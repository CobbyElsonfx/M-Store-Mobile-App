<?php

use App\Http\Controllers\Api\ApplicationController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\HealthController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ReferralController;
use App\Http\Controllers\Api\SettingsController;
use App\Http\Controllers\Api\PaystackWebhookController;
use App\Http\Controllers\Api\SubscriptionController;
use App\Http\Controllers\Api\SubscriptionPlanController;
use App\Http\Controllers\Api\UssdFlowController;
use App\Http\Controllers\Api\WalletController;
use Illuminate\Support\Facades\Route;

Route::get('/health', HealthController::class);
Route::post('/paystack/webhook', PaystackWebhookController::class);

Route::get('/referrals/validate/{code}', [ReferralController::class, 'validateCode']);

Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/register/verify', [AuthController::class, 'verifyRegistration']);
    Route::post('/register/resend-otp', [AuthController::class, 'resendRegistrationOtp']);
    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
    });
});

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/status', function () {
        return response()->json([
            'message' => 'Authenticated mobile API access confirmed.',
            'user_id' => auth()->id(),
        ]);
    });

    Route::get('/products', [ProductController::class, 'index']);
    Route::get('/products/{product}', [ProductController::class, 'show']);

    Route::get('/subscription-plans', [SubscriptionPlanController::class, 'index']);
    Route::get('/subscription-plans/{subscriptionPlan}', [SubscriptionPlanController::class, 'show']);
    Route::post('/subscriptions/pay', [SubscriptionController::class, 'pay']);
    Route::get('/subscriptions/payment/{reference}', [SubscriptionController::class, 'paymentStatus']);
    Route::get('/subscriptions/access-level', [SubscriptionController::class, 'accessLevel']);

    Route::get('/settings/business', [SettingsController::class, 'business']);
    Route::get('/settings/app', [SettingsController::class, 'app']);

    Route::get('/ussd-flows', [UssdFlowController::class, 'index']);

    Route::get('/orders', [OrderController::class, 'index']);
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/orders/{order}', [OrderController::class, 'show']);

    Route::get('/applications/next-id', [ApplicationController::class, 'nextId']);
    Route::get('/applications', [ApplicationController::class, 'index']);
    Route::get('/applications/{application}', [ApplicationController::class, 'show']);
    Route::post('/applications/{application}/submit', [ApplicationController::class, 'submit']);
    Route::post('/applications/{application}/documents', [ApplicationController::class, 'uploadDocument']);
    Route::delete('/applications/{application}/documents/{documentType}', [ApplicationController::class, 'deleteDocument']);
    Route::get('/applications/{application}/documents/{documentType}', [ApplicationController::class, 'downloadDocument']);

    Route::get('/wallet', [WalletController::class, 'show']);
    Route::get('/wallet/transactions', [WalletController::class, 'transactions']);
    Route::get('/withdrawals', [WalletController::class, 'withdrawals']);
    Route::post('/withdrawals', [WalletController::class, 'storeWithdrawal']);

    Route::get('/referrals', [ReferralController::class, 'index']);
    Route::get('/referrals/summary', [ReferralController::class, 'summary']);

    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::patch('/notifications/{notification}/read', [NotificationController::class, 'markRead']);
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllRead']);
});
