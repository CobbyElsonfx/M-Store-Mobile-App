# MoMo Kotle Laravel Backend

Laravel 13 API and admin — the **single authoritative backend** for the MoMo Kotle restructure.

**Target:** Kotlin → Laravel REST API → PostgreSQL

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

**Status:** Kotlin mobile and Laravel admin are the runtime stack. Legacy Next.js admin and Firebase/Firestore client artifacts have been removed from the repo.

## Quick start

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed
php artisan serve
```

- API health: http://localhost:8000/api/health
- Admin login: http://localhost:8000/admin/login

## Documentation

- [Migration Plan](../docs/LARAVEL_MIGRATION_PLAN.md)
- [API Architecture](../docs/API_ARCHITECTURE.md)
- [Database Architecture](../docs/DATABASE_ARCHITECTURE.md)
- [Deployment](../docs/DEPLOYMENT.md)
- [Existing System Architecture](../docs/ARCHITECTURE.md)

- [Export & Import Guide](../docs/MIGRATION_EXPORT_IMPORT.md)

## Migration import (optional)

Place a Firebase JSON export directory (with `manifest.json`) under `storage/app/migration/firebase-export/`, then:

```bash
cd laravel
php artisan migration:import-firebase --latest
php artisan migration:verify-firebase --latest
```

## Tests

```bash
php artisan test
```
