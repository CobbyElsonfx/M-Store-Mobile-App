<?php

namespace App\Services;

use App\Models\Referral;
use App\Models\User;
use App\Models\WalletTransaction;

class ReferralService
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
        private readonly WalletService $walletService,
    ) {}

    /**
     * @return \Illuminate\Database\Eloquent\Collection<int, Referral>
     */
    public function referralsForUser(User $user)
    {
        return Referral::query()
            ->where('referrer_user_id', $user->id)
            ->orderByDesc('registration_date')
            ->get();
    }

    public function summaryForUser(User $user): array
    {
        $wallet = $this->walletService->walletForUser($user);
        $referrals = $this->referralsForUser($user);
        $stats = $this->buildStats($user, $referrals, (float) $wallet->lifetime_earnings);
        $linkBase = (string) $this->businessSettings->get('referral_share_link_base', 'https://momokotle.app/ref/');

        return [
            'referralCode' => (string) ($user->referral_code ?? ''),
            'referralLink' => rtrim($linkBase, '/').'/'.($user->referral_code ?? ''),
            'stats' => $stats,
            'wallet' => [
                'userId' => (string) $user->id,
                'availableBalance' => (float) $wallet->available_balance,
                'pendingBalance' => (float) $wallet->pending_balance,
                'withdrawnBalance' => (float) $wallet->withdrawn_balance,
                'lifetimeEarnings' => (float) $wallet->lifetime_earnings,
                'updatedAt' => $wallet->updated_at?->toIso8601String(),
            ],
        ];
    }

    public function validateReferralCode(string $code): ?User
    {
        $normalized = strtoupper(trim($code));
        if ($normalized === '') {
            return null;
        }

        return User::query()
            ->whereRaw('UPPER(referral_code) = ?', [$normalized])
            ->first();
    }

    /** @param  \Illuminate\Database\Eloquent\Collection<int, Referral>  $referrals */
    private function buildStats(User $user, $referrals, float $lifetimeEarnings): array
    {
        $startOfDay = now()->startOfDay();
        $startOfMonth = now()->startOfMonth();

        $todayEarnings = (float) WalletTransaction::query()
            ->where('user_id', $user->id)
            ->where('status', 'Completed')
            ->where('created_at', '>=', $startOfDay)
            ->sum('amount');

        $monthlyEarnings = (float) WalletTransaction::query()
            ->where('user_id', $user->id)
            ->where('status', 'Completed')
            ->where('created_at', '>=', $startOfMonth)
            ->sum('amount');

        return [
            'totalReferrals' => $referrals->count(),
            'activeReferrals' => $referrals->where('is_active', true)->count(),
            'expiredReferrals' => $referrals->where('is_active', false)->count(),
            'totalEarnings' => $lifetimeEarnings,
            'todayEarnings' => round($todayEarnings, 2),
            'monthlyEarnings' => round($monthlyEarnings, 2),
            'lifetimeEarnings' => $lifetimeEarnings,
        ];
    }
}
