<?php

namespace App\Services;

use App\Models\BusinessSetting;
use App\Support\PaystackSecrets;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BusinessSettingsAdminService
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(array $data): void
    {
        if (round((float) $data['referral_commission_percent'] + (float) $data['system_commission_percent'], 2) !== 100.0) {
            throw ValidationException::withMessages([
                'system_commission_percent' => ['Referral and system commission percentages must total 100%.'],
            ]);
        }

        DB::transaction(function () use ($data) {
            foreach ($data as $key => $value) {
                BusinessSetting::query()->updateOrCreate(
                    ['key' => $key],
                    ['value' => $this->encodeValue($value)]
                );
            }
        });

        $this->businessSettings->forgetCache();
    }

    /** @return array<string, mixed> */
    public function formValues(): array
    {
        return [
            'referral_commission_percent' => $this->businessSettings->getFloat('referral_commission_percent', 40),
            'system_commission_percent' => $this->businessSettings->getFloat('system_commission_percent', 60),
            'monthly_subscription_bonus' => $this->businessSettings->getFloat('monthly_subscription_bonus', 1),
            'minimum_withdrawal' => $this->businessSettings->getFloat('minimum_withdrawal', 10),
            'trial_days' => $this->businessSettings->getInt('trial_days', 7),
            'currency' => (string) $this->businessSettings->get('currency', 'GHS'),
            'tax_rate' => $this->businessSettings->getFloat('tax_rate', 0),
            'store_enabled' => filter_var($this->businessSettings->get('store_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'subscription_enabled' => filter_var($this->businessSettings->get('subscription_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'maintenance_mode' => filter_var($this->businessSettings->get('maintenance_mode', false), FILTER_VALIDATE_BOOLEAN),
            'support_contact' => (string) $this->businessSettings->get('support_contact', ''),
            'referral_share_link_base' => (string) $this->businessSettings->get('referral_share_link_base', 'https://momokotle.app/ref/'),
            'paystack_public_key' => $this->paystackPublicKeyForForm(),
            'paystack_secret_configured' => $this->paystackSecretConfigured(),
            'paystack_base_url' => $this->paystackBaseUrlForForm(),
            'email_reminders_enabled' => filter_var($this->businessSettings->get('email_reminders_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'email_admin_alerts_enabled' => filter_var($this->businessSettings->get('email_admin_alerts_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'subscription_reminder_days' => (string) $this->businessSettings->get('subscription_reminder_days', '7,3,1'),
            'admin_notification_emails' => (string) $this->businessSettings->get('admin_notification_emails', ''),
        ];
    }

    private function encodeValue(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        return (string) $value;
    }

    private function paystackPublicKeyForForm(): string
    {
        $stored = trim((string) $this->businessSettings->get('paystack_public_key', ''));

        return $stored !== '' ? $stored : (string) config('services.paystack.public_key', '');
    }

    private function paystackBaseUrlForForm(): string
    {
        $stored = trim((string) $this->businessSettings->get('paystack_base_url', ''));

        return $stored !== ''
            ? $stored
            : (string) config('services.paystack.base_url', 'https://api.paystack.co');
    }

    private function paystackSecretConfigured(): bool
    {
        $stored = PaystackSecrets::decrypt((string) $this->businessSettings->get('paystack_secret_key', ''));

        return $stored !== '' || trim((string) config('services.paystack.secret_key', '')) !== '';
    }
}
