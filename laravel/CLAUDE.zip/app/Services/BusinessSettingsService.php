<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;

class BusinessSettingsService
{
    private const CACHE_KEY = 'business_settings.all';

    public function all(): array
    {
        return Cache::remember(self::CACHE_KEY, 300, function () {
            return \App\Models\BusinessSetting::query()
                ->pluck('value', 'key')
                ->map(fn ($value) => $this->decodeValue($value))
                ->all();
        });
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->all()[$key] ?? $default;
    }

    public function getFloat(string $key, float $default = 0.0): float
    {
        return (float) $this->get($key, $default);
    }

    public function getInt(string $key, int $default = 0): int
    {
        return (int) $this->get($key, $default);
    }

    public function forgetCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }

    private function decodeValue(string $value): mixed
    {
        $decoded = json_decode($value, true);

        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }
}
