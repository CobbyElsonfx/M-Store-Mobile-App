<?php

namespace App\Services;

use App\Enums\SubscriptionStatus;
use App\Models\User;
use Carbon\Carbon;

class SubscriptionAccessService
{
    public function resolveAccessLevel(User $user, ?Carbon $now = null): string
    {
        $now ??= now();

        if ($user->subscription_status === SubscriptionStatus::Trial
            && $user->trial_end_date
            && $now->lt($user->trial_end_date)
        ) {
            return 'full';
        }

        if ($user->subscription_status === SubscriptionStatus::Active
            && $user->subscription_expiry_date
            && $now->lt($user->subscription_expiry_date)
        ) {
            return 'full';
        }

        if ($user->subscription_status === SubscriptionStatus::Expired
            || ($user->subscription_status === SubscriptionStatus::Trial
                && $user->trial_end_date
                && $now->gte($user->trial_end_date))
            || ($user->subscription_status === SubscriptionStatus::Active
                && $user->subscription_expiry_date
                && $now->gte($user->subscription_expiry_date))
        ) {
            return 'subscription_required';
        }

        return 'limited';
    }
}
