<?php

namespace App\Services;

use App\Enums\AccountStatus;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Validation\ValidationException;

class UserAdminService
{
    public function updateAccountStatus(User $user, string $status): User
    {
        if ($user->isAdmin()) {
            throw ValidationException::withMessages([
                'account_status' => ['Admin accounts cannot be modified from this page.'],
            ]);
        }

        $previousStatus = $user->account_status;
        $accountStatus = AccountStatus::from($status);

        $user->update(['account_status' => $accountStatus]);

        if ($accountStatus === AccountStatus::Suspended && $previousStatus !== AccountStatus::Suspended) {
            Notification::query()->create([
                'user_id' => $user->id,
                'title' => 'Account Suspended',
                'message' => 'Your account has been suspended. Contact support if you believe this is an error.',
                'type' => 'AccountSuspended',
                'reference_id' => (string) $user->id,
                'is_read' => false,
            ]);

            \App\Events\AccountSuspended::dispatch($user->fresh());
        }

        return $user->fresh();
    }
}
