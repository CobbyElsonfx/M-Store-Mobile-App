<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class ProductAdminService
{
    /**
     * @param  array{
     *     product_name: string,
     *     product_description: string,
     *     category: string,
     *     price: float,
     *     profit: float,
     *     referral_percent: float,
     *     system_percent: float,
     *     stock_quantity: int,
     *     is_available: bool,
     * }  $data
     */
    public function create(array $data, ?UploadedFile $image = null): Product
    {
        $this->assertCommissionSplit($data['referral_percent'], $data['system_percent']);

        $id = (string) Str::uuid();

        $product = Product::query()->create([
            'id' => $id,
            ...$data,
            'image_path' => null,
        ]);

        if ($image !== null) {
            $product->update([
                'image_path' => $this->storeImage($product, $image),
            ]);
        }

        return $product->fresh();
    }

    /**
     * @param  array{
     *     product_name: string,
     *     product_description: string,
     *     category: string,
     *     price: float,
     *     profit: float,
     *     referral_percent: float,
     *     system_percent: float,
     *     stock_quantity: int,
     *     is_available: bool,
     * }  $data
     */
    public function update(Product $product, array $data, ?UploadedFile $image = null): Product
    {
        $this->assertCommissionSplit($data['referral_percent'], $data['system_percent']);

        if ($image !== null) {
            $this->deleteImage($product);
            $data['image_path'] = $this->storeImage($product, $image);
        }

        $product->update($data);

        return $product->fresh();
    }

    public function delete(Product $product): void
    {
        $this->deleteImage($product);
        $product->delete();
    }

    private function assertCommissionSplit(float $referralPercent, float $systemPercent): void
    {
        if (round($referralPercent + $systemPercent, 2) !== 100.0) {
            throw ValidationException::withMessages([
                'system_percent' => ['Referral and system percentages must total 100%.'],
            ]);
        }
    }

    private function storeImage(Product $product, UploadedFile $image): string
    {
        $extension = $image->getClientOriginalExtension() ?: 'jpg';
        $path = "products/{$product->id}.{$extension}";

        Storage::disk('public')->putFileAs(
            dirname($path),
            $image,
            basename($path)
        );

        return $path;
    }

    private function deleteImage(Product $product): void
    {
        if (blank($product->image_path)) {
            return;
        }

        if (str_starts_with($product->image_path, 'http://') || str_starts_with($product->image_path, 'https://')) {
            return;
        }

        Storage::disk('public')->delete($product->image_path);
    }
}
