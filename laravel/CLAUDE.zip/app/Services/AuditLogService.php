<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Http\Request;

class AuditLogService
{
    public function record(
        ?User $admin,
        string $action,
        ?string $entityType = null,
        ?string $entityId = null,
        mixed $oldValue = null,
        mixed $newValue = null,
        ?Request $request = null,
    ): AuditLog {
        return AuditLog::query()->create([
            'admin_user_id' => $admin?->id,
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'metadata' => array_filter([
                'admin_email' => $admin?->email,
                'old_value' => $this->normalizeValue($oldValue),
                'new_value' => $this->normalizeValue($newValue),
            ], fn ($value) => $value !== null),
            'ip_address' => $request?->ip(),
        ]);
    }

    private function normalizeValue(mixed $value): mixed
    {
        if ($value === null) {
            return null;
        }

        if (is_scalar($value)) {
            return $value;
        }

        return json_decode(json_encode($value), true);
    }
}
