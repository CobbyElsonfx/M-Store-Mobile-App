<?php

namespace App\Services;

use App\Models\AgentApplication;
use App\Models\Notification;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ApplicationAdminService
{
    /** @var list<string> */
    private const STATUSES = ['Pending', 'Approved', 'Rejected', 'ResubmissionRequired'];

    public function updateStatus(AgentApplication $application, string $status, ?string $adminNote = null): AgentApplication
    {
        if (! in_array($status, self::STATUSES, true)) {
            throw ValidationException::withMessages([
                'status' => ['Invalid application status.'],
            ]);
        }

        if ($application->status === 'Draft') {
            throw ValidationException::withMessages([
                'status' => ['Draft applications cannot be reviewed.'],
            ]);
        }

        $previousStatus = $application->status;
        $statusChanged = $previousStatus !== $status;

        return DB::transaction(function () use ($application, $status, $adminNote, $previousStatus, $statusChanged) {
            $application->update([
                'status' => $status,
                'admin_note' => $adminNote ?? '',
            ]);

            $updated = $application->fresh(['documents', 'user']);
            $this->notifyApplicant($updated, $status, $adminNote);

            if ($statusChanged) {
                DB::afterCommit(function () use ($updated, $previousStatus, $status, $adminNote) {
                    \App\Events\ApplicationStatusChanged::dispatch(
                        $updated,
                        $previousStatus,
                        $status,
                        $adminNote
                    );
                });
            }

            return $updated;
        });
    }

    private function notifyApplicant(AgentApplication $application, string $status, ?string $adminNote): void
    {
        [$title, $message, $type] = match ($status) {
            'Approved' => [
                'Application Approved',
                "Your {$application->form_type} application ({$application->id}) has been approved.",
                'ApplicationApproved',
            ],
            'Rejected' => [
                'Application Rejected',
                $adminNote
                    ? "Your {$application->form_type} application was rejected: {$adminNote}"
                    : "Your {$application->form_type} application ({$application->id}) was rejected.",
                'ApplicationRejected',
            ],
            'ResubmissionRequired' => [
                'Resubmission Required',
                $adminNote
                    ? "Please resubmit your {$application->form_type} application: {$adminNote}"
                    : "Please resubmit your {$application->form_type} application ({$application->id}).",
                'ApplicationResubmissionRequired',
            ],
            default => [
                'Application Updated',
                "Your {$application->form_type} application status is now {$status}.",
                'ApplicationUpdated',
            ],
        };

        Notification::query()->create([
            'user_id' => $application->user_id,
            'title' => $title,
            'message' => $message,
            'type' => $type,
            'reference_id' => $application->id,
            'is_read' => false,
        ]);
    }
}
