<?php

namespace App\Services;

use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class NotificationAdminService
{
    public function sendToUser(int $userId, string $title, string $message): void
    {
        $user = User::query()->whereKey($userId)->where('role', UserRole::Agent)->first();

        if ($user === null) {
            throw ValidationException::withMessages([
                'user_id' => ['Selected user was not found.'],
            ]);
        }

        $this->createNotification($user->id, $title, $message);
    }

    public function sendBulk(string $target, string $title, string $message): int
    {
        $query = User::query()->where('role', UserRole::Agent);

        $query = match ($target) {
            'all' => $query,
            'subscribers' => $query->where('subscription_status', SubscriptionStatus::Active),
            'trial' => $query->where('subscription_status', SubscriptionStatus::Trial),
            default => throw ValidationException::withMessages([
                'target' => ['Invalid notification target.'],
            ]),
        };

        $sent = 0;

        DB::transaction(function () use ($query, $title, $message, &$sent) {
            $query->orderBy('id')->chunkById(100, function ($users) use ($title, $message, &$sent) {
                foreach ($users as $user) {
                    $this->createNotification($user->id, $title, $message);
                    $sent++;
                }
            });
        });

        return $sent;
    }

    private function createNotification(int $userId, string $title, string $message): void
    {
        Notification::query()->create([
            'user_id' => $userId,
            'title' => $title,
            'message' => $message,
            'type' => 'AdminBroadcast',
            'reference_id' => null,
            'is_read' => false,
        ]);
    }
}
