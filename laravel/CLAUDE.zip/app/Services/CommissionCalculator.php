<?php

namespace App\Services;

use App\Models\Product;

class CommissionCalculator
{
    /**
     * Calculate referral/system commission split from product profit.
     * Percentages come from the product record (admin-configurable).
     */
    public function calculateFromProduct(Product $product, int $quantity = 1): array
    {
        $profit = round((float) $product->profit * $quantity, 2);
        $referralPercent = (float) $product->referral_percent;
        $systemPercent = (float) $product->system_percent;

        $referralShare = round(($profit * $referralPercent) / 100, 2);
        $systemShare = round(($profit * $systemPercent) / 100, 2);

        return [
            'product_profit' => $profit,
            'referral_share' => $referralShare,
            'system_share' => $systemShare,
            'referral_percent' => $referralPercent,
            'system_percent' => $systemPercent,
        ];
    }
}
