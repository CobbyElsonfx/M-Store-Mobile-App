<?php

namespace App\Services;

use App\Support\PaystackSecrets;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class PaystackClient
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    public function initialize(array $payload): array
    {
        $response = $this->http()->post('/transaction/initialize', $payload);

        return $this->payload($response->json(), 'Could not initialize Paystack payment.');
    }

    public function verify(string $reference): array
    {
        $response = $this->http()->get('/transaction/verify/'.rawurlencode($reference));

        return $this->payload($response->json(), 'Could not verify Paystack payment.');
    }

    public function isValidSignature(string $rawBody, ?string $signature): bool
    {
        $secret = $this->secretKey();
        if ($secret === '' || $signature === null || $signature === '') {
            return false;
        }

        $expected = hash_hmac('sha512', $rawBody, $secret);

        return hash_equals($expected, $signature);
    }

    public function publicKey(): string
    {
        $fromSettings = trim((string) $this->businessSettings->get('paystack_public_key', ''));

        return $fromSettings !== ''
            ? $fromSettings
            : (string) config('services.paystack.public_key');
    }

    public function secretKey(): string
    {
        $fromSettings = PaystackSecrets::decrypt(
            (string) $this->businessSettings->get('paystack_secret_key', '')
        );

        return $fromSettings !== ''
            ? $fromSettings
            : (string) config('services.paystack.secret_key');
    }

    public function baseUrl(): string
    {
        $fromSettings = trim((string) $this->businessSettings->get('paystack_base_url', ''));

        return $fromSettings !== ''
            ? $fromSettings
            : (string) config('services.paystack.base_url', 'https://api.paystack.co');
    }

    public function hasSecretKey(): bool
    {
        return $this->secretKey() !== '';
    }

    public function verifiesSsl(): bool
    {
        $configured = config('services.paystack.verify_ssl');
        if ($configured !== null && $configured !== '') {
            return filter_var($configured, FILTER_VALIDATE_BOOLEAN);
        }

        return ! app()->isLocal();
    }

    /**
     * @param  array<string, mixed>|null  $json
     * @return array<string, mixed>
     */
    private function payload(?array $json, string $fallback): array
    {
        if (! is_array($json) || ($json['status'] ?? false) !== true || ! is_array($json['data'] ?? null)) {
            $message = is_array($json) ? (string) ($json['message'] ?? $fallback) : $fallback;
            throw new RuntimeException($message);
        }

        return $json['data'];
    }

    private function http(): PendingRequest
    {
        $secret = $this->secretKey();
        if ($secret === '') {
            throw new RuntimeException('Paystack is not configured.');
        }

        $request = Http::baseUrl($this->baseUrl())
            ->withToken($secret)
            ->acceptJson()
            ->asJson()
            ->timeout(30);

        if (! $this->verifiesSsl()) {
            $request = $request->withoutVerifying();
        }

        return $request;
    }
}
