<?php

namespace App\Services;

use App\Models\AgentApplication;
use App\Models\ApplicationDocument;
use App\Models\User;
use App\Support\BusinessNameValidator;
use App\Support\DocumentSlotMapper;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class ApplicationService
{
    public function __construct(
        private readonly DailyCounterService $dailyCounter,
    ) {}

    public function reserveNext(User $user): AgentApplication
    {
        $id = $this->dailyCounter->nextSubmissionId();

        return AgentApplication::query()->create([
            'id' => $id,
            'user_id' => $user->id,
            'form_type' => '',
            'applicant_name' => '',
            'phone_number' => '',
            'form_data' => [],
            'status' => 'Draft',
        ]);
    }

    public function uploadDocument(
        AgentApplication $application,
        User $user,
        string $slotId,
        UploadedFile $file
    ): ApplicationDocument {
        $this->assertOwnedDraft($application, $user);

        $documentType = DocumentSlotMapper::documentType($slotId);
        $extension = $file->getClientOriginalExtension() ?: 'bin';
        $filename = DocumentSlotMapper::storageBasename($slotId, $extension);
        $storagePath = "{$user->id}/{$application->id}/{$filename}";

        Storage::disk('agent_documents')->putFileAs(
            dirname($storagePath),
            $file,
            basename($storagePath)
        );

        return ApplicationDocument::query()->updateOrCreate(
            [
                'application_id' => $application->id,
                'document_type' => $documentType,
            ],
            [
                'storage_path' => $storagePath,
                'mime_type' => $file->getMimeType(),
                'file_size' => $file->getSize(),
                'original_filename' => $file->getClientOriginalName() ?: $filename,
            ]
        );
    }

    public function deleteDocument(
        AgentApplication $application,
        User $user,
        string $documentType
    ): void {
        $this->assertOwnedDraft($application, $user);

        $document = ApplicationDocument::query()
            ->where('application_id', $application->id)
            ->where('document_type', $documentType)
            ->first();

        if ($document === null) {
            return;
        }

        Storage::disk('agent_documents')->delete($document->storage_path);
        $document->delete();
    }

    /**
     * @param  array{form_type: string, form_data: array<string, string>}  $data
     */
    public function submit(AgentApplication $application, User $user, array $data): AgentApplication
    {
        $this->assertOwnedDraft($application, $user);

        if ($message = BusinessNameValidator::validateFormData($data['form_data'])) {
            throw ValidationException::withMessages(['form_data' => [$message]]);
        }

        $documents = ApplicationDocument::query()
            ->where('application_id', $application->id)
            ->get();

        if ($documents->isEmpty()) {
            throw ValidationException::withMessages([
                'documents' => ['No documents to upload. Please attach the required files.'],
            ]);
        }

        $formData = $data['form_data'];
        $applicantName = $this->resolveApplicantName($formData);
        $phoneNumber = $formData['phoneNumber']
            ?? $formData['telephoneNumber']
            ?? $formData['whatsappNumber']
            ?? '';

        if ($phoneNumber === '') {
            throw ValidationException::withMessages([
                'form_data' => ['A phone number is required.'],
            ]);
        }

        $application->update([
            'form_type' => $data['form_type'],
            'applicant_name' => $applicantName,
            'phone_number' => $phoneNumber,
            'form_data' => $formData,
            'status' => 'Pending',
            'admin_note' => null,
        ]);

        $submitted = $application->fresh(['documents', 'user']);

        \App\Events\ApplicationSubmitted::dispatch($submitted);

        return $submitted;
    }

    public function documentDownloadPath(AgentApplication $application, User $user, string $documentType): string
    {
        if ($application->user_id !== $user->id) {
            abort(404);
        }

        return $this->resolveDocumentPath($application, $documentType);
    }

    public function adminDocumentDownloadPath(AgentApplication $application, string $documentType): string
    {
        if ($application->status === 'Draft') {
            abort(404);
        }

        return $this->resolveDocumentPath($application, $documentType);
    }

    private function resolveDocumentPath(AgentApplication $application, string $documentType): string
    {
        $document = ApplicationDocument::query()
            ->where('application_id', $application->id)
            ->where('document_type', $documentType)
            ->firstOrFail();

        if (! Storage::disk('agent_documents')->exists($document->storage_path)) {
            abort(404);
        }

        return Storage::disk('agent_documents')->path($document->storage_path);
    }

    public function documentUrl(AgentApplication $application, string $documentType): string
    {
        return url("/api/applications/{$application->id}/documents/{$documentType}");
    }

    private function assertOwnedDraft(AgentApplication $application, User $user): void
    {
        if ($application->user_id !== $user->id) {
            abort(404);
        }

        if ($application->status !== 'Draft') {
            throw ValidationException::withMessages([
                'application' => ['This application has already been submitted.'],
            ]);
        }
    }

    /** @param  array<string, string>  $formData */
    private function resolveApplicantName(array $formData): string
    {
        if ($name = trim($formData['fullName'] ?? '')) {
            return $name;
        }

        $first = trim($formData['firstName'] ?? '');
        $surname = trim($formData['surname'] ?? '');
        $combined = trim("{$first} {$surname}");
        if ($combined !== '') {
            return $combined;
        }

        return trim($formData['businessName'] ?? '');
    }
}
