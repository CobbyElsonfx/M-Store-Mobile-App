<?php

namespace App\Services;

use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Models\WithdrawalRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class WalletService
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    public function walletForUser(User $user): Wallet
    {
        return Wallet::query()->firstOrCreate(
            ['user_id' => $user->id],
            [
                'available_balance' => 0,
                'pending_balance' => 0,
                'withdrawn_balance' => 0,
                'lifetime_earnings' => 0,
            ]
        );
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection<int, WalletTransaction>
     */
    public function transactionsForUser(User $user, int $limit = 50)
    {
        return WalletTransaction::query()
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get();
    }

    public function requestWithdrawal(
        User $user,
        float $amount,
        string $paymentMethod,
        string $paymentNumber
    ): WithdrawalRequest {
        $minimum = $this->businessSettings->getFloat('minimum_withdrawal', 10);
        $currency = (string) $this->businessSettings->get('currency', 'GHS');

        if ($amount < $minimum) {
            throw ValidationException::withMessages([
                'amount' => ["Minimum withdrawal is {$currency} {$minimum}"],
            ]);
        }

        return DB::transaction(function () use ($user, $amount, $paymentMethod, $paymentNumber) {
            $wallet = Wallet::query()
                ->where('user_id', $user->id)
                ->lockForUpdate()
                ->first();

            if ($wallet === null) {
                throw ValidationException::withMessages([
                    'amount' => ['Wallet not found'],
                ]);
            }

            if ($amount > (float) $wallet->available_balance) {
                throw ValidationException::withMessages([
                    'amount' => ['Insufficient available balance'],
                ]);
            }

            $wallet->update([
                'available_balance' => round((float) $wallet->available_balance - $amount, 2),
                'pending_balance' => round((float) $wallet->pending_balance + $amount, 2),
            ]);

            return WithdrawalRequest::query()->create([
                'user_id' => $user->id,
                'amount' => round($amount, 2),
                'payment_method' => $paymentMethod,
                'payment_number' => trim($paymentNumber),
                'status' => 'Pending',
            ]);
        });
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection<int, WithdrawalRequest>
     */
    public function withdrawalsForUser(User $user)
    {
        return WithdrawalRequest::query()
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->get();
    }
}
