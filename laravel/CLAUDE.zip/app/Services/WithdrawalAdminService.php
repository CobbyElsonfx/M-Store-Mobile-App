<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\Wallet;
use App\Models\WithdrawalRequest;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class WithdrawalAdminService
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    public function approve(WithdrawalRequest $withdrawal, ?string $adminNote = null): WithdrawalRequest
    {
        return DB::transaction(function () use ($withdrawal, $adminNote) {
            $locked = $this->lockWithdrawal($withdrawal);

            if ($locked->status !== 'Pending') {
                throw new RuntimeException("Cannot approve withdrawal with status: {$locked->status}");
            }

            $locked->update([
                'status' => 'Approved',
                'admin_note' => $adminNote ?? $locked->admin_note,
            ]);

            $this->notifyUser($locked->fresh(['user']), 'Approved', $adminNote);

            return $locked->fresh(['user']);
        });
    }

    public function reject(WithdrawalRequest $withdrawal, ?string $adminNote = null): WithdrawalRequest
    {
        return DB::transaction(function () use ($withdrawal, $adminNote) {
            $locked = $this->lockWithdrawal($withdrawal);

            if (! in_array($locked->status, ['Pending', 'Approved'], true)) {
                throw new RuntimeException("Cannot reject withdrawal with status: {$locked->status}");
            }

            $wallet = Wallet::query()
                ->where('user_id', $locked->user_id)
                ->lockForUpdate()
                ->first();

            if ($wallet !== null) {
                $amount = (float) $locked->amount;
                $wallet->update([
                    'available_balance' => round((float) $wallet->available_balance + $amount, 2),
                    'pending_balance' => round(max(0, (float) $wallet->pending_balance - $amount), 2),
                ]);
            }

            $locked->update([
                'status' => 'Rejected',
                'admin_note' => $adminNote ?? $locked->admin_note,
            ]);

            $this->notifyUser($locked->fresh(['user']), 'Rejected', $adminNote);

            return $locked->fresh(['user']);
        });
    }

    public function markPaid(WithdrawalRequest $withdrawal, ?string $adminNote = null): WithdrawalRequest
    {
        return DB::transaction(function () use ($withdrawal, $adminNote) {
            $locked = $this->lockWithdrawal($withdrawal);

            if ($locked->status !== 'Approved') {
                throw new RuntimeException("Cannot mark as paid: withdrawal status is {$locked->status}");
            }

            $wallet = Wallet::query()
                ->where('user_id', $locked->user_id)
                ->lockForUpdate()
                ->first();

            if ($wallet === null) {
                throw new RuntimeException('Wallet not found for withdrawal user');
            }

            $amount = (float) $locked->amount;
            $pending = (float) $wallet->pending_balance;

            if ($amount > $pending) {
                throw new RuntimeException('Insufficient pending balance for withdrawal payout');
            }

            $wallet->update([
                'pending_balance' => round($pending - $amount, 2),
                'withdrawn_balance' => round((float) $wallet->withdrawn_balance + $amount, 2),
            ]);

            $locked->update([
                'status' => 'Paid',
                'admin_note' => $adminNote ?? $locked->admin_note,
            ]);

            $this->notifyUser($locked->fresh(['user']), 'Paid', $adminNote);

            return $locked->fresh(['user']);
        });
    }

    private function lockWithdrawal(WithdrawalRequest $withdrawal): WithdrawalRequest
    {
        return WithdrawalRequest::query()->whereKey($withdrawal->id)->lockForUpdate()->firstOrFail();
    }

    private function notifyUser(WithdrawalRequest $withdrawal, string $status, ?string $adminNote): void
    {
        $currency = (string) $this->businessSettings->get('currency', 'GHS');
        $amount = number_format((float) $withdrawal->amount, 2);

        [$title, $message, $type] = match ($status) {
            'Approved' => [
                'Withdrawal Approved',
                "Your {$currency} {$amount} withdrawal request has been approved.",
                'WithdrawalApproved',
            ],
            'Rejected' => [
                'Withdrawal Rejected',
                $adminNote
                    ? "Your {$currency} {$amount} withdrawal was rejected: {$adminNote}"
                    : "Your {$currency} {$amount} withdrawal request was rejected.",
                'WithdrawalRejected',
            ],
            'Paid' => [
                'Withdrawal Paid',
                "Your {$currency} {$amount} withdrawal has been paid to {$withdrawal->payment_number}.",
                'WithdrawalPaid',
            ],
            default => [
                'Withdrawal Updated',
                "Your withdrawal request status is now {$status}.",
                'WithdrawalUpdated',
            ],
        };

        Notification::query()->create([
            'user_id' => $withdrawal->user_id,
            'title' => $title,
            'message' => $message,
            'type' => $type,
            'reference_id' => $withdrawal->id,
            'is_read' => false,
        ]);
    }
}
