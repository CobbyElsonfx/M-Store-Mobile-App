<?php

namespace App\Services;

use App\Enums\SubscriptionStatus;
use App\Models\Notification;
use App\Models\Payment;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Support\PaystackMoney;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use RuntimeException;

class SubscriptionService
{
    public const PROVIDER_PAYSTACK = 'PAYSTACK';

    public const PROVIDER_ADMIN = 'ADMIN';

    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
        private readonly PaystackClient $paystack,
    ) {}

    /**
     * @return array{
     *     payment: Payment,
     *     access_code: string,
     *     authorization_url: string,
     *     reference: string,
     *     public_key: string,
     *     amount: float,
     *     currency: string,
     *     plan_name: string
     * }
     */
    public function initializePaystackPayment(User $user, string $planId): array
    {
        $this->assertSubscriptionsEnabled();
        $plan = $this->activePlan($planId);
        $this->reconcileOpenPaystackPayments($user);
        $this->assertNoActiveSubscription($user);

        $currency = strtoupper((string) ($this->businessSettings->get('currency', 'GHS') ?: 'GHS'));
        $reference = $this->uniqueReference($user->id);

        $payment = Payment::query()->create([
            'user_id' => $user->id,
            'subscription_plan_id' => $plan->id,
            'amount' => $plan->price,
            'currency' => $currency,
            'provider' => self::PROVIDER_PAYSTACK,
            'reference' => $reference,
            'purpose' => 'Subscription',
            'purpose_id' => $plan->id,
            'status' => 'Pending',
            'metadata' => [
                'user_id' => $user->id,
                'subscription_plan_id' => $plan->id,
            ],
        ]);

        try {
            $initialized = $this->paystack->initialize([
                'email' => $user->email,
                'amount' => PaystackMoney::toSubunits((float) $plan->price),
                'currency' => $currency,
                'reference' => $reference,
                'channels' => config('services.paystack.channels', ['mobile_money', 'card']),
                'metadata' => [
                    'user_id' => $user->id,
                    'payment_id' => $payment->id,
                    'subscription_plan_id' => $plan->id,
                ],
            ]);
        } catch (RuntimeException $exception) {
            $payment->update(['status' => 'Failed']);
            throw ValidationException::withMessages([
                'plan_id' => [$exception->getMessage()],
            ]);
        }

        $accessCode = (string) ($initialized['access_code'] ?? '');
        $authorizationUrl = (string) ($initialized['authorization_url'] ?? '');
        if ($authorizationUrl === '' && $accessCode !== '') {
            $authorizationUrl = 'https://checkout.paystack.com/'.$accessCode;
        }
        $paystackReference = (string) ($initialized['reference'] ?? $reference);

        $payment->update([
            'provider_reference' => $paystackReference !== '' ? $paystackReference : $reference,
            'metadata' => array_merge($payment->metadata ?? [], [
                'access_code' => $accessCode,
                'authorization_url' => $authorizationUrl,
            ]),
        ]);

        return [
            'payment' => $payment->fresh(),
            'access_code' => $accessCode,
            'authorization_url' => $authorizationUrl,
            'reference' => $reference,
            'public_key' => $this->paystack->publicKey(),
            'amount' => (float) $plan->price,
            'currency' => $currency,
            'plan_name' => $plan->plan_name,
        ];
    }

    public function paymentStatus(User $user, string $reference): Payment
    {
        $payment = Payment::query()
            ->where('user_id', $user->id)
            ->where(function ($query) use ($reference) {
                $query->where('reference', $reference)
                    ->orWhere('provider_reference', $reference);
            })
            ->first();

        if ($payment === null) {
            throw ValidationException::withMessages([
                'reference' => ['Payment was not found.'],
            ]);
        }

        if (in_array($payment->status, ['Pending', 'Ongoing'], true)) {
            $this->syncFromPaystack($payment);
            $payment->refresh();
        }

        return $payment;
    }

    public function handleWebhook(string $rawBody, ?string $signature): void
    {
        if (! $this->paystack->isValidSignature($rawBody, $signature)) {
            abort(401, 'Invalid Paystack signature.');
        }

        $payload = json_decode($rawBody, true);
        if (! is_array($payload)) {
            abort(400, 'Invalid webhook payload.');
        }

        $event = (string) ($payload['event'] ?? '');
        $data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        $reference = (string) ($data['reference'] ?? '');
        if ($reference === '') {
            return;
        }

        $payment = Payment::query()
            ->where('reference', $reference)
            ->orWhere('provider_reference', $reference)
            ->first();

        if ($payment === null) {
            return;
        }

        match ($event) {
            'charge.success' => $this->syncFromPaystack($payment),
            'charge.failed' => $this->markUnsuccessful($payment, 'Failed'),
            default => $this->applyGatewayStatus($payment, (string) ($data['status'] ?? '')),
        };
    }

    public function syncFromPaystack(Payment $payment): Payment
    {
        $reference = $payment->provider_reference ?: $payment->reference;

        try {
            $verified = $this->paystack->verify($reference);
        } catch (RuntimeException) {
            return $payment;
        }

        $this->applyVerifiedTransaction($payment, $verified);

        return $payment->fresh();
    }

    /**
     * @deprecated Client-confirmed purchases are no longer accepted. Paystack webhook/verify activates subscriptions.
     *
     * @param  array{plan_id: string, payment_provider: string, payment_reference: string}  $data
     */
    public function purchase(User $user, array $data): Subscription
    {
        throw ValidationException::withMessages([
            'plan_id' => ['Use Paystack checkout to purchase a subscription.'],
        ]);
    }

    public function assignPlan(
        User $user,
        SubscriptionPlan $plan,
        string $provider = self::PROVIDER_ADMIN,
        ?string $reference = null,
        bool $replaceActive = true,
        bool $processReferralBonus = false,
    ): Subscription {
        return DB::transaction(function () use ($user, $plan, $provider, $reference, $replaceActive, $processReferralBonus) {
            /** @var User $locked */
            $locked = User::query()->whereKey($user->id)->lockForUpdate()->firstOrFail();
            $previousExpiry = $locked->subscription_expiry_date;
            $wasActive = $this->hasActiveSubscription($locked);

            if ($replaceActive) {
                $this->expireActiveSubscriptions($locked);
            }

            $subscription = $this->applyPlanToUser(
                $locked,
                $plan,
                $provider,
                $reference ?? $this->uniqueAdminReference($locked->id),
                $processReferralBonus
            );

            DB::afterCommit(function () use ($locked, $subscription, $wasActive, $previousExpiry) {
                $freshUser = $locked->fresh();
                $freshSubscription = $subscription->fresh();
                if ($freshUser === null || $freshSubscription === null) {
                    return;
                }

                if ($wasActive) {
                    \App\Events\SubscriptionRenewed::dispatch($freshUser, $freshSubscription, $previousExpiry);
                } else {
                    \App\Events\SubscriptionActivated::dispatch($freshUser, $freshSubscription);
                }
            });

            return $subscription;
        });
    }

    public function revokeCurrentSubscription(User $user): void
    {
        DB::transaction(function () use ($user) {
            /** @var User $locked */
            $locked = User::query()->whereKey($user->id)->lockForUpdate()->firstOrFail();

            $this->expireActiveSubscriptions($locked);
            $expiry = $locked->subscription_expiry_date;

            $locked->update([
                'subscription_status' => SubscriptionStatus::Expired,
                'subscription_expiry_date' => now(),
                'active_subscription_id' => null,
            ]);

            Referral::query()
                ->where('referred_user_id', $locked->id)
                ->update(['has_active_subscription' => false]);

            DB::afterCommit(function () use ($locked, $expiry) {
                $freshUser = $locked->fresh();
                if ($freshUser !== null) {
                    \App\Events\SubscriptionExpired::dispatch($freshUser, $expiry, 'admin');
                }
            });
        });
    }

    private function applyVerifiedTransaction(Payment $payment, array $verified): void
    {
        $status = strtolower((string) ($verified['status'] ?? ''));

        if ($status === 'success') {
            $this->fulfillFromVerifiedPayload($payment, $verified);

            return;
        }

        $this->applyGatewayStatus($payment, $status);
    }

    /**
     * @param  array<string, mixed>  $verified
     */
    private function fulfillFromVerifiedPayload(Payment $payment, array $verified): void
    {
        DB::transaction(function () use ($payment, $verified) {
            /** @var Payment $locked */
            $locked = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();

            if ($locked->status === 'Confirmed') {
                return;
            }

            $amount = (int) ($verified['amount'] ?? 0);
            $currency = strtoupper((string) ($verified['currency'] ?? ''));

            if ($currency !== strtoupper((string) $locked->currency)
                || ! PaystackMoney::matches((float) $locked->amount, $amount)
            ) {
                $locked->update([
                    'status' => 'Failed',
                    'metadata' => array_merge($locked->metadata ?? [], [
                        'failure_reason' => 'amount_or_currency_mismatch',
                    ]),
                ]);

                return;
            }

            $user = User::query()->whereKey($locked->user_id)->lockForUpdate()->firstOrFail();
            $plan = $this->activePlan((string) $locked->subscription_plan_id);

            if ($this->hasActiveSubscription($user)) {
                $locked->update([
                    'status' => 'Confirmed',
                    'provider_reference' => (string) ($verified['reference'] ?? $locked->provider_reference),
                    'metadata' => array_merge($locked->metadata ?? [], [
                        'skipped_activation' => 'already_active',
                        'paystack_transaction_id' => $verified['id'] ?? null,
                    ]),
                ]);

                DB::afterCommit(function () use ($locked) {
                    \App\Events\PaymentSuccessful::dispatch($locked->fresh(['user', 'plan']));
                });

                return;
            }

            $this->activatePaidSubscription($user, $plan, $locked, $verified);
        });
    }

    /**
     * @param  array<string, mixed>  $verified
     */
    private function activatePaidSubscription(
        User $user,
        SubscriptionPlan $plan,
        Payment $payment,
        array $verified
    ): Subscription {
        $paystackReference = (string) ($verified['reference'] ?? $payment->reference);

        $subscription = $this->applyPlanToUser(
            $user,
            $plan,
            self::PROVIDER_PAYSTACK,
            $payment->reference,
            true
        );

        $payment->update([
            'status' => 'Confirmed',
            'purpose_id' => $subscription->id,
            'provider_reference' => $paystackReference,
            'metadata' => array_merge($payment->metadata ?? [], [
                'paystack_transaction_id' => $verified['id'] ?? null,
            ]),
        ]);

        DB::afterCommit(function () use ($user, $subscription, $payment) {
            $freshPayment = $payment->fresh(['user', 'plan']);
            $freshUser = $user->fresh();
            $freshSubscription = $subscription->fresh();
            if ($freshPayment !== null) {
                \App\Events\PaymentSuccessful::dispatch($freshPayment);
            }
            if ($freshUser !== null && $freshSubscription !== null) {
                \App\Events\SubscriptionActivated::dispatch($freshUser, $freshSubscription, $freshPayment);
            }
        });

        return $subscription;
    }

    private function applyPlanToUser(
        User $user,
        SubscriptionPlan $plan,
        string $provider,
        string $reference,
        bool $processReferralBonus,
    ): Subscription {
        $now = now();
        $endDate = $now->copy()->addDays($plan->duration_days);

        $subscription = Subscription::query()->create([
            'user_id' => $user->id,
            'plan_id' => $plan->id,
            'plan_name' => $plan->plan_name,
            'price' => $plan->price,
            'duration_days' => $plan->duration_days,
            'payment_provider' => $provider,
            'payment_reference' => $reference,
            'start_date' => $now,
            'end_date' => $endDate,
            'status' => 'Active',
        ]);

        $user->update([
            'subscription_status' => SubscriptionStatus::Active,
            'subscription_expiry_date' => $endDate,
            'active_subscription_id' => $subscription->id,
        ]);

        Referral::query()
            ->where('referred_user_id', $user->id)
            ->update(['has_active_subscription' => true]);

        if ($processReferralBonus && $user->referred_by_user_id) {
            $this->processReferrerBonus(
                (int) $user->referred_by_user_id,
                $subscription->id
            );
        }

        return $subscription;
    }

    private function expireActiveSubscriptions(User $user): void
    {
        Subscription::query()
            ->where('user_id', $user->id)
            ->where('status', 'Active')
            ->update(['status' => 'Expired']);
    }

    private function applyGatewayStatus(Payment $payment, string $gatewayStatus): void
    {
        $mapped = match (strtolower($gatewayStatus)) {
            'failed' => 'Failed',
            'abandoned' => 'Abandoned',
            'reversed' => 'Reversed',
            'ongoing', 'processing' => 'Ongoing',
            default => null,
        };

        if ($mapped === null || $payment->status === 'Confirmed') {
            return;
        }

        $this->markUnsuccessful($payment, $mapped);
    }

    private function markUnsuccessful(Payment $payment, string $status): void
    {
        if ($payment->status === 'Confirmed') {
            return;
        }

        $alreadyRecorded = $payment->status === $status;
        $payment->update(['status' => $status]);

        if ($alreadyRecorded) {
            return;
        }

        $fresh = $payment->fresh(['user', 'plan']);
        if ($fresh === null) {
            return;
        }

        if ($status === 'Abandoned') {
            \App\Events\PaymentAbandoned::dispatch($fresh);
        } elseif (in_array($status, ['Failed', 'Reversed'], true)) {
            \App\Events\PaymentFailed::dispatch($fresh);
        }
    }

    private function assertSubscriptionsEnabled(): void
    {
        if (! filter_var($this->businessSettings->get('subscription_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
            throw ValidationException::withMessages([
                'plan_id' => ['Subscriptions are currently disabled.'],
            ]);
        }
    }

    private function activePlan(string $planId): SubscriptionPlan
    {
        $plan = SubscriptionPlan::query()
            ->whereKey($planId)
            ->where('status', 'Active')
            ->first();

        if ($plan === null) {
            throw ValidationException::withMessages([
                'plan_id' => ['Subscription plan is not available.'],
            ]);
        }

        return $plan;
    }

    private function assertNoActiveSubscription(User $user): void
    {
        if ($this->hasActiveSubscription($user)) {
            throw ValidationException::withMessages([
                'plan_id' => ['You already have an active subscription.'],
            ]);
        }
    }

    private function hasActiveSubscription(User $user): bool
    {
        return Subscription::query()
            ->where('user_id', $user->id)
            ->where('status', 'Active')
            ->where('end_date', '>', now())
            ->exists();
    }

    private function reconcileOpenPaystackPayments(User $user): void
    {
        Payment::query()
            ->where('user_id', $user->id)
            ->where('provider', self::PROVIDER_PAYSTACK)
            ->whereIn('status', ['Pending', 'Ongoing'])
            ->get()
            ->each(fn (Payment $payment) => $this->syncFromPaystack($payment));
    }

    private function uniqueReference(int $userId): string
    {
        do {
            $reference = 'MKSUB_'.$userId.'_'.Str::lower(Str::ulid());
        } while (Payment::query()->where('reference', $reference)->exists());

        return $reference;
    }

    private function uniqueAdminReference(int $userId): string
    {
        do {
            $reference = 'ADMIN_'.$userId.'_'.Str::lower(Str::ulid());
        } while (Subscription::query()->where('payment_reference', $reference)->exists());

        return $reference;
    }

    private function processReferrerBonus(int $referrerUserId, string $subscriptionId): void
    {
        $bonus = $this->businessSettings->getFloat('monthly_subscription_bonus', 1);
        if ($bonus <= 0) {
            return;
        }

        $currency = (string) $this->businessSettings->get('currency', 'GHS');

        $wallet = Wallet::query()
            ->where('user_id', $referrerUserId)
            ->lockForUpdate()
            ->first();

        if ($wallet === null) {
            $wallet = Wallet::query()->create([
                'user_id' => $referrerUserId,
                'available_balance' => 0,
                'pending_balance' => 0,
                'withdrawn_balance' => 0,
                'lifetime_earnings' => 0,
            ]);
        }

        $wallet->update([
            'available_balance' => round((float) $wallet->available_balance + $bonus, 2),
            'lifetime_earnings' => round((float) $wallet->lifetime_earnings + $bonus, 2),
        ]);

        WalletTransaction::query()->create([
            'user_id' => $referrerUserId,
            'amount' => $bonus,
            'source' => 'SubscriptionBonus',
            'description' => 'Monthly referral subscription bonus',
            'reference' => $subscriptionId,
            'status' => 'Completed',
        ]);

        Notification::query()->create([
            'user_id' => $referrerUserId,
            'title' => 'Subscription Bonus',
            'message' => "You earned {$currency} {$bonus} subscription bonus",
            'type' => 'CommissionEarned',
            'reference_id' => $subscriptionId,
            'is_read' => false,
        ]);
    }
}
