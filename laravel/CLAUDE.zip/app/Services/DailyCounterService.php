<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class DailyCounterService
{
    public function nextSubmissionId(): string
    {
        return DB::transaction(function () {
            $datePart = now()->format('Ymd');
            $counterKey = "submission_{$datePart}";

            $counter = DB::table('daily_counters')
                ->where('counter_key', $counterKey)
                ->lockForUpdate()
                ->first();

            if ($counter === null) {
                DB::table('daily_counters')->insert([
                    'counter_key' => $counterKey,
                    'current_value' => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                $next = 1;
            } else {
                $next = $counter->current_value + 1;
                DB::table('daily_counters')
                    ->where('counter_key', $counterKey)
                    ->update([
                        'current_value' => $next,
                        'updated_at' => now(),
                    ]);
            }

            return sprintf('SUB%s%04d', $datePart, $next);
        });
    }
}
