<?php

namespace App\Services;

use App\Models\CommissionTransaction;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Product;
use App\Models\RevenueTransaction;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class OrderCommissionService
{
    public function __construct(
        private readonly CommissionCalculator $calculator,
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    /**
     * Process referral/system commission when an order is marked Delivered.
     *
     * @return array{skipped: bool, reason?: string, order_id?: string}
     */
    public function processForOrder(Order $order): array
    {
        if ($order->status !== 'Delivered') {
            throw new RuntimeException('Commission can only be processed for Delivered orders');
        }

        if ($order->commission_processed) {
            return ['skipped' => true, 'reason' => 'Commission already processed'];
        }

        return DB::transaction(function () use ($order) {
            /** @var Order $lockedOrder */
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();

            if ($lockedOrder->status !== 'Delivered') {
                throw new RuntimeException('Commission can only be processed for Delivered orders');
            }

            if ($lockedOrder->commission_processed) {
                return ['skipped' => true, 'reason' => 'Commission already processed'];
            }

            $product = $this->resolveProduct($lockedOrder);
            if ($product === null) {
                throw new RuntimeException('Product not found for order');
            }

            $breakdown = $this->calculator->calculateFromProduct($product, (int) $lockedOrder->quantity);
            $lockedOrder->loadMissing('user');
            $referrerUserId = $lockedOrder->user?->referred_by_user_id;

            if ($referrerUserId && $breakdown['referral_share'] > 0) {
                $this->creditReferrerWallet(
                    (int) $referrerUserId,
                    (float) $breakdown['referral_share'],
                    $lockedOrder->id
                );

                CommissionTransaction::query()->create([
                    'order_id' => $lockedOrder->id,
                    'referrer_user_id' => $referrerUserId,
                    'referred_user_id' => $lockedOrder->user_id,
                    'product_profit' => $breakdown['product_profit'],
                    'referral_share' => $breakdown['referral_share'],
                    'system_share' => $breakdown['system_share'],
                    'referral_percent' => $breakdown['referral_percent'],
                    'system_percent' => $breakdown['system_percent'],
                    'status' => 'Completed',
                ]);

                $currency = (string) $this->businessSettings->get('currency', 'GHS');

                Notification::query()->create([
                    'user_id' => $referrerUserId,
                    'title' => 'Commission Earned',
                    'message' => sprintf(
                        'You earned %s %.2f from a referral order',
                        $currency,
                        $breakdown['referral_share']
                    ),
                    'type' => 'CommissionEarned',
                    'reference_id' => $lockedOrder->id,
                    'is_read' => false,
                ]);
            }

            if ($breakdown['system_share'] > 0) {
                RevenueTransaction::query()->create([
                    'source' => 'OrderCommission',
                    'amount' => $breakdown['system_share'],
                    'order_id' => $lockedOrder->id,
                    'description' => "System share for order {$lockedOrder->id}",
                ]);
            }

            $lockedOrder->update(['commission_processed' => true]);

            return [
                'skipped' => false,
                'order_id' => $lockedOrder->id,
            ];
        });
    }

    private function resolveProduct(Order $order): ?Product
    {
        if ($order->product_id) {
            $product = Product::query()->find($order->product_id);
            if ($product !== null) {
                return $product;
            }
        }

        return Product::query()
            ->where('product_name', $order->item_name)
            ->first();
    }

    private function creditReferrerWallet(int $referrerUserId, float $amount, string $orderId): void
    {
        $wallet = Wallet::query()
            ->where('user_id', $referrerUserId)
            ->lockForUpdate()
            ->first();

        if ($wallet === null) {
            Wallet::query()->create([
                'user_id' => $referrerUserId,
                'available_balance' => round($amount, 2),
                'pending_balance' => 0,
                'withdrawn_balance' => 0,
                'lifetime_earnings' => round($amount, 2),
            ]);
        } else {
            $wallet->update([
                'available_balance' => round((float) $wallet->available_balance + $amount, 2),
                'lifetime_earnings' => round((float) $wallet->lifetime_earnings + $amount, 2),
            ]);
        }

        WalletTransaction::query()->create([
            'user_id' => $referrerUserId,
            'amount' => round($amount, 2),
            'source' => 'OrderCommission',
            'description' => "Commission for order {$orderId}",
            'reference' => $orderId,
            'status' => 'Completed',
        ]);
    }
}
