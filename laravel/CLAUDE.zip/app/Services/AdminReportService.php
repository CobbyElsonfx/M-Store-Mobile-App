<?php

namespace App\Services;

use App\Enums\AccountStatus;
use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Models\AgentApplication;
use App\Models\CommissionTransaction;
use App\Models\Order;
use App\Models\Referral;
use App\Models\RevenueTransaction;
use App\Models\Subscription;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WithdrawalRequest;
use Carbon\Carbon;

class AdminReportService
{
    /** @return array{start: Carbon, end: Carbon}|null */
    public function dateRange(string $filter, ?string $customStart = null, ?string $customEnd = null): ?array
    {
        $now = Carbon::now();
        $end = $now->copy()->endOfDay();

        return match ($filter) {
            'today' => ['start' => $now->copy()->startOfDay(), 'end' => $end],
            '7days', 'weekly' => ['start' => $now->copy()->subDays(6)->startOfDay(), 'end' => $end],
            '30days', 'monthly' => ['start' => $now->copy()->subDays(29)->startOfDay(), 'end' => $end],
            'yearly' => ['start' => $now->copy()->startOfYear(), 'end' => $end],
            'custom' => ($customStart && $customEnd)
                ? [
                    'start' => Carbon::parse($customStart)->startOfDay(),
                    'end' => Carbon::parse($customEnd)->endOfDay(),
                ]
                : null,
            default => null,
        };
    }

    /** @return array<string, mixed> */
    public function dashboardStats(): array
    {
        $monthStart = Carbon::now()->startOfMonth();

        return [
            'total_users' => User::query()->where('role', UserRole::Agent)->count(),
            'pending_orders' => Order::query()->where('status', 'Pending')->count(),
            'pending_submissions' => AgentApplication::query()->where('status', 'Pending')->count(),
            'pending_withdrawals' => WithdrawalRequest::query()->where('status', 'Pending')->count(),
            'total_wallet_balance' => round((float) Wallet::query()->sum('available_balance'), 2),
            'monthly_revenue' => round((float) RevenueTransaction::query()
                ->where('created_at', '>=', $monthStart)
                ->sum('amount'), 2),
            'active_subscribers' => User::query()
                ->where('role', UserRole::Agent)
                ->where('subscription_status', SubscriptionStatus::Active)
                ->count(),
            'total_referrals' => Referral::query()->count(),
        ];
    }

    /** @return array<string, mixed> */
    public function buildReport(string $filter, ?string $customStart = null, ?string $customEnd = null): array
    {
        $range = $this->dateRange($filter, $customStart, $customEnd);

        $ordersQuery = Order::query();
        $submissionsQuery = AgentApplication::query()->where('status', '!=', 'Draft');
        $usersQuery = User::query()->where('role', UserRole::Agent);
        $revenueQuery = RevenueTransaction::query();
        $commissionQuery = CommissionTransaction::query();
        $withdrawalsQuery = WithdrawalRequest::query();
        $referralsQuery = Referral::query();
        $subscriptionsQuery = Subscription::query();

        if ($range !== null) {
            $apply = fn ($query) => $query->whereBetween('created_at', [$range['start'], $range['end']]);
            $ordersQuery = $apply($ordersQuery);
            $submissionsQuery = $apply($submissionsQuery);
            $usersQuery = $apply($usersQuery);
            $revenueQuery = $apply($revenueQuery);
            $commissionQuery = $apply($commissionQuery);
            $withdrawalsQuery = $apply($withdrawalsQuery);
            $referralsQuery = $referralsQuery->whereBetween('registration_date', [$range['start'], $range['end']]);
            $subscriptionsQuery = $apply($subscriptionsQuery);
        }

        $newReferrals = (clone $referralsQuery)->count();

        $orders = $ordersQuery->get();
        $commissions = $commissionQuery->get();
        $revenue = $revenueQuery->get();
        $withdrawals = $withdrawalsQuery->get();
        $users = $usersQuery->get();
        $subscriptions = $subscriptionsQuery->get();

        $deliveredOrders = $orders->where('status', 'Delivered');
        $totalSales = round($deliveredOrders->sum(fn ($o) => (float) $o->total_amount), 2);
        $totalRevenue = round($revenue->sum(fn ($t) => (float) $t->amount), 2);
        $subscriptionRevenue = round($revenue->where('source', 'Subscription')->sum(fn ($t) => (float) $t->amount), 2);
        $referralEarnings = round($commissions->sum(fn ($c) => (float) $c->referral_share), 2);
        $withdrawalTotal = round($withdrawals->where('status', 'Paid')->sum(fn ($w) => (float) $w->amount), 2);

        $productCounts = $deliveredOrders
            ->groupBy('item_name')
            ->map(fn ($group) => $group->sum('quantity'))
            ->sortDesc()
            ->take(10);

        $referrerEarnings = $commissions
            ->groupBy('referrer_user_id')
            ->map(fn ($group) => round($group->sum(fn ($c) => (float) $c->referral_share), 2))
            ->sortDesc()
            ->take(10);

        $topReferrers = User::query()
            ->whereIn('id', $referrerEarnings->keys())
            ->get(['id', 'name', 'email', 'first_name', 'last_name'])
            ->keyBy('id');

        return [
            'filter' => $filter,
            'range' => $range,
            'total_sales' => $totalSales,
            'total_orders' => $orders->count(),
            'total_revenue' => $totalRevenue,
            'subscription_revenue' => $subscriptionRevenue,
            'referral_earnings' => $referralEarnings,
            'withdrawal_total' => $withdrawalTotal,
            'new_referrals' => $newReferrals,
            'active_users' => $users->where('account_status', AccountStatus::Active)->count(),
            'suspended_users' => $users->where('account_status', AccountStatus::Suspended)->count(),
            'active_subscriptions' => $subscriptions->where('status', 'Active')->count(),
            'trial_subscriptions' => User::query()
                ->where('role', UserRole::Agent)
                ->where('subscription_status', SubscriptionStatus::Trial)
                ->when($range, fn ($q) => $q->whereBetween('created_at', [$range['start'], $range['end']]))
                ->count(),
            'top_products' => $productCounts,
            'top_referrers' => $referrerEarnings->map(fn ($earnings, $userId) => [
                'user' => $topReferrers->get($userId),
                'earnings' => $earnings,
            ]),
            'orders_by_status' => collect(['Pending', 'Paid', 'Processing', 'Delivered', 'Cancelled'])
                ->mapWithKeys(fn ($status) => [$status => $orders->where('status', $status)->count()]),
        ];
    }
}
