<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Validation\ValidationException;

class SubscriptionAdminService
{
    public function __construct(
        private readonly SubscriptionService $subscriptionService,
    ) {}

    public function changePlan(User $user, string $planId): Subscription
    {
        $this->assertAgent($user);

        $plan = SubscriptionPlan::query()
            ->whereKey($planId)
            ->where('status', 'Active')
            ->first();

        if ($plan === null) {
            throw ValidationException::withMessages([
                'plan_id' => ['Select an active subscription plan.'],
            ]);
        }

        $subscription = $this->subscriptionService->assignPlan(
            $user,
            $plan,
            SubscriptionService::PROVIDER_ADMIN,
            replaceActive: true,
            processReferralBonus: false,
        );

        $this->notify(
            $user,
            'Subscription Updated',
            "Your subscription is now {$plan->plan_name} and is valid until {$subscription->end_date?->format('Y-m-d')}.",
            'General',
            $subscription->id
        );

        return $subscription;
    }

    public function revoke(User $user): void
    {
        $this->assertAgent($user);

        $this->subscriptionService->revokeCurrentSubscription($user);

        $this->notify(
            $user,
            'Subscription Ended',
            'Your subscription has been ended by an administrator.',
            'SubscriptionExpired',
            (string) $user->id
        );
    }

    private function assertAgent(User $user): void
    {
        if ($user->isAdmin()) {
            throw ValidationException::withMessages([
                'plan_id' => ['Admin accounts cannot be modified from this page.'],
            ]);
        }
    }

    private function notify(
        User $user,
        string $title,
        string $message,
        string $type,
        string $referenceId
    ): void {
        Notification::query()->create([
            'user_id' => $user->id,
            'title' => $title,
            'message' => $message,
            'type' => $type,
            'reference_id' => $referenceId,
            'is_read' => false,
        ]);
    }
}
