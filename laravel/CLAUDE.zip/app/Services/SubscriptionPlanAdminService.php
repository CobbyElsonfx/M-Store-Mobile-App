<?php

namespace App\Services;

use App\Models\SubscriptionPlan;
use Illuminate\Support\Str;

class SubscriptionPlanAdminService
{
    /**
     * @param  array{
     *     plan_name: string,
     *     price: float,
     *     duration_days: int,
     *     status: string,
     *     sort_order: int,
     * }  $data
     */
    public function create(array $data): SubscriptionPlan
    {
        return SubscriptionPlan::query()->create([
            'id' => (string) Str::uuid(),
            ...$data,
        ]);
    }

    /**
     * @param  array{
     *     plan_name: string,
     *     price: float,
     *     duration_days: int,
     *     status: string,
     *     sort_order: int,
     * }  $data
     */
    public function update(SubscriptionPlan $plan, array $data): SubscriptionPlan
    {
        $plan->update($data);

        return $plan->fresh();
    }

    public function delete(SubscriptionPlan $plan): void
    {
        $plan->delete();
    }
}
