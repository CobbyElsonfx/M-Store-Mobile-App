<?php

namespace App\Services;

use App\Models\UssdFlowTemplate;
use Illuminate\Database\Eloquent\Collection;

class UssdFlowTemplateService
{
    /** @return Collection<int, UssdFlowTemplate> */
    public function allOrdered(): Collection
    {
        return UssdFlowTemplate::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();
    }

    /** @return Collection<int, UssdFlowTemplate> */
    public function activeForMobile(): Collection
    {
        return UssdFlowTemplate::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();
    }

    public function findByKey(string $flowKey): ?UssdFlowTemplate
    {
        return UssdFlowTemplate::query()
            ->where('flow_key', $flowKey)
            ->first();
    }

    /**
     * @param  list<array{type: string, value?: string|null, hints?: list<string>|null}>  $steps
     */
    public function updateTemplate(UssdFlowTemplate $template, array $data): UssdFlowTemplate
    {
        $template->fill([
            'name' => $data['name'],
            'ussd_code' => $data['ussd_code'],
            'steps' => $data['steps'],
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);
        $template->save();

        return $template->fresh();
    }

    /**
     * @return list<array{type: string, value?: string|null, hints?: list<string>|null}>
     */
    public function parseStepsText(string $raw): array
    {
        $lines = preg_split('/\R/', trim($raw)) ?: [];
        $steps = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }

            $token = strtolower($line);
            $steps[] = match ($token) {
                'phone', '{phone}' => ['type' => 'phone'],
                'phone_confirm', 'confirm_phone', '{phone_confirm}' => ['type' => 'phone_confirm'],
                'amount', '{amount}' => ['type' => 'amount'],
                'reference', '{reference}' => ['type' => 'reference'],
                'stop', 'stop_for_user' => ['type' => 'stop'],
                default => ['type' => 'menu', 'value' => $line],
            };
        }

        return $steps;  
    }

    public function stepsToText(array $steps): string
    {
        $lines = [];
        foreach ($steps as $step) {
            $type = strtolower((string) ($step['type'] ?? 'menu'));
            $lines[] = match ($type) {
                'phone' => 'phone',
                'phone_confirm' => 'phone_confirm',
                'amount' => 'amount',
                'reference' => 'reference',
                'stop' => 'stop',
                default => (string) ($step['value'] ?? ''),
            };
        }

        return implode(PHP_EOL, array_filter($lines, fn (string $line) => $line !== ''));
    }
}
