<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderService
{
    public function __construct(
        private readonly BusinessSettingsService $businessSettings,
    ) {}

    /**
     * @param  array{product_id: string, quantity: int, phone_number: string, location: string}  $data
     */
    public function createForUser(User $user, array $data): Order
    {
        if (! filter_var($this->businessSettings->get('store_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
            throw ValidationException::withMessages([
                'product_id' => ['The store is currently unavailable.'],
            ]);
        }

        return DB::transaction(function () use ($user, $data) {
            /** @var Product $product */
            $product = Product::query()
                ->whereKey($data['product_id'])
                ->lockForUpdate()
                ->firstOrFail();

            if (! $product->is_available) {
                throw ValidationException::withMessages([
                    'product_id' => ['This product is not available for purchase.'],
                ]);
            }

            if ($product->stock_quantity < $data['quantity']) {
                throw ValidationException::withMessages([
                    'quantity' => ["Only {$product->stock_quantity} item(s) left in stock."],
                ]);
            }

            $agentName = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
            if ($agentName === '') {
                $agentName = $user->name;
            }

            return Order::query()->create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'agent_name' => $agentName,
                'item_name' => $product->product_name,
                'quantity' => $data['quantity'],
                'total_amount' => round((float) $product->price * $data['quantity'], 2),
                'phone_number' => $data['phone_number'],
                'location' => $data['location'],
                'status' => 'Pending',
            ]);
        });
    }
}
