<?php

namespace App\Services\Migration;

use Illuminate\Support\Facades\File;

class FirebaseImportService
{
    public function __construct(
        private readonly UsersImporter $usersImporter,
        private readonly CatalogImporter $catalogImporter,
        private readonly BusinessDataImporter $businessImporter,
        private readonly SettingsImporter $settingsImporter,
    ) {}

    /**
     * @return array{export_dir: string, stats: array, manifest: array}
     */
    public function importFromDirectory(string $exportDir): array
    {
        if (! File::isDirectory($exportDir)) {
            throw new \InvalidArgumentException("Export directory not found: {$exportDir}");
        }

        $manifestPath = $exportDir.DIRECTORY_SEPARATOR.'manifest.json';
        if (! File::exists($manifestPath)) {
            throw new \InvalidArgumentException('manifest.json not found in export directory.');
        }

        /** @var array $manifest */
        $manifest = json_decode(File::get($manifestPath), true, 512, JSON_THROW_ON_ERROR);

        if (! ($manifest['read_only'] ?? true)) {
            throw new \RuntimeException('Manifest must indicate read_only export.');
        }

        $ctx = new FirebaseImportContext();

        // Order respects foreign keys
        $this->usersImporter->import($this->loadCollection($exportDir, 'users'), $ctx);
        $this->usersImporter->importAdmins($this->loadCollection($exportDir, 'admins'), $ctx);
        $this->catalogImporter->importSubscriptionPlans($this->loadCollection($exportDir, 'subscription_plans'), $ctx);
        $this->catalogImporter->importProducts($this->loadCollection($exportDir, 'storeProducts'), $ctx);
        $this->businessImporter->importWallets($this->loadCollection($exportDir, 'wallets'), $ctx);
        $this->businessImporter->importSubscriptions($this->loadCollection($exportDir, 'subscriptions'), $ctx);
        $this->businessImporter->linkReferrerForeignKeys($ctx);
        $this->businessImporter->importReferrals($this->loadCollection($exportDir, 'referrals'), $ctx);
        $this->businessImporter->importOrders($this->loadCollection($exportDir, 'storeOrders'), $ctx);
        $this->businessImporter->importWalletTransactions($this->loadCollection($exportDir, 'wallet_transactions'), $ctx);
        $this->businessImporter->importAgentApplications(
            $this->loadCollection($exportDir, 'form_submissions'),
            $ctx,
            'agent_applications'
        );
        $this->businessImporter->importAgentApplications(
            $this->loadCollection($exportDir, 'formSubmissions'),
            $ctx,
            'agent_applications_legacy'
        );
        $this->settingsImporter->importBusinessSettings($this->loadCollection($exportDir, 'business_settings'), $ctx);
        $this->settingsImporter->importAppSettings($this->loadCollection($exportDir, 'appSettings'), $ctx);

        return [
            'export_dir' => $exportDir,
            'stats' => $ctx->stats,
            'manifest' => $manifest,
        ];
    }

    /** @return list<array{id: string, data: array}> */
    private function loadCollection(string $dir, string $name): array
    {
        $path = $dir.DIRECTORY_SEPARATOR.$name.'.json';
        if (! File::exists($path)) {
            return [];
        }

        $payload = json_decode(File::get($path), true);
        if (! is_array($payload)) {
            return [];
        }

        return $payload['documents'] ?? [];
    }

    public function findLatestExportDirectory(): ?string
    {
        $base = storage_path('app/migration/firebase-export');
        if (! File::isDirectory($base)) {
            return null;
        }

        $dirs = collect(File::directories($base))
            ->sort()
            ->values();

        return $dirs->last();
    }
}
