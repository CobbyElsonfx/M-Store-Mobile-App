<?php

namespace App\Services\Migration;

use App\Models\Product;
use App\Models\SubscriptionPlan;
use App\Support\Migration\FirebaseJson;

class CatalogImporter
{
    public function importProducts(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];

                if ($id === '') {
                    $ctx->record('products', 'skipped');
                    continue;
                }

                Product::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'product_name' => FirebaseJson::string($data['productName'] ?? 'Unknown'),
                        'product_description' => FirebaseJson::string($data['productDescription'] ?? ''),
                        'category' => FirebaseJson::string($data['category'] ?? 'SIM Cards'),
                        'price' => FirebaseJson::float($data['price'] ?? 0),
                        'profit' => FirebaseJson::float($data['profit'] ?? 0),
                        'referral_percent' => FirebaseJson::float($data['referralPercent'] ?? 40),
                        'system_percent' => FirebaseJson::float($data['systemPercent'] ?? 60),
                        'stock_quantity' => FirebaseJson::int($data['stockQuantity'] ?? 0),
                        'image_path' => FirebaseJson::string($data['productImageUrl'] ?? null) ?: null,
                        'is_available' => FirebaseJson::bool($data['isAvailable'] ?? true, true),
                    ]
                );

                $ctx->record('products', 'imported');
            } catch (\Throwable $e) {
                if (config('app.debug')) {
                    logger()->error("Product import failed: {$e->getMessage()}");
                }
                $ctx->record('products', 'errors');
            }
        }
    }

    public function importSubscriptionPlans(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];

                if ($id === '') {
                    $ctx->record('subscription_plans', 'skipped');
                    continue;
                }

                SubscriptionPlan::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'plan_name' => FirebaseJson::string($data['planName'] ?? 'Plan'),
                        'price' => FirebaseJson::float($data['price'] ?? 0),
                        'duration_days' => FirebaseJson::int($data['durationDays'] ?? 30),
                        'status' => FirebaseJson::string($data['status'] ?? 'Active'),
                        'sort_order' => FirebaseJson::int($data['sortOrder'] ?? 0),
                    ]
                );

                $ctx->record('subscription_plans', 'imported');
            } catch (\Throwable) {
                $ctx->record('subscription_plans', 'errors');
            }
        }
    }
}
