<?php

namespace App\Services\Migration;

use App\Models\AgentApplication;
use App\Models\ApplicationDocument;
use App\Models\Order;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Support\Migration\FirebaseJson;
use Illuminate\Support\Facades\DB;

class BusinessDataImporter
{
    public function importWallets(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $uid = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];
                $userId = $ctx->resolveUserId($data['userId'] ?? $uid);

                if (! $userId) {
                    $ctx->record('wallets', 'skipped');
                    continue;
                }

                Wallet::query()->updateOrCreate(
                    ['user_id' => $userId],
                    [
                        'available_balance' => FirebaseJson::float($data['availableBalance'] ?? 0),
                        'pending_balance' => FirebaseJson::float($data['pendingBalance'] ?? 0),
                        'withdrawn_balance' => FirebaseJson::float($data['withdrawnBalance'] ?? 0),
                        'lifetime_earnings' => FirebaseJson::float($data['lifetimeEarnings'] ?? 0),
                    ]
                );

                $ctx->record('wallets', 'imported');
            } catch (\Throwable) {
                $ctx->record('wallets', 'errors');
            }
        }
    }

    public function importOrders(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];
                $userId = $ctx->resolveUserId(FirebaseJson::string($data['userId'] ?? ''));

                if ($id === '' || ! $userId) {
                    $ctx->record('orders', 'skipped');
                    continue;
                }

                Order::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'user_id' => $userId,
                        'product_id' => FirebaseJson::string($data['productId'] ?? null) ?: null,
                        'agent_name' => FirebaseJson::string($data['agentName'] ?? ''),
                        'item_name' => FirebaseJson::string($data['itemName'] ?? ''),
                        'quantity' => FirebaseJson::int($data['quantity'] ?? 1, 1),
                        'total_amount' => FirebaseJson::float($data['totalAmount'] ?? 0),
                        'phone_number' => FirebaseJson::string($data['phoneNumber'] ?? ''),
                        'location' => FirebaseJson::string($data['location'] ?? null) ?: null,
                        'status' => FirebaseJson::string($data['status'] ?? 'Pending'),
                        'commission_processed' => FirebaseJson::bool($data['commissionProcessed'] ?? false),
                        'created_at' => FirebaseJson::parseTimestamp($data['createdAt'] ?? null),
                        'updated_at' => FirebaseJson::parseTimestamp($data['updatedAt'] ?? null),
                    ]
                );

                $ctx->record('orders', 'imported');
            } catch (\Throwable) {
                $ctx->record('orders', 'errors');
            }
        }
    }

    public function importSubscriptions(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];
                $userId = $ctx->resolveUserId(FirebaseJson::string($data['userId'] ?? ''));

                $planId = FirebaseJson::string($data['planId'] ?? '');
                if ($id === '' || ! $userId || $planId === '') {
                    $ctx->record('subscriptions', 'skipped');
                    continue;
                }

                if (! SubscriptionPlan::query()->where('id', $planId)->exists()) {
                    $ctx->record('subscriptions', 'skipped');
                    continue;
                }

                Subscription::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'user_id' => $userId,
                        'plan_id' => $planId,
                        'plan_name' => FirebaseJson::string($data['planName'] ?? ''),
                        'price' => FirebaseJson::float($data['price'] ?? 0),
                        'duration_days' => FirebaseJson::int($data['durationDays'] ?? 30),
                        'payment_provider' => FirebaseJson::string($data['paymentProvider'] ?? null) ?: null,
                        'payment_reference' => FirebaseJson::string($data['paymentReference'] ?? null) ?: null,
                        'start_date' => FirebaseJson::parseTimestamp($data['startDate'] ?? null) ?? now(),
                        'end_date' => FirebaseJson::parseTimestamp($data['endDate'] ?? null) ?? now(),
                        'status' => FirebaseJson::string($data['status'] ?? 'Active'),
                    ]
                );

                $ctx->record('subscriptions', 'imported');
            } catch (\Throwable) {
                $ctx->record('subscriptions', 'errors');
            }
        }
    }

    public function importReferrals(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];
                $referrerId = $ctx->resolveUserId(FirebaseJson::string($data['referrerUserId'] ?? ''));
                $referredId = $ctx->resolveUserId(FirebaseJson::string($data['referredUserId'] ?? ''));

                if ($id === '' || ! $referrerId || ! $referredId) {
                    $ctx->record('referrals', 'skipped');
                    continue;
                }

                Referral::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'referrer_user_id' => $referrerId,
                        'referrer_code' => FirebaseJson::string($data['referrerCode'] ?? ''),
                        'referred_user_id' => $referredId,
                        'referred_user_name' => FirebaseJson::string($data['referredUserName'] ?? ''),
                        'registration_date' => FirebaseJson::parseTimestamp($data['registrationDate'] ?? null) ?? now(),
                        'is_active' => FirebaseJson::bool($data['isActive'] ?? true, true),
                        'total_orders' => FirebaseJson::int($data['totalOrders'] ?? 0),
                        'has_active_subscription' => FirebaseJson::bool($data['hasActiveSubscription'] ?? false),
                        'wallet_earnings' => FirebaseJson::float($data['walletEarnings'] ?? 0),
                    ]
                );

                $ctx->record('referrals', 'imported');
            } catch (\Throwable) {
                $ctx->record('referrals', 'errors');
            }
        }
    }

    public function importWalletTransactions(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? $doc['data']['transactionId'] ?? '');
                $data = $doc['data'] ?? [];
                $userId = $ctx->resolveUserId(FirebaseJson::string($data['userId'] ?? ''));

                if ($id === '' || ! $userId) {
                    $ctx->record('wallet_transactions', 'skipped');
                    continue;
                }

                WalletTransaction::query()->updateOrCreate(
                    ['id' => $id],
                    [
                        'user_id' => $userId,
                        'amount' => FirebaseJson::float($data['amount'] ?? 0),
                        'source' => FirebaseJson::string($data['source'] ?? 'Adjustment'),
                        'description' => FirebaseJson::string($data['description'] ?? ''),
                        'reference' => FirebaseJson::string($data['reference'] ?? null) ?: null,
                        'status' => FirebaseJson::string($data['status'] ?? 'Completed'),
                        'created_at' => FirebaseJson::parseTimestamp($data['createdAt'] ?? null),
                    ]
                );

                $ctx->record('wallet_transactions', 'imported');
            } catch (\Throwable) {
                $ctx->record('wallet_transactions', 'errors');
            }
        }
    }

    public function importAgentApplications(array $documents, FirebaseImportContext $ctx, string $label): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? $doc['data']['submissionId'] ?? '');
                $data = $doc['data'] ?? [];
                $userId = $ctx->resolveUserId(FirebaseJson::string($data['userId'] ?? ''));

                if ($id === '' || ! $userId) {
                    $ctx->record($label, 'skipped');
                    continue;
                }

                if (AgentApplication::query()->where('id', $id)->exists()) {
                    $ctx->record($label, 'skipped');
                    continue;
                }

                $formData = is_array($data['formData'] ?? null) ? $data['formData'] : [];
                $documentsMap = is_array($data['documents'] ?? null) ? $data['documents'] : [];

                AgentApplication::query()->create([
                    'id' => $id,
                    'user_id' => $userId,
                    'form_type' => FirebaseJson::string($data['formType'] ?? ''),
                    'applicant_name' => FirebaseJson::string($data['applicantName'] ?? $formData['fullName'] ?? ''),
                    'phone_number' => FirebaseJson::string($data['phoneNumber'] ?? $formData['phoneNumber'] ?? ''),
                    'form_data' => $formData,
                    'status' => FirebaseJson::string($data['status'] ?? 'Pending'),
                    'admin_note' => FirebaseJson::string($data['adminNote'] ?? null) ?: null,
                    'created_at' => FirebaseJson::parseTimestamp($data['createdAt'] ?? null),
                    'updated_at' => FirebaseJson::parseTimestamp($data['updatedAt'] ?? null),
                ]);

                foreach ($documentsMap as $docType => $url) {
                    if (! is_string($url) || $url === '') {
                        continue;
                    }

                    ApplicationDocument::query()->create([
                        'application_id' => $id,
                        'document_type' => $docType,
                        'storage_path' => $url,
                        'mime_type' => null,
                        'file_size' => null,
                        'original_filename' => $docType,
                    ]);
                }

                $ctx->record($label, 'imported');
            } catch (\Throwable) {
                $ctx->record($label, 'errors');
            }
        }
    }

    public function linkReferrerForeignKeys(FirebaseImportContext $ctx): void
    {
        User::query()
            ->whereNotNull('referred_by_code')
            ->whereNull('referred_by_user_id')
            ->each(function ($user) use ($ctx) {
                $referrer = User::query()->where('referral_code', $user->referred_by_code)->first();
                if ($referrer) {
                    $user->update(['referred_by_user_id' => $referrer->id]);
                }
            });
    }
}
