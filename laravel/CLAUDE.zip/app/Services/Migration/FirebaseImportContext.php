<?php

namespace App\Services\Migration;

use App\Models\User;

class FirebaseImportContext
{
    /** @var array<string, int> firebase_uid => laravel user id */
    public array $userIdMap = [];

    /** @var array<string, array{imported: int, skipped: int, errors: int}> */
    public array $stats = [];

    public function record(string $entity, string $result): void
    {
        if (! isset($this->stats[$entity])) {
            $this->stats[$entity] = ['imported' => 0, 'skipped' => 0, 'errors' => 0];
        }

        $this->stats[$entity][$result]++;
    }

    public function resolveUserId(?string $firebaseUid): ?int
    {
        if ($firebaseUid === null || $firebaseUid === '') {
            return null;
        }

        if (isset($this->userIdMap[$firebaseUid])) {
            return $this->userIdMap[$firebaseUid];
        }

        $user = User::query()->where('firebase_uid', $firebaseUid)->first();

        if ($user) {
            $this->userIdMap[$firebaseUid] = $user->id;

            return $user->id;
        }

        return null;
    }

    public function registerUser(string $firebaseUid, int $laravelId): void
    {
        $this->userIdMap[$firebaseUid] = $laravelId;
    }
}
