<?php

namespace App\Services\Migration;

use App\Enums\UserRole;
use App\Models\AgentApplication;
use App\Models\Order;
use App\Models\Product;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\File;

class FirebaseImportVerificationService
{
    /** @var array<string, string> firestore collection => db table/model */
    private const COUNT_MAP = [
        'users' => User::class,
        'admins' => null,
        'storeProducts' => Product::class,
        'storeOrders' => Order::class,
        'form_submissions' => AgentApplication::class,
        'formSubmissions' => null,
        'wallets' => Wallet::class,
        'wallet_transactions' => WalletTransaction::class,
        'subscription_plans' => SubscriptionPlan::class,
        'subscriptions' => Subscription::class,
        'referrals' => Referral::class,
    ];

    /**
     * @return array{passed: bool, rows: list<array>, export_dir: string}
     */
    public function verify(string $exportDir): array
    {
        $manifestPath = $exportDir.DIRECTORY_SEPARATOR.'manifest.json';
        if (! File::exists($manifestPath)) {
            throw new \InvalidArgumentException('manifest.json not found.');
        }

        $manifest = json_decode(File::get($manifestPath), true, 512, JSON_THROW_ON_ERROR);
        $rows = [];
        $passed = true;

        foreach ($manifest['collections'] ?? [] as $collection => $meta) {
            $expected = (int) ($meta['count'] ?? 0);
            $row = [
                'collection' => $collection,
                'firebase_count' => $expected,
                'postgres_count' => null,
                'delta' => null,
                'status' => 'skipped',
                'note' => '',
            ];

            if ($collection === 'admins') {
                $row['postgres_count'] = User::query()->where('role', UserRole::Admin)->count();
                $row['delta'] = $row['postgres_count'] - $expected;
                $row['status'] = $row['delta'] >= 0 ? 'ok' : 'mismatch';
                $row['note'] = 'Admins imported as users.role=admin';
            } elseif ($collection === 'formSubmissions') {
                $row['note'] = 'Legacy collection — merged into agent_applications; not counted separately';
                $row['status'] = 'info';
            } elseif (isset(self::COUNT_MAP[$collection]) && self::COUNT_MAP[$collection]) {
                $model = self::COUNT_MAP[$collection];
                $row['postgres_count'] = $model::query()->count();
                $row['delta'] = $row['postgres_count'] - $expected;
                $row['status'] = $this->matchStatus($collection, $expected, $row['postgres_count']);
            } else {
                $row['note'] = 'Verification mapping not yet implemented';
                $row['status'] = 'pending';
            }

            if (in_array($row['status'], ['mismatch'], true)) {
                $passed = false;
            }

            $rows[] = $row;
        }

        return [
            'passed' => $passed,
            'rows' => $rows,
            'export_dir' => $exportDir,
            'verified_at' => now()->toIso8601String(),
        ];
    }

    private function matchStatus(string $collection, int $expected, int $actual): string
    {
        if ($collection === 'form_submissions') {
            // Legacy duplicates may reduce count — allow actual >= expected after merge
            return $actual >= $expected ? 'ok' : 'mismatch';
        }

        if ($collection === 'users') {
            // Admins may also exist as users — actual can exceed expected
            return $actual >= $expected ? 'ok' : 'mismatch';
        }

        return $actual === $expected ? 'ok' : 'mismatch';
    }
}
