<?php

namespace App\Services\Migration;

use App\Models\BusinessSetting;
use App\Support\Migration\FirebaseJson;
use Illuminate\Support\Facades\DB;

class SettingsImporter
{
    public function importBusinessSettings(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            $data = $doc['data'] ?? [];
            $flat = $this->flattenSettings($data);

            foreach ($flat as $key => $value) {
                BusinessSetting::query()->updateOrCreate(
                    ['key' => $key],
                    ['value' => is_scalar($value) ? (string) $value : json_encode($value)]
                );
            }

            $ctx->record('business_settings', 'imported');
        }
    }

    public function importAppSettings(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            $data = $doc['data'] ?? [];
            $flat = $this->flattenSettings($data);

            foreach ($flat as $key => $value) {
                DB::table('app_settings')->updateOrInsert(
                    ['key' => $key],
                    ['value' => is_scalar($value) ? (string) $value : json_encode($value), 'updated_at' => now(), 'created_at' => now()]
                );
            }

            $ctx->record('app_settings', 'imported');
        }
    }

    /** @return array<string, mixed> */
    private function flattenSettings(array $data): array
    {
        $map = [
            'referralCommissionPercent' => 'referral_commission_percent',
            'systemCommissionPercent' => 'system_commission_percent',
            'monthlySubscriptionBonus' => 'monthly_subscription_bonus',
            'minimumWithdrawal' => 'minimum_withdrawal',
            'trialDays' => 'trial_days',
            'currency' => 'currency',
            'taxRate' => 'tax_rate',
            'storeEnabled' => 'store_enabled',
            'subscriptionEnabled' => 'subscription_enabled',
            'referralShareLinkBase' => 'referral_share_link_base',
        ];

        $out = [];
        foreach ($data as $key => $value) {
            if ($key === 'updatedAt' || $key === 'createdAt') {
                continue;
            }
            $normalized = $map[$key] ?? $key;
            $out[$normalized] = $value;
        }

        return $out;
    }
}
