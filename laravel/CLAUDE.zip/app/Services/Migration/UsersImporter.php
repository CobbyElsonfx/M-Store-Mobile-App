<?php

namespace App\Services\Migration;

use App\Enums\AccountStatus;
use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Models\User;
use App\Support\Migration\FirebaseJson;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UsersImporter
{
    public function import(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $id = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];

                if ($id === '') {
                    $ctx->record('users', 'skipped');
                    continue;
                }

                $email = FirebaseJson::string($data['email'] ?? '');
                if ($email === '') {
                    $email = "imported+{$id}@migration.local";
                }

                $first = FirebaseJson::string($data['firstName'] ?? '');
                $last = FirebaseJson::string($data['lastName'] ?? '');
                $full = FirebaseJson::string($data['fullName'] ?? trim("{$first} {$last}"));

                $user = User::query()->updateOrCreate(
                    ['firebase_uid' => $id],
                    [
                        'email' => $email,
                        'name' => $full !== '' ? $full : $email,
                        'password' => Hash::make(Str::random(40)),
                        'role' => UserRole::Agent,
                        'first_name' => $first,
                        'last_name' => $last,
                        'phone_number' => FirebaseJson::string($data['phoneNumber'] ?? null),
                        'location' => FirebaseJson::string($data['location'] ?? null),
                        'account_status' => AccountStatus::tryFrom(
                            FirebaseJson::string($data['accountStatus'] ?? 'Active', 'Active')
                        ) ?? AccountStatus::Active,
                        'referral_code' => FirebaseJson::string($data['referralCode'] ?? null) ?: null,
                        'referred_by_code' => FirebaseJson::string($data['referredBy'] ?? null) ?: null,
                        'referral_date' => FirebaseJson::parseTimestamp($data['referralDate'] ?? null),
                        'trial_start_date' => FirebaseJson::parseTimestamp($data['trialStartDate'] ?? null),
                        'trial_end_date' => FirebaseJson::parseTimestamp($data['trialEndDate'] ?? null),
                        'is_trial_used' => FirebaseJson::bool($data['isTrialUsed'] ?? false),
                        'subscription_status' => SubscriptionStatus::tryFrom(
                            FirebaseJson::string($data['subscriptionStatus'] ?? 'None', 'None')
                        ) ?? SubscriptionStatus::None,
                        'subscription_expiry_date' => FirebaseJson::parseTimestamp($data['subscriptionExpiryDate'] ?? null),
                        'active_subscription_id' => FirebaseJson::string($data['activeSubscriptionId'] ?? null) ?: null,
                    ]
                );

                $ctx->registerUser($id, $user->id);
                $ctx->record('users', 'imported');
            } catch (\Throwable) {
                $ctx->record('users', 'errors');
            }
        }
    }

    public function importAdmins(array $documents, FirebaseImportContext $ctx): void
    {
        foreach ($documents as $doc) {
            try {
                $uid = FirebaseJson::string($doc['id'] ?? '');
                $data = $doc['data'] ?? [];
                $email = FirebaseJson::string($data['email'] ?? "admin+{$uid}@migration.local");

                $user = User::query()->updateOrCreate(
                    ['firebase_uid' => $uid],
                    [
                        'email' => $email,
                        'name' => FirebaseJson::string($data['name'] ?? 'Admin'),
                        'password' => Hash::make(Str::random(40)),
                        'role' => UserRole::Admin,
                    ]
                );

                $ctx->registerUser($uid, $user->id);
                $ctx->record('admins', 'imported');
            } catch (\Throwable) {
                $ctx->record('admins', 'errors');
            }
        }
    }
}
