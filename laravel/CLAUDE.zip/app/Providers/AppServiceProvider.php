<?php

namespace App\Providers;

use App\Events\AccountInformationUpdated;
use App\Events\AccountSuspended;
use App\Events\ApplicationStatusChanged;
use App\Events\ApplicationSubmitted;
use App\Events\PaymentAbandoned;
use App\Events\PaymentFailed;
use App\Events\PaymentSuccessful;
use App\Events\SubscriptionActivated;
use App\Events\SubscriptionExpired;
use App\Events\SubscriptionExpiringSoon;
use App\Events\SubscriptionRenewed;
use App\Events\UserRegistered;
use App\Listeners\SendDomainEmailNotifications;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        foreach ([
            UserRegistered::class,
            AccountInformationUpdated::class,
            AccountSuspended::class,
            SubscriptionActivated::class,
            SubscriptionRenewed::class,
            SubscriptionExpired::class,
            SubscriptionExpiringSoon::class,
            PaymentSuccessful::class,
            PaymentFailed::class,
            PaymentAbandoned::class,
            ApplicationSubmitted::class,
            ApplicationStatusChanged::class,
        ] as $event) {
            Event::listen($event, SendDomainEmailNotifications::class);
        }
    }
}

