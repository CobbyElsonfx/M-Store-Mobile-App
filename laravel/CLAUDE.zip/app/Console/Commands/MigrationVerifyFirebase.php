<?php

namespace App\Console\Commands;

use App\Services\Migration\FirebaseImportService;
use App\Services\Migration\FirebaseImportVerificationService;
use Illuminate\Console\Command;

class MigrationVerifyFirebase extends Command
{
    protected $signature = 'migration:verify-firebase
                            {--dir= : Path to export directory containing manifest.json}
                            {--latest : Use the latest export directory}
                            {--report= : Optional path to write JSON verification report}';

    protected $description = 'Verify PostgreSQL import counts against Firebase export manifest';

    public function handle(
        FirebaseImportService $importService,
        FirebaseImportVerificationService $verificationService,
    ): int {
        $dir = $this->option('dir');

        if ($this->option('latest') || ! $dir) {
            $dir = $importService->findLatestExportDirectory();
            if (! $dir) {
                $this->error('No export directory found.');

                return self::FAILURE;
            }
        }

        $this->info("Verifying against export: {$dir}");

        try {
            $report = $verificationService->verify($dir);
        } catch (\Throwable $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        $this->table(
            ['Collection', 'Firebase', 'PostgreSQL', 'Delta', 'Status', 'Note'],
            collect($report['rows'])->map(fn ($r) => [
                $r['collection'],
                $r['firebase_count'],
                $r['postgres_count'] ?? '—',
                $r['delta'] ?? '—',
                $r['status'],
                $r['note'] ?? '',
            ])->all()
        );

        if ($path = $this->option('report')) {
            file_put_contents($path, json_encode($report, JSON_PRETTY_PRINT));
            $this->info("Report written to {$path}");
        }

        if ($report['passed']) {
            $this->info('Verification PASSED (within expected tolerances).');

            return self::SUCCESS;
        }

        $this->warn('Verification reported mismatches — review before module cutover.');

        return self::FAILURE;
    }
}
