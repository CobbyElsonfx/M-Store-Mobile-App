<?php

namespace App\Console\Commands;

use App\Services\Migration\FirebaseImportService;
use Illuminate\Console\Command;

class MigrationImportFirebase extends Command
{
    protected $signature = 'migration:import-firebase
                            {--dir= : Path to export directory containing manifest.json}
                            {--latest : Use the latest export in storage/app/migration/firebase-export}';

    protected $description = 'Import read-only Firebase JSON export into PostgreSQL (idempotent upsert)';

    public function handle(FirebaseImportService $importService): int
    {
        $dir = $this->option('dir');

        if ($this->option('latest') || ! $dir) {
            $dir = $importService->findLatestExportDirectory();
            if (! $dir) {
                $this->error('No export directory found. Copy a Firebase JSON export into storage/app/migration/firebase-export/.');

                return self::FAILURE;
            }
        }

        $this->info("Importing from: {$dir}");
        $this->warn('Firebase is NOT modified. This imports a local JSON snapshot only.');

        try {
            $result = $importService->importFromDirectory($dir);
        } catch (\Throwable $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        $this->newLine();
        $this->table(
            ['Entity', 'Imported', 'Skipped', 'Errors'],
            collect($result['stats'])->map(fn ($s, $entity) => [
                $entity,
                $s['imported'] ?? 0,
                $s['skipped'] ?? 0,
                $s['errors'] ?? 0,
            ])->values()->all()
        );

        $this->newLine();
        $this->info('Import complete. Run migration:verify-firebase to reconcile counts.');

        return self::SUCCESS;
    }
}
