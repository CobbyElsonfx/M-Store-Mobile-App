<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class SubmitApplicationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'form_type' => ['required', 'string', 'max:120'],
            'form_data' => ['required', 'array'],
            'form_data.*' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
