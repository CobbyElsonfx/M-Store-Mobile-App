<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class StoreSubscriptionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'plan_id' => ['required', 'string', 'exists:subscription_plans,id'],
            'payment_provider' => ['required', 'string', 'max:30'],
            'payment_reference' => ['required', 'string', 'max:120'],
        ];
    }
}
