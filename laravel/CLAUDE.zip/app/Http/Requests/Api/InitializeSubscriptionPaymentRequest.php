<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class InitializeSubscriptionPaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        if (! $this->filled('subscription_plan_id') && $this->filled('plan_id')) {
            $this->merge([
                'subscription_plan_id' => $this->input('plan_id'),
            ]);
        }
    }

    public function rules(): array
    {
        return [
            'subscription_plan_id' => ['required', 'string', 'exists:subscription_plans,id'],
        ];
    }
}
