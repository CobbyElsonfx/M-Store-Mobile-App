<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Referral;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ReferralController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('search')->toString());
        $subscriptionFilter = $request->string('subscription')->toString();

        $referrals = Referral::query()
            ->with([
                'referrer:id,name,email,first_name,last_name',
                'referredUser:id,name,email,first_name,last_name,subscription_status',
            ])
            ->when($subscriptionFilter === 'active', fn ($q) => $q->where('has_active_subscription', true))
            ->when($subscriptionFilter === 'inactive', fn ($q) => $q->where('has_active_subscription', false))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('referrer_code', 'like', "%{$search}%")
                        ->orWhere('referred_user_name', 'like', "%{$search}%")
                        ->orWhereHas('referrer', fn ($u) => $u->where('email', 'like', "%{$search}%"))
                        ->orWhereHas('referredUser', fn ($u) => $u->where('email', 'like', "%{$search}%"));
                });
            })
            ->orderByDesc('registration_date')
            ->paginate(25)
            ->withQueryString();

        return view('admin.referrals.index', [
            'title' => 'Referrals',
            'referrals' => $referrals,
            'search' => $search,
            'subscriptionFilter' => $subscriptionFilter !== '' ? $subscriptionFilter : 'all',
        ]);
    }
}
