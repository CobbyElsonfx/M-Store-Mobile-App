<?php

namespace App\Http\Controllers\Admin;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\AuditLogService;
use App\Services\NotificationAdminService;
use App\Support\AuditActions;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NotificationController extends Controller
{
    public function __construct(
        private readonly NotificationAdminService $notificationAdminService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function create(Request $request): View
    {
        $search = trim($request->string('user_search')->toString());

        $users = User::query()
            ->where('role', UserRole::Agent)
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%");
                });
            })
            ->orderBy('name')
            ->limit(20)
            ->get(['id', 'name', 'email', 'first_name', 'last_name', 'phone_number']);

        return view('admin.notifications.create', [
            'title' => 'Notifications',
            'users' => $users,
            'userSearch' => $search,
            'targets' => [
                'all' => 'All Users',
                'subscribers' => 'Subscribers',
                'trial' => 'Trial Users',
                'specific' => 'Specific User',
            ],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'target' => ['required', 'in:all,subscribers,trial,specific'],
            'user_id' => ['nullable', 'integer', 'exists:users,id'],
            'title' => ['required', 'string', 'min:2', 'max:255'],
            'message' => ['required', 'string', 'min:2', 'max:2000'],
        ]);

        if ($validated['target'] === 'specific') {
            if (empty($validated['user_id'])) {
                return back()
                    ->withInput()
                    ->withErrors(['user_id' => 'Select a user to notify.']);
            }

            $this->notificationAdminService->sendToUser(
                (int) $validated['user_id'],
                $validated['title'],
                $validated['message']
            );

            $sent = 1;
        } else {
            $sent = $this->notificationAdminService->sendBulk(
                $validated['target'],
                $validated['title'],
                $validated['message']
            );
        }

        $this->auditLogService->record(
            $request->user(),
            AuditActions::NOTIFICATION_SENT,
            'notification',
            null,
            null,
            [
                'target' => $validated['target'],
                'user_id' => $validated['user_id'] ?? null,
                'title' => $validated['title'],
                'recipient_count' => $sent,
            ],
            $request
        );

        return redirect()
            ->route('admin.notifications.create')
            ->with('status', "Notification sent to {$sent} user(s).");
    }
}
