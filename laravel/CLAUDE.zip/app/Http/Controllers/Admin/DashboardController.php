<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\AdminReportService;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __construct(
        private readonly AdminReportService $reportService,
    ) {}

    public function index(): View
    {
        return view('admin.dashboard', [
            'title' => 'MoMo Kotle Admin',
            'stats' => $this->reportService->dashboardStats(),
        ]);
    }
}
