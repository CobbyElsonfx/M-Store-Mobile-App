<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OrderCommissionService;
use App\Services\AuditLogService;
use App\Support\AuditActions;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class OrderController extends Controller
{
    private const STATUSES = ['Pending', 'Paid', 'Processing', 'Delivered', 'Cancelled'];

    public function __construct(
        private readonly OrderCommissionService $commissionService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('search')->toString());

        $orders = Order::query()
            ->with(['user:id,name,email', 'product:id,product_name'])
            ->when($status !== '' && $status !== 'all', fn ($query) => $query->where('status', $status))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('agent_name', 'like', "%{$search}%")
                        ->orWhere('item_name', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%")
                        ->orWhere('location', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.orders.index', [
            'title' => 'Orders',
            'orders' => $orders,
            'statuses' => self::STATUSES,
            'statusFilter' => $status !== '' ? $status : 'all',
            'search' => $search,
        ]);
    }

    public function updateStatus(Request $request, Order $order): RedirectResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:'.implode(',', self::STATUSES)],
        ]);

        $previousStatus = $order->status;
        $order->update(['status' => $validated['status']]);

        if ($validated['status'] === 'Delivered' && $previousStatus !== 'Delivered') {
            $this->commissionService->processForOrder($order->fresh());
        }

        $this->auditLogService->record(
            $request->user(),
            AuditActions::ORDER_STATUS_CHANGE,
            'order',
            $order->id,
            $previousStatus,
            $validated['status'],
            $request
        );

        return redirect()
            ->route('admin.orders.index', array_filter([
                'status' => $request->input('return_status'),
                'search' => $request->input('return_search'),
                'page' => $request->input('return_page'),
            ], fn ($value) => $value !== null && $value !== ''))
            ->with('status', 'Order status updated.');
    }
}
