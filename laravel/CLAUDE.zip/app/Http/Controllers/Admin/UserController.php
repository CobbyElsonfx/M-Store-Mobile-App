<?php

namespace App\Http\Controllers\Admin;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Models\AgentApplication;
use App\Models\Order;
use App\Models\Referral;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Services\AuditLogService;
use App\Services\SubscriptionAdminService;
use App\Services\UserAdminService;
use App\Support\AuditActions;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class UserController extends Controller
{
    public function __construct(
        private readonly UserAdminService $userAdminService,
        private readonly SubscriptionAdminService $subscriptionAdminService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('search')->toString());

        $users = User::query()
            ->where('role', UserRole::Agent)
            ->with('wallet')
            ->withCount(['referralsMade', 'orders', 'agentApplications'])
            ->when($status !== '' && $status !== 'all', function ($query) use ($status) {
                $query->where('account_status', $status);
            })
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%")
                        ->orWhere('referral_code', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.users.index', [
            'title' => 'Users',
            'users' => $users,
            'statuses' => ['Active', 'Suspended'],
            'statusFilter' => $status !== '' ? $status : 'all',
            'search' => $search,
        ]);
    }

    public function show(User $user): View
    {
        $this->ensureAgent($user);

        $user->load([
            'wallet',
            'referrer:id,name,email,first_name,last_name',
            'activeSubscription',
            'subscriptions' => fn ($query) => $query->orderByDesc('created_at')->limit(20),
        ]);

        return view('admin.users.show', [
            'title' => 'User '.$user->email,
            'user' => $user,
            'plans' => SubscriptionPlan::query()
                ->where('status', 'Active')
                ->orderBy('sort_order')
                ->orderBy('duration_days')
                ->get(),
            'stats' => [
                'orders' => Order::query()->where('user_id', $user->id)->count(),
                'submissions' => AgentApplication::query()
                    ->where('user_id', $user->id)
                    ->where('status', '!=', 'Draft')
                    ->count(),
                'referrals' => Referral::query()->where('referrer_user_id', $user->id)->count(),
                'wallet' => Wallet::query()->where('user_id', $user->id)->first(),
            ],
        ]);
    }

    public function updateStatus(Request $request, User $user): RedirectResponse
    {
        $this->ensureAgent($user);

        $validated = $request->validate([
            'account_status' => ['required', 'in:Active,Suspended'],
        ]);

        $previousStatus = $user->account_status;

        $this->userAdminService->updateAccountStatus($user, $validated['account_status']);

        $action = $validated['account_status'] === 'Suspended'
            ? AuditActions::USER_SUSPENSION
            : AuditActions::USER_ACTIVATION;

        $this->auditLogService->record(
            $request->user(),
            $action,
            'user',
            $user->id,
            $previousStatus,
            $validated['account_status'],
            $request
        );

        return redirect()
            ->route('admin.users.show', $user)
            ->with('status', 'Account status updated.');
    }

    public function updateSubscription(Request $request, User $user): RedirectResponse
    {
        $this->ensureAgent($user);

        $validated = $request->validate([
            'action' => ['required', 'in:grant,revoke'],
            'plan_id' => ['required_if:action,grant', 'nullable', 'string'],
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ]);

        $previous = $this->subscriptionSnapshot($user);

        if ($validated['action'] === 'revoke') {
            $this->subscriptionAdminService->revoke($user);

            $this->auditLogService->record(
                $request->user(),
                AuditActions::SUBSCRIPTION_REVOKE,
                'user',
                (string) $user->id,
                $previous,
                [
                    'status' => 'Expired',
                    'admin_note' => $validated['admin_note'] ?? null,
                ],
                $request
            );

            return redirect()
                ->route('admin.users.show', $user)
                ->with('status', 'Subscription ended.');
        }

        $subscription = $this->subscriptionAdminService->changePlan($user, (string) $validated['plan_id']);

        $this->auditLogService->record(
            $request->user(),
            AuditActions::SUBSCRIPTION_CHANGE,
            'user',
            (string) $user->id,
            $previous,
            [
                'status' => 'Active',
                'plan' => $subscription->plan_name,
                'expires' => $subscription->end_date?->toIso8601String(),
                'admin_note' => $validated['admin_note'] ?? null,
            ],
            $request
        );

        return redirect()
            ->route('admin.users.show', $user)
            ->with('status', 'Subscription updated.');
    }

    /** @return array{status: string|null, plan: string|null, expires: string|null} */
    private function subscriptionSnapshot(User $user): array
    {
        $user->loadMissing('activeSubscription');

        return [
            'status' => $user->subscription_status?->value,
            'plan' => $user->activeSubscription?->plan_name,
            'expires' => $user->subscription_expiry_date?->toIso8601String(),
        ];
    }

    private function ensureAgent(User $user): void
    {
        if ($user->role !== UserRole::Agent) {
            abort(404);
        }
    }
}
