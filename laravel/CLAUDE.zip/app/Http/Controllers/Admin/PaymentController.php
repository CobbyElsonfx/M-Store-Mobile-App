<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PaymentController extends Controller
{
    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('search')->toString());

        $payments = Payment::query()
            ->with([
                'user:id,name,email,first_name,last_name,subscription_expiry_date',
                'plan:id,plan_name',
                'subscription:id,payment_reference,start_date,end_date,status',
            ])
            ->when($status !== '' && $status !== 'all', fn ($q) => $q->where('status', $status))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('reference', 'like', "%{$search}%")
                        ->orWhere('provider_reference', 'like', "%{$search}%")
                        ->orWhereHas('user', fn ($u) => $u->where('email', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%"));
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.payments.index', [
            'title' => 'Payments',
            'payments' => $payments,
            'statuses' => ['Pending', 'Ongoing', 'Confirmed', 'Failed', 'Abandoned', 'Reversed'],
            'statusFilter' => $status !== '' ? $status : 'all',
            'search' => $search,
        ]);
    }
}
