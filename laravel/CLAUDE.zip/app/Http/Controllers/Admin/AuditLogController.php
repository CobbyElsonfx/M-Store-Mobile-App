<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Support\AuditActions;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AuditLogController extends Controller
{
    public function index(Request $request): View
    {
        $action = $request->string('action')->toString();

        $logs = AuditLog::query()
            ->with('admin:id,name,email')
            ->when($action !== '' && $action !== 'all', fn ($query) => $query->where('action', $action))
            ->orderByDesc('created_at')
            ->paginate(50)
            ->withQueryString();

        return view('admin.audit-log.index', [
            'title' => 'Audit Log',
            'logs' => $logs,
            'actions' => AuditActions::labels(),
            'actionFilter' => $action !== '' ? $action : 'all',
        ]);
    }
}
