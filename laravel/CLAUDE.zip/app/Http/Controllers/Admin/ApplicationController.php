<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AgentApplication;
use App\Models\ApplicationDocument;
use App\Services\ApplicationAdminService;
use App\Services\ApplicationService;
use App\Services\AuditLogService;
use App\Support\AuditActions;
use App\Support\SubmissionLabels;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ApplicationController extends Controller
{
    public function __construct(
        private readonly ApplicationAdminService $applicationAdminService,
        private readonly ApplicationService $applicationService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $formType = $request->string('form_type')->toString();
        $search = trim($request->string('search')->toString());

        $applications = AgentApplication::query()
            ->with('user:id,name,email')
            ->where('status', '!=', 'Draft')
            ->when($status !== '' && $status !== 'all', fn ($query) => $query->where('status', $status))
            ->when($formType !== '' && $formType !== 'all', fn ($query) => $query->where('form_type', $formType))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('id', 'like', "%{$search}%")
                        ->orWhere('applicant_name', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.submissions.index', [
            'title' => 'Submissions',
            'applications' => $applications,
            'formTypes' => SubmissionLabels::FORM_TYPES,
            'statuses' => SubmissionLabels::STATUSES,
            'statusFilter' => $status !== '' ? $status : 'all',
            'formTypeFilter' => $formType !== '' ? $formType : 'all',
            'search' => $search,
        ]);
    }

    public function show(AgentApplication $application): View|RedirectResponse
    {
        if ($application->status === 'Draft') {
            abort(404);
        }

        $application->load(['documents', 'user:id,name,email,phone_number']);

        return view('admin.submissions.show', [
            'title' => 'Submission '.$application->id,
            'application' => $application,
            'statuses' => SubmissionLabels::STATUSES,
            'formFieldLabels' => SubmissionLabels::FORM_FIELD_LABELS,
            'documentLabels' => SubmissionLabels::DOCUMENT_LABELS,
        ]);
    }

    public function updateStatus(Request $request, AgentApplication $application): RedirectResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:'.implode(',', SubmissionLabels::STATUSES)],
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ]);

        $previousStatus = $application->status;

        $this->applicationAdminService->updateStatus(
            $application,
            $validated['status'],
            $validated['admin_note'] ?? ''
        );

        $action = match ($validated['status']) {
            'Approved' => AuditActions::APPLICATION_APPROVAL,
            'Rejected' => AuditActions::APPLICATION_REJECTION,
            default => AuditActions::APPLICATION_STATUS_CHANGE,
        };

        $this->auditLogService->record(
            $request->user(),
            $action,
            'application',
            $application->id,
            $previousStatus,
            $validated['status'],
            $request
        );

        return redirect()
            ->route('admin.submissions.show', $application)
            ->with('status', 'Submission status updated.');
    }

    public function document(
        AgentApplication $application,
        string $documentType
    ): BinaryFileResponse {
        $path = $this->applicationService->adminDocumentDownloadPath($application, $documentType);

        $document = ApplicationDocument::query()
            ->where('application_id', $application->id)
            ->where('document_type', $documentType)
            ->firstOrFail();

        $mime = $document->mime_type ?: (mime_content_type($path) ?: 'application/octet-stream');
        $filename = $document->original_filename ?: basename($path);
        $disposition = str_starts_with($mime, 'image/') ? 'inline' : 'attachment';

        return response()->file($path, [
            'Content-Type' => $mime,
            'Content-Disposition' => "{$disposition}; filename=\"{$filename}\"",
        ]);
    }
}
