<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WalletController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('search')->toString());

        $wallets = Wallet::query()
            ->with('user:id,name,email,first_name,last_name,phone_number')
            ->when($search !== '', function ($query) use ($search) {
                $query->whereHas('user', function ($userQuery) use ($search) {
                    $userQuery->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%")
                        ->orWhere('phone_number', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('updated_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.wallets.index', [
            'title' => 'Wallets',
            'wallets' => $wallets,
            'search' => $search,
        ]);
    }

    public function show(Wallet $wallet): View
    {
        $wallet->load('user:id,name,email,first_name,last_name,phone_number');

        $transactions = WalletTransaction::query()
            ->where('user_id', $wallet->user_id)
            ->orderByDesc('created_at')
            ->limit(50)
            ->get();

        return view('admin.wallets.show', [
            'title' => 'Wallet',
            'wallet' => $wallet,
            'transactions' => $transactions,
        ]);
    }
}
