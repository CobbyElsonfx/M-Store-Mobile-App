<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\AdminReportService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ReportController extends Controller
{
    public function __construct(
        private readonly AdminReportService $reportService,
    ) {}

    public function index(Request $request): View
    {
        $filter = $request->string('filter')->toString() ?: 'monthly';
        $customStart = $request->string('start_date')->toString();
        $customEnd = $request->string('end_date')->toString();

        $report = $this->reportService->buildReport(
            $filter,
            $customStart ?: null,
            $customEnd ?: null
        );

        return view('admin.reports.index', [
            'title' => 'Reports',
            'report' => $report,
            'filter' => $filter,
            'startDate' => $customStart,
            'endDate' => $customEnd,
            'filters' => [
                'today' => 'Today',
                '7days' => 'Last 7 days',
                'monthly' => 'Last 30 days',
                'yearly' => 'This year',
                'custom' => 'Custom range',
            ],
        ]);
    }
}
