<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\AuditLogService;
use App\Services\BusinessSettingsAdminService;
use App\Support\AuditActions;
use App\Support\PaystackSecrets;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BusinessSettingsController extends Controller
{
    public function __construct(
        private readonly BusinessSettingsAdminService $businessSettingsAdminService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function edit(): View
    {
        return view('admin.settings.business', [
            'title' => 'Business Settings',
            'settings' => $this->businessSettingsAdminService->formValues(),
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $request->merge([
            'paystack_public_key' => $this->nullableTrim($request->input('paystack_public_key')),
            'paystack_secret_key' => $this->nullableTrim($request->input('paystack_secret_key')),
            'paystack_base_url' => $this->nullableTrim($request->input('paystack_base_url')),
        ]);
        $validated = $request->validate([
            'referral_commission_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'system_commission_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'monthly_subscription_bonus' => ['required', 'numeric', 'min:0'],
            'minimum_withdrawal' => ['required', 'numeric', 'min:0'],
            'trial_days' => ['required', 'integer', 'min:0'],
            'currency' => ['required', 'string', 'max:10'],
            'tax_rate' => ['required', 'numeric', 'min:0', 'max:100'],
            'referral_share_link_base' => ['required', 'url'],
            'support_contact' => ['nullable', 'string', 'max:255'],
            'paystack_public_key' => ['nullable', 'string', 'max:255', 'regex:/^pk_(test|live)_[A-Za-z0-9]+$/'],
            'paystack_secret_key' => ['nullable', 'string', 'max:255', 'regex:/^sk_(test|live)_[A-Za-z0-9]+$/'],
            'paystack_base_url' => ['nullable', 'url', 'max:255'],
            'subscription_reminder_days' => ['nullable', 'string', 'max:40'],
            'admin_notification_emails' => ['nullable', 'string', 'max:2000'],
        ]);

        $previousSettings = $this->businessSettingsAdminService->formValues();

        $payload = [
            'referral_commission_percent' => round((float) $validated['referral_commission_percent'], 2),
            'system_commission_percent' => round((float) $validated['system_commission_percent'], 2),
            'monthly_subscription_bonus' => round((float) $validated['monthly_subscription_bonus'], 2),
            'minimum_withdrawal' => round((float) $validated['minimum_withdrawal'], 2),
            'trial_days' => (int) $validated['trial_days'],
            'currency' => $validated['currency'],
            'tax_rate' => round((float) $validated['tax_rate'], 2),
            'referral_share_link_base' => $validated['referral_share_link_base'],
            'support_contact' => $validated['support_contact'] ?? '',
            'store_enabled' => $request->boolean('store_enabled'),
            'subscription_enabled' => $request->boolean('subscription_enabled'),
            'maintenance_mode' => $request->boolean('maintenance_mode'),
        ];

        if ($request->exists('subscription_reminder_days') || $request->exists('admin_notification_emails')) {
            $payload['email_reminders_enabled'] = $request->boolean('email_reminders_enabled');
            $payload['email_admin_alerts_enabled'] = $request->boolean('email_admin_alerts_enabled');
            $payload['subscription_reminder_days'] = $this->reminderDays($validated['subscription_reminder_days'] ?? '7,3,1');
            $payload['admin_notification_emails'] = $validated['admin_notification_emails'] ?? '';
        }

        $publicKey = trim((string) ($validated['paystack_public_key'] ?? ''));
        if ($publicKey !== '') {
            $payload['paystack_public_key'] = $publicKey;
        }

        $secretKey = trim((string) ($validated['paystack_secret_key'] ?? ''));
        if ($secretKey !== '') {
            $payload['paystack_secret_key'] = PaystackSecrets::encrypt($secretKey);
        }

        $baseUrl = trim((string) ($validated['paystack_base_url'] ?? ''));
        if ($baseUrl !== '') {
            $payload['paystack_base_url'] = $baseUrl;
        }

        $this->businessSettingsAdminService->update($payload);

        $this->auditLogService->record(
            $request->user(),
            AuditActions::BUSINESS_SETTINGS_CHANGE,
            'business_settings',
            'global',
            $previousSettings,
            $this->businessSettingsAdminService->formValues(),
            $request
        );

        return redirect()
            ->route('admin.settings.business.edit')
            ->with('status', 'Business settings saved.');
    }

    private function nullableTrim(mixed $value): ?string
    {
        $trimmed = trim((string) $value);

        return $trimmed === '' ? null : $trimmed;
    }

    private function reminderDays(string $raw): string
    {
        $days = array_values(array_unique(array_filter(
            array_map('intval', preg_split('/[\s,;]+/', $raw, -1, PREG_SPLIT_NO_EMPTY) ?: []),
            fn (int $day) => $day > 0 && $day <= 90
        )));

        return $days === [] ? '7,3,1' : implode(',', $days);
    }
}
