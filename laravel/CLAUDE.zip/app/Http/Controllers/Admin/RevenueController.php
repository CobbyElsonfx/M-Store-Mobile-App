<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RevenueTransaction;
use Illuminate\Http\Request;
use Illuminate\View\View;

class RevenueController extends Controller
{
    private const SOURCES = ['OrderCommission', 'Subscription'];

    public function index(Request $request): View
    {
        $source = $request->string('source')->toString();
        $startDate = $request->string('start_date')->toString();
        $endDate = $request->string('end_date')->toString();

        $query = RevenueTransaction::query()->orderByDesc('created_at');

        if ($source !== '' && $source !== 'all') {
            $query->where('source', $source);
        }

        if ($startDate !== '') {
            $query->whereDate('created_at', '>=', $startDate);
        }

        if ($endDate !== '') {
            $query->whereDate('created_at', '<=', $endDate);
        }

        $transactions = (clone $query)->paginate(25)->withQueryString();

        $summaryRows = (clone $query)->get(['source', 'amount']);
        $total = round($summaryRows->sum(fn ($row) => (float) $row->amount), 2);
        $bySource = $summaryRows
            ->groupBy('source')
            ->map(fn ($rows) => round($rows->sum(fn ($row) => (float) $row->amount), 2))
            ->all();

        return view('admin.revenue.index', [
            'title' => 'Revenue',
            'transactions' => $transactions,
            'summary' => [
                'total' => $total,
                'transaction_count' => $summaryRows->count(),
                'by_source' => $bySource,
            ],
            'sources' => self::SOURCES,
            'sourceFilter' => $source !== '' ? $source : 'all',
            'startDate' => $startDate,
            'endDate' => $endDate,
        ]);
    }
}
