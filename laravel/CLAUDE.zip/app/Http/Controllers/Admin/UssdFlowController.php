<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\UssdFlowTemplate;
use App\Services\AuditLogService;
use App\Services\UssdFlowTemplateService;
use App\Support\AuditActions;
use App\Support\UssdFlowDefaults;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class UssdFlowController extends Controller
{
    public function __construct(
        private readonly UssdFlowTemplateService $ussdFlowTemplateService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(): View
    {
        return view('admin.ussd-flows.index', [
            'title' => 'USSD Flows',
            'flows' => $this->ussdFlowTemplateService->allOrdered(),
        ]);
    }

    public function edit(UssdFlowTemplate $ussdFlow): View
    {
        return view('admin.ussd-flows.edit', [
            'title' => 'Edit USSD Flow',
            'flow' => $ussdFlow,
            'stepsText' => $this->ussdFlowTemplateService->stepsToText($ussdFlow->steps ?? []),
        ]);
    }

    public function update(Request $request, UssdFlowTemplate $ussdFlow): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'ussd_code' => ['required', 'string', 'max:32', 'regex:/^[\*\#0-9]+$/'],
            'steps_text' => ['required', 'string', 'max:5000'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $steps = $this->ussdFlowTemplateService->parseStepsText($validated['steps_text']);
        if ($steps === []) {
            return back()
                ->withInput()
                ->withErrors(['steps_text' => 'Add at least one step.']);
        }

        $previous = [
            'name' => $ussdFlow->name,
            'ussd_code' => $ussdFlow->ussd_code,
            'steps' => $ussdFlow->steps,
            'is_active' => $ussdFlow->is_active,
        ];

        $updated = $this->ussdFlowTemplateService->updateTemplate($ussdFlow, [
            'name' => $validated['name'],
            'ussd_code' => $validated['ussd_code'],
            'steps' => $steps,
            'is_active' => $request->boolean('is_active'),
        ]);

        $this->auditLogService->record(
            $request->user(),
            AuditActions::USSD_FLOW_UPDATE,
            'ussd_flow_template',
            (string) $ussdFlow->id,
            $previous,
            [
                'name' => $updated->name,
                'ussd_code' => $updated->ussd_code,
                'steps' => $updated->steps,
                'is_active' => $updated->is_active,
            ],
            $request
        );

        return redirect()
            ->route('admin.ussd-flows.index')
            ->with('status', 'USSD flow updated.');
    }

    public function reset(UssdFlowTemplate $ussdFlow): RedirectResponse
    {
        $defaults = collect(UssdFlowDefaults::all())
            ->firstWhere('flow_key', $ussdFlow->flow_key);

        abort_if($defaults === null, 404);

        $this->ussdFlowTemplateService->updateTemplate($ussdFlow, array_merge($defaults, [
            'is_active' => true,
        ]));

        return redirect()
            ->route('admin.ussd-flows.edit', $ussdFlow)
            ->with('status', 'USSD flow reset to defaults.');
    }
}
