<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPlan;
use App\Services\SubscriptionPlanAdminService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SubscriptionPlanController extends Controller
{
    private const STATUSES = ['Active', 'Disabled'];

    public function __construct(
        private readonly SubscriptionPlanAdminService $subscriptionPlanAdminService,
    ) {}

    public function index(): View
    {
        $plans = SubscriptionPlan::query()
            ->orderBy('sort_order')
            ->orderBy('plan_name')
            ->get();

        return view('admin.subscription-plans.index', [
            'title' => 'Subscription Plans',
            'plans' => $plans,
        ]);
    }

    public function create(): View
    {
        return view('admin.subscription-plans.form', [
            'title' => 'Add Subscription Plan',
            'plan' => null,
            'statuses' => self::STATUSES,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $this->subscriptionPlanAdminService->create($this->validatedPlanData($request));

        return redirect()
            ->route('admin.subscription-plans.index')
            ->with('status', 'Subscription plan created.');
    }

    public function edit(SubscriptionPlan $subscriptionPlan): View
    {
        return view('admin.subscription-plans.form', [
            'title' => 'Edit Subscription Plan',
            'plan' => $subscriptionPlan,
            'statuses' => self::STATUSES,
        ]);
    }

    public function update(Request $request, SubscriptionPlan $subscriptionPlan): RedirectResponse
    {
        $this->subscriptionPlanAdminService->update(
            $subscriptionPlan,
            $this->validatedPlanData($request)
        );

        return redirect()
            ->route('admin.subscription-plans.index')
            ->with('status', 'Subscription plan updated.');
    }

    public function destroy(SubscriptionPlan $subscriptionPlan): RedirectResponse
    {
        $this->subscriptionPlanAdminService->delete($subscriptionPlan);

        return redirect()
            ->route('admin.subscription-plans.index')
            ->with('status', 'Subscription plan deleted.');
    }

    /**
     * @return array{
     *     plan_name: string,
     *     price: float,
     *     duration_days: int,
     *     status: string,
     *     sort_order: int,
     * }
     */
    private function validatedPlanData(Request $request): array
    {
        $validated = $request->validate([
            'plan_name' => ['required', 'string', 'min:2', 'max:255'],
            'price' => ['required', 'numeric', 'min:0'],
            'duration_days' => ['required', 'integer', 'min:1'],
            'status' => ['required', 'in:'.implode(',', self::STATUSES)],
            'sort_order' => ['required', 'integer', 'min:0'],
        ]);

        return [
            'plan_name' => $validated['plan_name'],
            'price' => round((float) $validated['price'], 2),
            'duration_days' => (int) $validated['duration_days'],
            'status' => $validated['status'],
            'sort_order' => (int) $validated['sort_order'],
        ];
    }
}
