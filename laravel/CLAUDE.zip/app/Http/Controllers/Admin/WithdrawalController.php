<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WithdrawalRequest;
use App\Services\AuditLogService;
use App\Services\WithdrawalAdminService;
use App\Support\AuditActions;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use RuntimeException;

class WithdrawalController extends Controller
{
    private const STATUSES = ['Pending', 'Approved', 'Rejected', 'Paid'];

    public function __construct(
        private readonly WithdrawalAdminService $withdrawalAdminService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('search')->toString());

        $withdrawals = WithdrawalRequest::query()
            ->with('user:id,name,email,first_name,last_name,phone_number')
            ->when($status !== '' && $status !== 'all', fn ($query) => $query->where('status', $status))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('payment_number', 'like', "%{$search}%")
                        ->orWhere('payment_method', 'like', "%{$search}%")
                        ->orWhereHas('user', function ($userQuery) use ($search) {
                            $userQuery->where('name', 'like', "%{$search}%")
                                ->orWhere('email', 'like', "%{$search}%")
                                ->orWhere('first_name', 'like', "%{$search}%")
                                ->orWhere('last_name', 'like', "%{$search}%");
                        });
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        return view('admin.withdrawals.index', [
            'title' => 'Withdrawals',
            'withdrawals' => $withdrawals,
            'statuses' => self::STATUSES,
            'statusFilter' => $status !== '' ? $status : 'all',
            'search' => $search,
        ]);
    }

    public function update(Request $request, WithdrawalRequest $withdrawal): RedirectResponse
    {
        $validated = $request->validate([
            'action' => ['required', 'in:approve,reject,mark_paid'],
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ]);

        try {
            match ($validated['action']) {
                'approve' => $this->withdrawalAdminService->approve(
                    $withdrawal,
                    $validated['admin_note'] ?? null
                ),
                'reject' => $this->withdrawalAdminService->reject(
                    $withdrawal,
                    $validated['admin_note'] ?? null
                ),
                'mark_paid' => $this->withdrawalAdminService->markPaid(
                    $withdrawal,
                    $validated['admin_note'] ?? null
                ),
            };
        } catch (RuntimeException $exception) {
            return redirect()
                ->route('admin.withdrawals.index', array_filter([
                    'status' => $request->input('return_status'),
                    'search' => $request->input('return_search'),
                    'page' => $request->input('return_page'),
                ], fn ($value) => $value !== null && $value !== ''))
                ->with('error', $exception->getMessage());
        }

        $action = match ($validated['action']) {
            'approve' => AuditActions::WITHDRAWAL_APPROVAL,
            'reject' => AuditActions::WITHDRAWAL_REJECTION,
            'mark_paid' => AuditActions::WITHDRAWAL_PAID,
        };

        $this->auditLogService->record(
            $request->user(),
            $action,
            'withdrawal',
            $withdrawal->id,
            null,
            $withdrawal->fresh()->status,
            $request
        );

        return redirect()
            ->route('admin.withdrawals.index', array_filter([
                'status' => $request->input('return_status'),
                'search' => $request->input('return_search'),
                'page' => $request->input('return_page'),
            ], fn ($value) => $value !== null && $value !== ''))
            ->with('status', 'Withdrawal updated.');
    }
}
