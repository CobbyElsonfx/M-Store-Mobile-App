<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CommissionTransaction;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CommissionController extends Controller
{
    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('search')->toString());

        $commissions = CommissionTransaction::query()
            ->with([
                'referrer:id,name,email,first_name,last_name',
                'referredUser:id,name,email,first_name,last_name',
                'order:id,item_name',
            ])
            ->when($status !== '' && $status !== 'all', fn ($query) => $query->where('status', $status))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('order_id', 'like', "%{$search}%")
                        ->orWhereHas('order', fn ($order) => $order->where('item_name', 'like', "%{$search}%"))
                        ->orWhereHas('referrer', function ($user) use ($search) {
                            $user->where('email', 'like', "%{$search}%")
                                ->orWhere('name', 'like', "%{$search}%")
                                ->orWhere('first_name', 'like', "%{$search}%")
                                ->orWhere('last_name', 'like', "%{$search}%");
                        });
                });
            })
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        $totalsQuery = CommissionTransaction::query();
        if ($status !== '' && $status !== 'all') {
            $totalsQuery->where('status', $status);
        }

        $totals = $totalsQuery
            ->selectRaw('COALESCE(SUM(product_profit), 0) as profit_total')
            ->selectRaw('COALESCE(SUM(referral_share), 0) as referral_total')
            ->selectRaw('COALESCE(SUM(system_share), 0) as system_total')
            ->first();

        return view('admin.commissions.index', [
            'title' => 'Commissions',
            'commissions' => $commissions,
            'statuses' => ['Completed'],
            'statusFilter' => $status !== '' ? $status : 'all',
            'search' => $search,
            'totals' => [
                'profit' => (float) ($totals->profit_total ?? 0),
                'referral' => (float) ($totals->referral_total ?? 0),
                'system' => (float) ($totals->system_total ?? 0),
            ],
        ]);
    }
}
