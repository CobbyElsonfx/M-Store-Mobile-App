<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\AuditLogService;
use App\Services\ProductAdminService;
use App\Support\AuditActions;
use App\Support\CatalogLabels;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function __construct(
        private readonly ProductAdminService $productAdminService,
        private readonly AuditLogService $auditLogService,
    ) {}

    public function index(): View
    {
        $products = Product::query()
            ->orderByDesc('created_at')
            ->get();

        return view('admin.products.index', [
            'title' => 'Products',
            'products' => $products,
        ]);
    }

    public function create(): View
    {
        return view('admin.products.form', [
            'title' => 'Add Product',
            'product' => null,
            'categories' => CatalogLabels::PRODUCT_CATEGORIES,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedProductData($request);

        $product = $this->productAdminService->create(
            $data,
            $request->file('image')
        );

        $this->auditLogService->record(
            $request->user(),
            AuditActions::PRODUCT_CREATE,
            'product',
            $product->id,
            null,
            $product->product_name,
            $request
        );

        return redirect()
            ->route('admin.products.index')
            ->with('status', 'Product created.');
    }

    public function edit(Product $product): View
    {
        return view('admin.products.form', [
            'title' => 'Edit Product',
            'product' => $product,
            'categories' => CatalogLabels::PRODUCT_CATEGORIES,
        ]);
    }

    public function update(Request $request, Product $product): RedirectResponse
    {
        $data = $this->validatedProductData($request);

        $previousName = $product->product_name;

        $this->productAdminService->update(
            $product,
            $data,
            $request->file('image')
        );

        $this->auditLogService->record(
            $request->user(),
            AuditActions::PRODUCT_UPDATE,
            'product',
            $product->id,
            $previousName,
            $data['product_name'],
            $request
        );

        return redirect()
            ->route('admin.products.index')
            ->with('status', 'Product updated.');
    }

    public function destroy(Request $request, Product $product): RedirectResponse
    {
        $productId = $product->id;
        $productName = $product->product_name;

        $this->productAdminService->delete($product);

        $this->auditLogService->record(
            $request->user(),
            AuditActions::PRODUCT_DELETE,
            'product',
            $productId,
            $productName,
            null,
            $request
        );

        return redirect()
            ->route('admin.products.index')
            ->with('status', 'Product deleted.');
    }

    /**
     * @return array{
     *     product_name: string,
     *     product_description: string,
     *     category: string,
     *     price: float,
     *     profit: float,
     *     referral_percent: float,
     *     system_percent: float,
     *     stock_quantity: int,
     *     is_available: bool,
     * }
     */
    private function validatedProductData(Request $request): array
    {
        $validated = $request->validate([
            'product_name' => ['required', 'string', 'min:2', 'max:255'],
            'product_description' => ['required', 'string', 'min:5'],
            'category' => ['required', 'in:'.implode(',', CatalogLabels::PRODUCT_CATEGORIES)],
            'price' => ['required', 'numeric', 'min:0'],
            'profit' => ['required', 'numeric', 'min:0'],
            'referral_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'system_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'stock_quantity' => ['required', 'integer', 'min:0'],
            'is_available' => ['sometimes', 'boolean'],
            'image' => ['nullable', 'image', 'max:5120'],
        ]);

        return [
            'product_name' => $validated['product_name'],
            'product_description' => $validated['product_description'],
            'category' => $validated['category'],
            'price' => round((float) $validated['price'], 2),
            'profit' => round((float) $validated['profit'], 2),
            'referral_percent' => round((float) $validated['referral_percent'], 2),
            'system_percent' => round((float) $validated['system_percent'], 2),
            'stock_quantity' => (int) $validated['stock_quantity'],
            'is_available' => $request->boolean('is_available'),
        ];
    }

    public static function imageUrl(?Product $product): ?string
    {
        if ($product === null || blank($product->image_path)) {
            return null;
        }

        if (str_starts_with($product->image_path, 'http://') || str_starts_with($product->image_path, 'https://')) {
            return $product->image_path;
        }

        return Storage::disk('public')->url($product->image_path);
    }
}
