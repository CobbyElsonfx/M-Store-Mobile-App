<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BusinessSettingsResource;
use App\Services\BusinessSettingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller
{
    public function business(BusinessSettingsService $businessSettings): BusinessSettingsResource
    {
        return new BusinessSettingsResource($businessSettings);
    }

    public function app(): JsonResponse
    {
        $settings = DB::table('app_settings')
            ->pluck('value', 'key')
            ->map(function ($value) {
                $decoded = json_decode($value, true);

                return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
            });

        return response()->json(['settings' => $settings]);
    }
}
