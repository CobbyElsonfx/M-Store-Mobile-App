<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PaystackWebhookController extends Controller
{
    public function __invoke(Request $request, SubscriptionService $subscriptionService): Response
    {
        $subscriptionService->handleWebhook(
            $request->getContent(),
            $request->header('X-Paystack-Signature')
        );

        return response('ok', 200);
    }
}
