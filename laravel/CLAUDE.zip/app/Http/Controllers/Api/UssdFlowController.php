<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UssdFlowTemplateResource;
use App\Services\UssdFlowTemplateService;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class UssdFlowController extends Controller
{
    public function index(UssdFlowTemplateService $ussdFlowTemplateService): AnonymousResourceCollection
    {
        return UssdFlowTemplateResource::collection(
            $ussdFlowTemplateService->activeForMobile()
        );
    }
}
