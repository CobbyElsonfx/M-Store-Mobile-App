<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\StoreWithdrawalRequest;
use App\Http\Resources\WalletResource;
use App\Http\Resources\WalletTransactionResource;
use App\Http\Resources\WithdrawalResource;
use App\Services\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class WalletController extends Controller
{
    public function show(WalletService $walletService): WalletResource
    {
        $wallet = $walletService->walletForUser(request()->user());

        return new WalletResource($wallet);
    }

    public function transactions(WalletService $walletService): AnonymousResourceCollection
    {
        $transactions = $walletService->transactionsForUser(request()->user());

        return WalletTransactionResource::collection($transactions);
    }

    public function withdrawals(WalletService $walletService): AnonymousResourceCollection
    {
        return WithdrawalResource::collection(
            $walletService->withdrawalsForUser(request()->user())
        );
    }

    public function storeWithdrawal(
        StoreWithdrawalRequest $request,
        WalletService $walletService
    ): JsonResponse {
        $withdrawal = $walletService->requestWithdrawal(
            $request->user(),
            (float) $request->validated('amount'),
            $request->validated('payment_method'),
            $request->validated('payment_number')
        );

        return (new WithdrawalResource($withdrawal))
            ->response()
            ->setStatusCode(201);
    }
}
