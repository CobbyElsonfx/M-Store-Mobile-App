<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ReferralResource;
use App\Http\Resources\ReferralSummaryResource;
use App\Services\ReferralService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class ReferralController extends Controller
{
    public function index(ReferralService $referralService): AnonymousResourceCollection
    {
        return ReferralResource::collection(
            $referralService->referralsForUser(request()->user())
        );
    }

    public function summary(ReferralService $referralService): ReferralSummaryResource
    {
        return new ReferralSummaryResource(
            $referralService->summaryForUser(request()->user())
        );
    }

    public function validateCode(string $code, ReferralService $referralService): JsonResponse
    {
        $referrer = $referralService->validateReferralCode($code);

        if ($referrer === null) {
            return response()->json(['message' => 'Referral code not found.'], 404);
        }

        return response()->json([
            'data' => [
                'referrerUserId' => (string) $referrer->id,
                'referralCode' => $referrer->referral_code,
            ],
        ]);
    }
}
