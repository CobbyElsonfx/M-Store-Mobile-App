<?php

namespace App\Http\Controllers\Api;

use App\Enums\SubscriptionStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\InitializeSubscriptionPaymentRequest;
use App\Http\Resources\PaymentResource;
use App\Services\SubscriptionAccessService;
use App\Services\SubscriptionService;
use Illuminate\Http\JsonResponse;

class SubscriptionController extends Controller
{
    public function pay(
        InitializeSubscriptionPaymentRequest $request,
        SubscriptionService $subscriptionService
    ): JsonResponse {
        $checkout = $subscriptionService->initializePaystackPayment(
            $request->user(),
            $request->validated('subscription_plan_id')
        );

        return response()->json([
            'success' => true,
            'access_code' => $checkout['access_code'],
            'authorization_url' => $checkout['authorization_url'],
            'reference' => $checkout['reference'],
            'public_key' => $checkout['public_key'],
            'data' => [
                'access_code' => $checkout['access_code'],
                'authorization_url' => $checkout['authorization_url'],
                'reference' => $checkout['reference'],
                'public_key' => $checkout['public_key'],
                'amount' => $checkout['amount'],
                'currency' => $checkout['currency'],
                'plan_name' => $checkout['plan_name'],
                'status' => $checkout['payment']->status,
            ],
        ]);
    }

    public function paymentStatus(
        string $reference,
        SubscriptionService $subscriptionService
    ): JsonResponse {
        $payment = $subscriptionService->paymentStatus(request()->user(), $reference);
        $user = request()->user()->fresh();

        return response()->json([
            'success' => true,
            'data' => (new PaymentResource($payment->loadMissing('plan')))->resolve() + [
                'subscriptionActive' => $user->subscription_status === SubscriptionStatus::Active
                    && $user->subscription_expiry_date?->isFuture(),
            ],
        ]);
    }

    public function accessLevel(SubscriptionAccessService $accessService): JsonResponse
    {
        $user = request()->user()->fresh();

        return response()->json([
            'data' => [
                'accessLevel' => $accessService->resolveAccessLevel($user),
            ],
        ]);
    }
}
