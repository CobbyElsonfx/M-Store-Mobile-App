<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\LoginRequest;
use App\Http\Requests\Api\RegisterRequest;
use App\Http\Requests\Api\ResendRegistrationOtpRequest;
use App\Http\Requests\Api\VerifyRegistrationOtpRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\RegistrationOtpService;
use App\Services\UserRegistrationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function __construct(
        private readonly RegistrationOtpService $registrationOtpService,
        private readonly UserRegistrationService $userRegistrationService,
    ) {}

    public function register(RegisterRequest $request): JsonResponse
    {
        $validated = $request->validated();

        $this->registrationOtpService->send($validated);

        return response()->json([
            'message' => 'Verification code sent to your email.',
            'requires_verification' => true,
            'email' => $validated['email'],
        ]);
    }

    public function verifyRegistration(VerifyRegistrationOtpRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $payload = $this->registrationOtpService->verify(
            $validated['email'],
            $validated['otp_code']
        );

        $user = $this->userRegistrationService->createAgent($payload);
        $token = $user->createToken('mobile')->plainTextToken;

        return response()->json([
            'message' => 'Registration successful.',
            'token' => $token,
            'token_type' => 'Bearer',
            'user' => new UserResource($user->fresh(['wallet'])),
        ], 201);
    }

    public function resendRegistrationOtp(ResendRegistrationOtpRequest $request): JsonResponse
    {
        $this->registrationOtpService->resend($request->validated('email'));

        return response()->json([
            'message' => 'Verification code sent to your email.',
        ]);
    }

    public function login(LoginRequest $request): JsonResponse
    {
        $user = User::query()->where('email', $request->validated('email'))->first();

        if (! $user || ! Hash::check($request->validated('password'), $user->password)) {
            return response()->json(['message' => 'Invalid email or password.'], 401);
        }

        if (! $user->isAgent()) {
            return response()->json(['message' => 'This account cannot access the mobile API.'], 403);
        }

        if ($user->isSuspended()) {
            return response()->json(['message' => 'Your account has been suspended. Please contact support.'], 403);
        }

        $user->tokens()->delete();
        $token = $user->createToken('mobile')->plainTextToken;

        return response()->json([
            'message' => 'Login successful.',
            'token' => $token,
            'token_type' => 'Bearer',
            'user' => new UserResource($user->load('wallet')),
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()?->currentAccessToken()?->delete();

        return response()->json(['message' => 'Logged out.']);
    }

    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'user' => new UserResource($request->user()->load('wallet')),
        ]);
    }
}
