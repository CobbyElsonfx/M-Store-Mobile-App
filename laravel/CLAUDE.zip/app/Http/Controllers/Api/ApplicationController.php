<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SubmitApplicationRequest;
use App\Http\Requests\Api\UploadApplicationDocumentRequest;
use App\Http\Resources\ApplicationResource;
use App\Models\AgentApplication;
use App\Services\ApplicationService;
use App\Support\DocumentSlotMapper;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ApplicationController extends Controller
{
    public function nextId(ApplicationService $applicationService): JsonResponse
    {
        $application = $applicationService->reserveNext(request()->user());

        return response()->json([
            'data' => [
                'id' => $application->id,
            ],
        ]);
    }

    public function index(Request $request): AnonymousResourceCollection
    {
        $applications = AgentApplication::query()
            ->with('documents')
            ->where('user_id', $request->user()->id)
            ->where('status', '!=', 'Draft')
            ->orderByDesc('created_at')
            ->get();

        return ApplicationResource::collection($applications);
    }

    public function show(Request $request, AgentApplication $application): ApplicationResource|JsonResponse
    {
        if ($application->user_id !== $request->user()->id || $application->status === 'Draft') {
            return response()->json(['message' => 'Application not found.'], 404);
        }

        $application->load('documents');

        return new ApplicationResource($application);
    }

    public function submit(
        SubmitApplicationRequest $request,
        AgentApplication $application,
        ApplicationService $applicationService
    ): ApplicationResource {
        $submitted = $applicationService->submit(
            $application,
            $request->user(),
            $request->validated()
        );

        return new ApplicationResource($submitted);
    }

    public function uploadDocument(
        UploadApplicationDocumentRequest $request,
        AgentApplication $application,
        ApplicationService $applicationService
    ): JsonResponse {
        $document = $applicationService->uploadDocument(
            $application,
            $request->user(),
            $request->validated('slot_id'),
            $request->file('file')
        );

        $documentType = $document->document_type;

        return response()->json([
            'data' => [
                'slotId' => DocumentSlotMapper::slotIdFromDocumentType($documentType),
                'documentType' => $documentType,
                'url' => $applicationService->documentUrl($application, $documentType),
            ],
        ]);
    }

    public function deleteDocument(
        Request $request,
        AgentApplication $application,
        string $documentType,
        ApplicationService $applicationService
    ): JsonResponse {
        $applicationService->deleteDocument(
            $application,
            $request->user(),
            $documentType
        );

        return response()->json(['message' => 'Document removed.']);
    }

    public function downloadDocument(
        Request $request,
        AgentApplication $application,
        string $documentType,
        ApplicationService $applicationService
    ): BinaryFileResponse {
        $path = $applicationService->documentDownloadPath(
            $application,
            $request->user(),
            $documentType
        );

        return response()->download($path);
    }
}
