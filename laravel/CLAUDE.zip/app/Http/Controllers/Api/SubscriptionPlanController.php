<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SubscriptionPlanResource;
use App\Models\SubscriptionPlan;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class SubscriptionPlanController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        $plans = SubscriptionPlan::query()
            ->where('status', 'Active')
            ->orderBy('sort_order')
            ->get();

        return SubscriptionPlanResource::collection($plans);
    }

    public function show(SubscriptionPlan $subscriptionPlan): SubscriptionPlanResource
    {
        return new SubscriptionPlanResource($subscriptionPlan);
    }
}
