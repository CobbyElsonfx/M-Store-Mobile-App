<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Payment */
class PaymentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'paymentId' => $this->id,
            'reference' => $this->reference,
            'status' => $this->status,
            'amount' => (float) $this->amount,
            'currency' => $this->currency,
            'provider' => $this->provider,
            'planId' => $this->subscription_plan_id,
            'planName' => $this->plan?->plan_name,
            'subscriptionId' => $this->status === 'Confirmed' ? $this->purpose_id : null,
            'createdAt' => $this->created_at?->toIso8601String(),
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }
}
