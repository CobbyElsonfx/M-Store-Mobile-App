<?php

namespace App\Http\Resources;

use App\Services\ApplicationService;
use App\Support\DocumentSlotMapper;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\AgentApplication */
class ApplicationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        /** @var ApplicationService $applications */
        $applications = app(ApplicationService::class);

        $documents = [];
        foreach ($this->documents as $document) {
            $slotId = DocumentSlotMapper::slotIdFromDocumentType($document->document_type);
            $documents[$slotId] = $applications->documentUrl($this->resource, $document->document_type);
        }

        return [
            'id' => $this->id,
            'userId' => (string) $this->user_id,
            'formType' => $this->form_type,
            'applicantName' => $this->applicant_name,
            'phoneNumber' => $this->phone_number,
            'formData' => $this->form_data ?? [],
            'documents' => $documents,
            'status' => $this->status,
            'adminNote' => $this->admin_note,
            'createdAt' => $this->created_at?->toIso8601String(),
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }
}
