<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Subscription */
class SubscriptionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'subscriptionId' => $this->id,
            'userId' => (string) $this->user_id,
            'planId' => $this->plan_id,
            'planName' => $this->plan_name,
            'price' => (float) $this->price,
            'durationDays' => (int) $this->duration_days,
            'paymentProvider' => $this->payment_provider,
            'paymentReference' => $this->payment_reference,
            'startDate' => $this->start_date?->toIso8601String(),
            'endDate' => $this->end_date?->toIso8601String(),
            'status' => $this->status,
            'createdAt' => $this->created_at?->toIso8601String(),
        ];
    }
}
