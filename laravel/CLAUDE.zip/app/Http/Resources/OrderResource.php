<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Order */
class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'userId' => (string) $this->user_id,
            'productId' => $this->product_id,
            'agentName' => $this->agent_name,
            'itemName' => $this->item_name,
            'quantity' => (int) $this->quantity,
            'totalAmount' => (float) $this->total_amount,
            'phoneNumber' => $this->phone_number,
            'location' => $this->location,
            'status' => $this->status,
            'createdAt' => $this->created_at?->toIso8601String(),
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }
}
