<?php

namespace App\Http\Resources;

use App\Services\BusinessSettingsService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BusinessSettingsResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        /** @var BusinessSettingsService $settings */
        $settings = $this->resource;

        return [
            'referralCommissionPercent' => $settings->getFloat('referral_commission_percent', 40),
            'systemCommissionPercent' => $settings->getFloat('system_commission_percent', 60),
            'monthlySubscriptionBonus' => $settings->getFloat('monthly_subscription_bonus', 1),
            'minimumWithdrawal' => $settings->getFloat('minimum_withdrawal', 10),
            'trialDays' => $settings->getInt('trial_days', 7),
            'currency' => (string) $settings->get('currency', 'GHS'),
            'taxRate' => $settings->getFloat('tax_rate', 0),
            'storeEnabled' => filter_var($settings->get('store_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'subscriptionEnabled' => filter_var($settings->get('subscription_enabled', true), FILTER_VALIDATE_BOOLEAN),
            'referralShareLinkBase' => (string) $settings->get('referral_share_link_base', 'https://momokotle.app/ref/'),
        ];
    }
}
