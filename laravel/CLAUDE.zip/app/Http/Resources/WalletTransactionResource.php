<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\WalletTransaction */
class WalletTransactionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'transactionId' => $this->id,
            'userId' => (string) $this->user_id,
            'amount' => (float) $this->amount,
            'source' => $this->source,
            'description' => $this->description,
            'reference' => $this->reference,
            'status' => $this->status,
            'createdAt' => $this->created_at?->toIso8601String(),
        ];
    }
}
