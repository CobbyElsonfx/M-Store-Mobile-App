<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\UssdFlowTemplate */
class UssdFlowTemplateResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'flowKey' => $this->flow_key,
            'name' => $this->name,
            'ussdCode' => $this->ussd_code,
            'steps' => collect($this->steps ?? [])->map(function (array $step) {
                return [
                    'type' => $step['type'] ?? 'menu',
                    'value' => $step['value'] ?? null,
                    'hints' => $step['hints'] ?? null,
                ];
            })->values()->all(),
            'isActive' => (bool) $this->is_active,
            'sortOrder' => (int) $this->sort_order,
        ];
    }
}
