<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReferralSummaryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'referralCode' => $this->resource['referralCode'],
            'referralLink' => $this->resource['referralLink'],
            'stats' => $this->resource['stats'],
            'wallet' => $this->resource['wallet'],
        ];
    }
}
