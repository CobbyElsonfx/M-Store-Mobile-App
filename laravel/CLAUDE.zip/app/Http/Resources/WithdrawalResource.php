<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\WithdrawalRequest */
class WithdrawalResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'withdrawalId' => $this->id,
            'userId' => (string) $this->user_id,
            'amount' => (float) $this->amount,
            'paymentMethod' => $this->payment_method,
            'paymentNumber' => $this->payment_number,
            'status' => $this->status,
            'adminNote' => $this->admin_note,
            'createdAt' => $this->created_at?->toIso8601String(),
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }
}
