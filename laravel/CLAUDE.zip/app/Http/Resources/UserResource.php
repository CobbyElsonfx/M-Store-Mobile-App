<?php

namespace App\Http\Resources;

use App\Services\SubscriptionAccessService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\User */
class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $accessService = app(SubscriptionAccessService::class);

        return [
            'id' => $this->id,
            'email' => $this->email,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'full_name' => trim(($this->first_name ?? '').' '.($this->last_name ?? '')),
            'phone_number' => $this->phone_number,
            'location' => $this->location,
            'account_status' => $this->account_status?->value ?? $this->account_status,
            'referral_code' => $this->referral_code,
            'subscription_status' => $this->subscription_status?->value ?? $this->subscription_status,
            'trial_end_date' => $this->trial_end_date?->toIso8601String(),
            'subscription_expiry_date' => $this->subscription_expiry_date?->toIso8601String(),
            'access_level' => $accessService->resolveAccessLevel($this->resource),
            'wallet' => $this->whenLoaded('wallet', fn () => [
                'available_balance' => (float) $this->wallet->available_balance,
                'pending_balance' => (float) $this->wallet->pending_balance,
                'withdrawn_balance' => (float) $this->wallet->withdrawn_balance,
                'lifetime_earnings' => (float) $this->wallet->lifetime_earnings,
            ]),
        ];
    }
}
