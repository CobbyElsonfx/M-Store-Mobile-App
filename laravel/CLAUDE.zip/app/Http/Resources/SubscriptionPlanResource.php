<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\SubscriptionPlan */
class SubscriptionPlanResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'planName' => $this->plan_name,
            'price' => (float) $this->price,
            'durationDays' => (int) $this->duration_days,
            'status' => $this->status,
            'sortOrder' => (int) $this->sort_order,
        ];
    }
}
