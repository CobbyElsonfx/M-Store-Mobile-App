<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Referral */
class ReferralResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'referralId' => $this->id,
            'referrerUserId' => (string) $this->referrer_user_id,
            'referrerCode' => $this->referrer_code,
            'referredUserId' => (string) $this->referred_user_id,
            'referredUserName' => $this->referred_user_name,
            'registrationDate' => $this->registration_date?->toIso8601String(),
            'isActive' => (bool) $this->is_active,
            'totalOrders' => (int) $this->total_orders,
            'hasActiveSubscription' => (bool) $this->has_active_subscription,
            'walletEarnings' => (float) $this->wallet_earnings,
        ];
    }
}
