<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Wallet */
class WalletResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'userId' => (string) $this->user_id,
            'availableBalance' => (float) $this->available_balance,
            'pendingBalance' => (float) $this->pending_balance,
            'withdrawnBalance' => (float) $this->withdrawn_balance,
            'lifetimeEarnings' => (float) $this->lifetime_earnings,
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }
}
