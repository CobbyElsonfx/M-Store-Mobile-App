<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/** @mixin \App\Models\Product */
class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'productName' => $this->product_name,
            'productDescription' => $this->product_description,
            'category' => $this->category,
            'price' => (float) $this->price,
            'profit' => (float) $this->profit,
            'referralPercent' => (float) $this->referral_percent,
            'systemPercent' => (float) $this->system_percent,
            'stockQuantity' => (int) $this->stock_quantity,
            'productImageUrl' => $this->resolveImageUrl(),
            'isAvailable' => (bool) $this->is_available,
            'updatedAt' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function resolveImageUrl(): ?string
    {
        if (blank($this->image_path)) {
            return null;
        }

        if (str_starts_with($this->image_path, 'http://') || str_starts_with($this->image_path, 'https://')) {
            return $this->image_path;
        }

        return Storage::disk('public')->url($this->image_path);
    }
}
