<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Notification */
class NotificationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'notificationId' => $this->id,
            'userId' => (string) $this->user_id,
            'title' => $this->title,
            'message' => $this->message,
            'type' => $this->type,
            'referenceId' => $this->reference_id,
            'isRead' => (bool) $this->is_read,
            'createdAt' => $this->created_at?->toIso8601String(),
        ];
    }
}
