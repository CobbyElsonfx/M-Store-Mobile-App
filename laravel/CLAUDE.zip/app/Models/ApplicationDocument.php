<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ApplicationDocument extends Model
{
    use HasUuids;

    protected $fillable = [
        'application_id',
        'document_type',
        'storage_path',
        'mime_type',
        'file_size',
        'original_filename',
    ];

    public function application(): BelongsTo
    {
        return $this->belongsTo(AgentApplication::class, 'application_id');
    }
}
