<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UssdFlowTemplate extends Model
{
    protected $fillable = [
        'flow_key',
        'name',
        'ussd_code',
        'steps',
        'is_active',
        'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'steps' => 'array',
            'is_active' => 'boolean',
        ];
    }
}
