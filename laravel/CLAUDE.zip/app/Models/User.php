<?php

namespace App\Models;

use App\Enums\AccountStatus;
use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'first_name',
        'last_name',
        'phone_number',
        'location',
        'account_status',
        'referral_code',
        'referred_by_code',
        'referred_by_user_id',
        'referral_date',
        'trial_start_date',
        'trial_end_date',
        'is_trial_used',
        'subscription_status',
        'subscription_expiry_date',
        'active_subscription_id',
        'firebase_uid',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'role' => UserRole::class,
            'account_status' => AccountStatus::class,
            'subscription_status' => SubscriptionStatus::class,
            'referral_date' => 'datetime',
            'trial_start_date' => 'datetime',
            'trial_end_date' => 'datetime',
            'subscription_expiry_date' => 'datetime',
            'is_trial_used' => 'boolean',
        ];
    }

    public function isAdmin(): bool
    {
        return $this->role === UserRole::Admin;
    }

    public function isAgent(): bool
    {
        return $this->role === UserRole::Agent;
    }

    public function isSuspended(): bool
    {
        return $this->account_status === AccountStatus::Suspended;
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(self::class, 'referred_by_user_id');
    }

    public function referralsMade(): HasMany
    {
        return $this->hasMany(Referral::class, 'referrer_user_id');
    }

    public function wallet(): HasOne
    {
        return $this->hasOne(Wallet::class);
    }

    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    public function activeSubscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class, 'active_subscription_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function agentApplications(): HasMany
    {
        return $this->hasMany(AgentApplication::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class);
    }
}
