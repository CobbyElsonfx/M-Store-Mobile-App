<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CommissionTransaction extends Model
{
    use HasUuids;

    protected $fillable = [
        'order_id',
        'subscription_id',
        'referrer_user_id',
        'referred_user_id',
        'product_profit',
        'referral_share',
        'system_share',
        'referral_percent',
        'system_percent',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'product_profit' => 'decimal:2',
            'referral_share' => 'decimal:2',
            'system_share' => 'decimal:2',
            'referral_percent' => 'decimal:2',
            'system_percent' => 'decimal:2',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referrer_user_id');
    }

    public function referredUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referred_user_id');
    }
}
