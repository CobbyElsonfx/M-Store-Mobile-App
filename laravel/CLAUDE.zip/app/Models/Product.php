<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'product_name',
        'product_description',
        'category',
        'price',
        'profit',
        'referral_percent',
        'system_percent',
        'stock_quantity',
        'image_path',
        'is_available',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'profit' => 'decimal:2',
            'referral_percent' => 'decimal:2',
            'system_percent' => 'decimal:2',
            'is_available' => 'boolean',
        ];
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }
}
