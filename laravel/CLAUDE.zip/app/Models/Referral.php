<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Referral extends Model
{
    use HasUuids;

    protected $fillable = [
        'referrer_user_id',
        'referrer_code',
        'referred_user_id',
        'referred_user_name',
        'registration_date',
        'is_active',
        'total_orders',
        'has_active_subscription',
        'wallet_earnings',
    ];

    protected function casts(): array
    {
        return [
            'registration_date' => 'datetime',
            'is_active' => 'boolean',
            'has_active_subscription' => 'boolean',
            'wallet_earnings' => 'decimal:2',
        ];
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referrer_user_id');
    }

    public function referredUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referred_user_id');
    }
}
