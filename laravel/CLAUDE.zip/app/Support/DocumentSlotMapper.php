<?php

namespace App\Support;

class DocumentSlotMapper
{
    /** @var array<string, array{storage: string, type: string}> */
    private const SLOTS = [
        'ghanaCardFront' => ['storage' => 'ghana_card_front', 'type' => 'ghanaCardFrontUrl'],
        'ghanaCardBack' => ['storage' => 'ghana_card_back', 'type' => 'ghanaCardBackUrl'],
        'businessCertificate' => ['storage' => 'business_certificate', 'type' => 'businessCertificateUrl'],
        'formA' => ['storage' => 'form_a', 'type' => 'formAUrl'],
        'formB' => ['storage' => 'form_b', 'type' => 'formBUrl'],
        'formC' => ['storage' => 'form_c', 'type' => 'formCUrl'],
        'signature' => ['storage' => 'signature', 'type' => 'signatureUrl'],
        'applicantHoldingFront' => ['storage' => 'applicant_front', 'type' => 'applicantFrontUrl'],
        'applicantHoldingBack' => ['storage' => 'applicant_back', 'type' => 'applicantBackUrl'],
        'ghanaCard' => ['storage' => 'ghana_card', 'type' => 'ghanaCardUrl'],
        'birthProof' => ['storage' => 'birth_proof', 'type' => 'birthProofUrl'],
        'businessCertificateFormA' => ['storage' => 'form_a', 'type' => 'formAUrl'],
        'businessCertificateFormB' => ['storage' => 'form_b', 'type' => 'formBUrl'],
        'businessCertificateFormC' => ['storage' => 'form_c', 'type' => 'formCUrl'],
    ];

    public static function documentType(string $slotId): string
    {
        return self::SLOTS[$slotId]['type']
            ?? $slotId.'Url';
    }

    public static function storageBasename(string $slotId, string $extension): string
    {
        $base = self::SLOTS[$slotId]['storage']
            ?? strtolower(preg_replace('/([a-z])([A-Z])/', '$1_$2', $slotId) ?? $slotId);

        $extension = ltrim(strtolower($extension), '.');

        return $extension === '' ? $base : "{$base}.{$extension}";
    }

    public static function slotIdFromDocumentType(string $documentType): string
    {
        foreach (self::SLOTS as $slotId => $meta) {
            if ($meta['type'] === $documentType) {
                return $slotId;
            }
        }

        if (str_ends_with($documentType, 'Url')) {
            return substr($documentType, 0, -3);
        }

        return $documentType;
    }
}
