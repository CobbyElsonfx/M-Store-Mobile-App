<?php

namespace App\Support;

class SubmissionLabels
{
    public const FORM_TYPES = [
        'Agent Card Request',
        'EVD Agent and Sim Conversion Form',
        'Dynamic SIM Cards Bulk Purchase',
        'Dynamic SIM Cards Bulk Purchase Form',
        'Telecel Agent Details',
        'Telecel Agent Details Form',
        'AirtelTigo Agent Details',
        'AirtelTigo Agent Details Form',
        'Business Certificate Application',
        'Birth Certificate Application',
        'Passport Application',
    ];

    public const STATUSES = [
        'Pending',
        'Approved',
        'Rejected',
        'ResubmissionRequired',
    ];

    /** @var array<string, string> */
    public const DOCUMENT_LABELS = [
        'ghanaCardFrontUrl' => 'Ghana Card Front',
        'ghanaCardBackUrl' => 'Ghana Card Back',
        'businessCertificateUrl' => 'Business Certificate',
        'formAUrl' => 'Form A',
        'formBUrl' => 'Form B',
        'formCUrl' => 'Form C',
        'signatureUrl' => 'Signature',
        'applicantFrontUrl' => 'Applicant Holding Front',
        'applicantBackUrl' => 'Applicant Holding Back',
        'ghanaCardUrl' => 'Ghana Card',
        'birthProofUrl' => 'Birth Proof',
    ];

    /** @var array<string, string> */
    public const FORM_FIELD_LABELS = [
        'businessName' => 'Business Name',
        'surname' => 'Surname',
        'firstName' => 'First Name',
        'fullName' => 'Full Name',
        'phoneNumber' => 'Phone Number',
        'dateOfBirth' => 'Date of Birth',
        'placeOfBirth' => 'Place of Birth',
        'ghanaCardNumber' => 'Ghana Card Number',
        'location' => 'Location',
        'whatsappNumber' => 'WhatsApp Number',
        'nextOfKinName' => 'Next of Kin Name',
        'nextOfKinPhone' => 'Next of Kin Phone',
        'otherName' => 'Other Name',
        'gender' => 'Gender',
        'cityOfBirth' => 'City/Town of Birth',
        'countryOfBirth' => 'Country of Birth',
        'height' => 'Height',
        'nationality' => 'Nationality',
        'oldPassportNumber' => 'Old Passport Number',
        'oldPassportDateOfIssue' => 'Old Passport Date of Issue',
        'socialSecurityNumber' => 'Social Security Number',
        'voterIdNumber' => 'Voter ID Number',
        'birthCertificateNumber' => 'Birth Certificate Number',
        'birthCertificateDateOfIssue' => 'Birth Certificate Date of Issue',
        'birthCertificatePlaceOfIssue' => 'Birth Certificate Place of Issue',
        'maritalStatus' => 'Marital Status',
        'newPassportProfession' => 'New Passport Profession',
        'oldPassportProfession' => 'Old Passport Profession',
        'emailAddress' => 'Email Address',
        'houseNumber' => 'House Number',
        'cityOfResidence' => 'City of Residence',
        'houseStreetName' => 'House Street Name',
        'postOfficeBox' => 'Post Office Box',
        'hasFormalEducation' => 'Formal Education',
        'schoolName' => 'Name of School',
        'schoolMonthStarted' => 'Month Started',
        'schoolYearStarted' => 'Year Started',
        'schoolMonthEnded' => 'Month Ended',
        'schoolYearEnded' => 'Year Ended',
        'schoolAddress' => 'School Address',
        'fatherFullName' => 'Father Full Name',
        'fatherLivingStatus' => 'Father Living / Dead',
        'fatherTelephone' => 'Father Telephone',
        'fatherEmail' => 'Father Email',
        'fatherHometown' => 'Father Hometown',
        'fatherHouseNumber' => 'Father House Number',
        'fatherPostOfficeBox' => 'Father Post Office Box',
        'fatherNationality' => 'Father Nationality',
        'motherFullName' => 'Mother Full Name',
        'motherLivingStatus' => 'Mother Living / Dead',
        'motherTelephone' => 'Mother Telephone',
        'motherEmail' => 'Mother Email',
        'motherHometown' => 'Mother Hometown',
        'motherHouseNumber' => 'Mother House Number',
        'motherPostOfficeBox' => 'Mother Post Office Box',
        'motherNationality' => 'Mother Nationality',
        'grandparentFullName' => 'Grandparent Full Name',
        'grandparentLivingStatus' => 'Grandparent Living / Dead',
        'grandparentTelephone' => 'Grandparent Telephone',
        'grandparentHometown' => 'Grandparent Home Town',
        'grandparentHouseNumber' => 'Grandparent House Number',
        'grandparentPostOfficeBox' => 'Grandparent Post Office Box',
        'grandparentNationality' => 'Grandparent Nationality',
        'guarantor1FullName' => 'Guarantor 1 Full Name',
        'guarantor1Occupation' => 'Guarantor 1 Occupation',
        'guarantor1Telephone' => 'Guarantor 1 Telephone',
        'guarantor1Email' => 'Guarantor 1 Email',
        'guarantor1HouseNumber' => 'Guarantor 1 House Number',
        'guarantor1PostOfficeBox' => 'Guarantor 1 Post Office Box',
        'guarantor2FullName' => 'Guarantor 2 Full Name',
        'guarantor2Occupation' => 'Guarantor 2 Occupation',
        'guarantor2Telephone' => 'Guarantor 2 Telephone',
        'guarantor2Email' => 'Guarantor 2 Email',
        'guarantor2HouseNumber' => 'Guarantor 2 House Number',
        'guarantor2PostOfficeBox' => 'Guarantor 2 Post Office Box',
        'witnessFullName' => 'Witness Full Name',
        'witnessOccupation' => 'Witness Occupation',
        'witnessWorkAddress' => 'Witness Work Address',
        'witnessWorkTelephone' => 'Witness Work Telephone',
        'witnessHomeTelephone' => 'Witness Home Telephone',
        'witnessHouseAddress' => 'Witness House Address',
        'qualifiedWitness' => 'Qualified Witness',
    ];

    public static function documentLabel(string $documentType): string
    {
        return self::DOCUMENT_LABELS[$documentType] ?? $documentType;
    }

    public static function statusLabel(string $status): string
    {
        return match ($status) {
            'ResubmissionRequired' => 'Resubmission Required',
            default => $status,
        };
    }
}
