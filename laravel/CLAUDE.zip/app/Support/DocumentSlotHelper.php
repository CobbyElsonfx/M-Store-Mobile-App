<?php

namespace App\Support;

class DocumentSlotHelper
{
    /** @var array<string, string> */
    private const SLOT_TO_FIRESTORE_KEY = [
        'ghanaCardFront' => 'ghanaCardFrontUrl',
        'ghanaCardBack' => 'ghanaCardBackUrl',
        'businessCertificate' => 'businessCertificateUrl',
        'formA' => 'formAUrl',
        'formB' => 'formBUrl',
        'formC' => 'formCUrl',
        'signature' => 'signatureUrl',
        'applicantHoldingFront' => 'applicantFrontUrl',
        'applicantHoldingBack' => 'applicantBackUrl',
        'ghanaCard' => 'ghanaCardUrl',
        'birthProof' => 'birthProofUrl',
        'businessCertificateFormA' => 'formAUrl',
        'businessCertificateFormB' => 'formBUrl',
        'businessCertificateFormC' => 'formCUrl',
    ];

    public static function firestoreKeyForSlot(string $slotId): string
    {
        return self::SLOT_TO_FIRESTORE_KEY[$slotId] ?? $slotId.'Url';
    }

    public static function slotForFirestoreKey(string $firestoreKey): string
    {
        foreach (self::SLOT_TO_FIRESTORE_KEY as $slot => $key) {
            if ($key === $firestoreKey) {
                return $slot;
            }
        }

        return str_ends_with($firestoreKey, 'Url')
            ? substr($firestoreKey, 0, -3)
            : $firestoreKey;
    }

    public static function storageFileName(string $slotId, string $originalFilename): string
    {
        $extension = pathinfo($originalFilename, PATHINFO_EXTENSION) ?: 'bin';
        $base = preg_replace('/[^a-z0-9_]+/i', '_', self::slotForFirestoreKey(self::firestoreKeyForSlot($slotId)));

        return strtolower($base).'.'.strtolower($extension);
    }
}
