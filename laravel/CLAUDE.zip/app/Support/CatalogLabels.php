<?php

namespace App\Support;

class CatalogLabels
{
    public const PRODUCT_CATEGORIES = [
        'SIM Cards',
        'Agent Materials',
    ];
}
