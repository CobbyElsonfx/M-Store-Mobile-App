<?php

namespace App\Support;

final class PaystackMoney
{
    public const SUBUNITS_PER_UNIT = 100;

    public static function toSubunits(float|string $amount): int
    {
        return (int) round(((float) $amount) * self::SUBUNITS_PER_UNIT);
    }

    public static function fromSubunits(int $subunits): float
    {
        return round($subunits / self::SUBUNITS_PER_UNIT, 2);
    }

    public static function matches(float|string $majorAmount, int $subunitAmount): bool
    {
        return self::toSubunits($majorAmount) === $subunitAmount;
    }
}
