<?php

namespace App\Support\Migration;

use Carbon\Carbon;

final class FirebaseJson
{
    public static function parseTimestamp(mixed $value): ?Carbon
    {
        if ($value === null) {
            return null;
        }

        if (is_array($value) && ($value['__type'] ?? null) === 'timestamp') {
            return Carbon::parse($value['iso']);
        }

        if (is_string($value)) {
            return Carbon::parse($value);
        }

        return null;
    }

    public static function float(mixed $value, float $default = 0.0): float
    {
        if ($value === null || $value === '') {
            return $default;
        }

        return (float) $value;
    }

    public static function int(mixed $value, int $default = 0): int
    {
        if ($value === null || $value === '') {
            return $default;
        }

        return (int) $value;
    }

    public static function string(mixed $value, string $default = ''): string
    {
        if ($value === null) {
            return $default;
        }

        return (string) $value;
    }

    public static function bool(mixed $value, bool $default = false): bool
    {
        if ($value === null) {
            return $default;
        }

        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
