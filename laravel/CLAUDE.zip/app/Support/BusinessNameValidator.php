<?php

namespace App\Support;

class BusinessNameValidator
{
    private const MAX_LENGTH = 100;

    private const MIN_MEANINGFUL_CHARS = 2;

    /** @var list<string> */
    private const FIELD_KEYS = [
        'businessName',
        'businessName1',
        'businessName2',
        'businessName3',
    ];

    public static function validateFormData(array $formData): ?string
    {
        foreach (self::FIELD_KEYS as $key) {
            $raw = trim((string) ($formData[$key] ?? ''));
            if ($raw === '') {
                continue;
            }

            if ($message = self::validate($raw, self::labelForKey($key))) {
                return $message;
            }
        }

        return null;
    }

    public static function validate(string $value, string $label = 'Business Name'): ?string
    {
        $normalized = trim(preg_replace('/\s+/', ' ', $value) ?? '');

        if ($normalized === '') {
            return "{$label} is required";
        }

        if (strlen($normalized) > self::MAX_LENGTH) {
            return "{$label} must be at most ".self::MAX_LENGTH.' characters';
        }

        if (preg_match_all('/[\p{L}\p{N}]/u', $normalized) < self::MIN_MEANINGFUL_CHARS) {
            return "{$label} must contain at least ".self::MIN_MEANINGFUL_CHARS.' letters or numbers';
        }

        if (preg_match('/<[^>]*>|javascript:|on\w+\s*=|data:/i', $normalized)) {
            return "Enter a valid {$label}";
        }

        if (preg_match('/[<>{}\\\\]/', $normalized)) {
            return "Enter a valid {$label}";
        }

        return null;
    }

    private static function labelForKey(string $key): string
    {
        return match ($key) {
            'businessName1' => 'Business Name Option 1',
            'businessName2' => 'Business Name Option 2',
            'businessName3' => 'Business Name Option 3',
            default => 'Business Name',
        };
    }
}
