<?php

namespace App\Support;

class UssdFlowDefaults
{
    /** @return list<array<string, mixed>> */
    public static function all(): array
    {
        return [
            [
                'flow_key' => 'MTN_CASHIN',
                'name' => 'CASH IN',
                'ussd_code' => '*170#',
                'sort_order' => 1,
                'steps' => [
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'phone'],
                    ['type' => 'phone_confirm'],
                    ['type' => 'amount'],
                    ['type' => 'reference'],
                ],
            ],
            [
                'flow_key' => 'MTN_CASHOUT',
                'name' => 'CASH OUT',
                'ussd_code' => '*171#',
                'sort_order' => 2,
                'steps' => [
                    ['type' => 'menu', 'value' => '2'],
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'phone'],
                    ['type' => 'phone_confirm'],
                    ['type' => 'amount'],
                    ['type' => 'stop'],
                ],
            ],
            [
                'flow_key' => 'AGENT_MERCHANT',
                'name' => 'PAY TO MERCHANT',
                'ussd_code' => '*171#',
                'sort_order' => 3,
                'steps' => [
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'phone'],
                    ['type' => 'phone_confirm'],
                    ['type' => 'amount'],
                    ['type' => 'stop'],
                ],
            ],
            [
                'flow_key' => 'MTN_AIRTIME',
                'name' => 'TRANSFER AIRTIME',
                'ussd_code' => '*171#',
                'sort_order' => 4,
                'steps' => [
                    ['type' => 'menu', 'value' => '5'],
                    ['type' => 'menu', 'value' => '1'],
                    ['type' => 'menu', 'value' => '5'],
                    ['type' => 'phone'],
                    ['type' => 'phone_confirm'],
                    ['type' => 'amount'],
                    ['type' => 'stop'],
                ],
            ],
            [
                'flow_key' => 'BALANCE',
                'name' => 'BALANCE',
                'ussd_code' => '*171#',
                'sort_order' => 5,
                'steps' => [
                    ['type' => 'menu', 'value' => '6'],
                    ['type' => 'stop'],
                ],
            ],
            [
                'flow_key' => 'COMMISSION',
                'name' => 'COMMISSION',
                'ussd_code' => '*171#',
                'sort_order' => 6,
                'steps' => [
                    ['type' => 'menu', 'value' => '7'],
                    ['type' => 'stop'],
                ],
            ],
            [
                'flow_key' => 'EVD_JUST4U',
                'name' => 'EVD/JUST4U',
                'ussd_code' => '*171#',
                'sort_order' => 7,
                'steps' => [
                    ['type' => 'menu', 'value' => '8'],
                    ['type' => 'stop'],
                ],
            ],
        ];
    }

    /** @return list<string> */
    public static function allowedFlowKeys(): array
    {
        return array_column(self::all(), 'flow_key');
    }
}
