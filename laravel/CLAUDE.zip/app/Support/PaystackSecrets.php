<?php

namespace App\Support;

use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;

final class PaystackSecrets
{
    public static function encrypt(string $secret): string
    {
        return Crypt::encryptString($secret);
    }

    public static function decrypt(?string $stored): string
    {
        $stored = trim((string) $stored);
        if ($stored === '') {
            return '';
        }

        try {
            return Crypt::decryptString($stored);
        } catch (DecryptException) {
            return str_starts_with($stored, 'sk_') ? $stored : '';
        }
    }
}
