<?php

namespace App\Support;

class AuditActions
{
    public const LOGIN = 'AdminLogin';

    public const APPLICATION_APPROVAL = 'ApplicationApproval';

    public const APPLICATION_REJECTION = 'ApplicationRejection';

    public const APPLICATION_STATUS_CHANGE = 'ApplicationStatusChange';

    public const ORDER_STATUS_CHANGE = 'OrderStatusChange';

    public const WITHDRAWAL_APPROVAL = 'WithdrawalApproval';

    public const WITHDRAWAL_REJECTION = 'WithdrawalRejection';

    public const WITHDRAWAL_PAID = 'WithdrawalPaid';

    public const USER_SUSPENSION = 'UserSuspension';

    public const USER_ACTIVATION = 'UserActivation';

    public const SUBSCRIPTION_CHANGE = 'SubscriptionChange';

    public const SUBSCRIPTION_REVOKE = 'SubscriptionRevoke';

    public const PRODUCT_CREATE = 'ProductCreate';

    public const PRODUCT_UPDATE = 'ProductUpdate';

    public const PRODUCT_DELETE = 'ProductDelete';

    public const BUSINESS_SETTINGS_CHANGE = 'BusinessSettingsChange';

    public const USSD_FLOW_UPDATE = 'UssdFlowUpdate';

    public const NOTIFICATION_SENT = 'NotificationSent';

    /** @return array<string, string> */
    public static function labels(): array
    {
        return [
            self::LOGIN => 'Admin Login',
            self::APPLICATION_APPROVAL => 'Application Approval',
            self::APPLICATION_REJECTION => 'Application Rejection',
            self::APPLICATION_STATUS_CHANGE => 'Application Status Change',
            self::ORDER_STATUS_CHANGE => 'Order Status Change',
            self::WITHDRAWAL_APPROVAL => 'Withdrawal Approval',
            self::WITHDRAWAL_REJECTION => 'Withdrawal Rejection',
            self::WITHDRAWAL_PAID => 'Withdrawal Paid',
            self::USER_SUSPENSION => 'User Suspension',
            self::USER_ACTIVATION => 'User Activation',
            self::SUBSCRIPTION_CHANGE => 'Subscription Change',
            self::SUBSCRIPTION_REVOKE => 'Subscription Revoke',
            self::PRODUCT_CREATE => 'Product Create',
            self::PRODUCT_UPDATE => 'Product Update',
            self::PRODUCT_DELETE => 'Product Delete',
            self::BUSINESS_SETTINGS_CHANGE => 'Business Settings Change',
            self::USSD_FLOW_UPDATE => 'USSD Flow Update',
            self::NOTIFICATION_SENT => 'Notification Sent',
        ];
    }
}
