<?php

namespace App\Enums;

enum SubscriptionStatus: string
{
    case None = 'None';
    case Trial = 'Trial';
    case Active = 'Active';
    case Expired = 'Expired';
}
