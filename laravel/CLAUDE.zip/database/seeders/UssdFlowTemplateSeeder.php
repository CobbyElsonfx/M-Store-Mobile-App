<?php

namespace Database\Seeders;

use App\Models\UssdFlowTemplate;
use App\Support\UssdFlowDefaults;
use Illuminate\Database\Seeder;

class UssdFlowTemplateSeeder extends Seeder
{
    public function run(): void
    {
        foreach (UssdFlowDefaults::all() as $flow) {
            UssdFlowTemplate::query()->updateOrCreate(
                ['flow_key' => $flow['flow_key']],
                array_merge($flow, ['is_active' => true])
            );
        }
    }
}
