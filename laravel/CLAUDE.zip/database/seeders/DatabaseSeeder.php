<?php

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\BusinessSetting;
use App\Models\Product;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->seedBusinessSettings();
        $this->seedSubscriptionPlans();
        $this->seedProducts();
        $this->seedAdminUser();
        $this->call(UssdFlowTemplateSeeder::class);
    }

    private function seedBusinessSettings(): void
    {
        $settings = [
            'referral_commission_percent' => 40,
            'system_commission_percent' => 60,
            'monthly_subscription_bonus' => 1,
            'minimum_withdrawal' => 10,
            'trial_days' => 7,
            'currency' => 'GHS',
            'tax_rate' => 0,
            'store_enabled' => true,
            'subscription_enabled' => true,
            'referral_share_link_base' => 'https://momokotle.app/ref/',
            'email_reminders_enabled' => true,
            'email_admin_alerts_enabled' => true,
            'subscription_reminder_days' => '7,3,1',
            'admin_notification_emails' => '',
        ];

        foreach ($settings as $key => $value) {
            BusinessSetting::query()->updateOrCreate(
                ['key' => $key],
                ['value' => is_bool($value) ? ($value ? 'true' : 'false') : (string) $value]
            );
        }
    }

    private function seedSubscriptionPlans(): void
    {
        $plans = [
            ['plan_name' => '1 Month', 'price' => 6, 'duration_days' => 30, 'sort_order' => 1],
            ['plan_name' => '3 Months', 'price' => 15, 'duration_days' => 90, 'sort_order' => 2],
            ['plan_name' => '6 Months', 'price' => 30, 'duration_days' => 180, 'sort_order' => 3],
            ['plan_name' => '1 Year', 'price' => 65, 'duration_days' => 365, 'sort_order' => 4],
        ];

        foreach ($plans as $plan) {
            SubscriptionPlan::query()->updateOrCreate(
                ['plan_name' => $plan['plan_name']],
                array_merge($plan, ['id' => (string) \Illuminate\Support\Str::uuid(), 'status' => 'Active'])
            );
        }
    }

    private function seedProducts(): void
    {
        $products = [
            [
                'product_name' => 'MTN Agent SIM',
                'category' => 'SIM Cards',
                'price' => 2650,
                'profit' => 250,
                'referral_percent' => 40,
                'system_percent' => 60,
            ],
            [
                'product_name' => 'Telecel Agent SIM',
                'category' => 'SIM Cards',
                'price' => 350,
                'profit' => 100,
                'referral_percent' => 40,
                'system_percent' => 60,
            ],
            [
                'product_name' => 'AirtelTigo Agent SIM',
                'category' => 'SIM Cards',
                'price' => 350,
                'profit' => 100,
                'referral_percent' => 40,
                'system_percent' => 60,
            ],
            [
                'product_name' => 'EVD SIM Conversion',
                'category' => 'SIM Cards',
                'price' => 350,
                'profit' => 100,
                'referral_percent' => 40,
                'system_percent' => 60,
            ],
        ];

        foreach ($products as $product) {
            Product::query()->updateOrCreate(
                ['product_name' => $product['product_name']],
                array_merge($product, [
                    'id' => (string) \Illuminate\Support\Str::uuid(),
                    'product_description' => $product['product_name'],
                    'stock_quantity' => 0,
                    'is_available' => true,
                ])
            );
        }
    }

    private function seedAdminUser(): void
    {
        User::query()->updateOrCreate(
            ['email' => 'admin@momokotle.test'],
            [
                'name' => 'System Admin',
                'password' => Hash::make('password'),
                'role' => UserRole::Admin,
                'first_name' => 'System',
                'last_name' => 'Admin',
            ]
        );
    }
}
