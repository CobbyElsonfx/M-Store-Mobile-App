<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('referrals', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('referrer_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('referrer_code', 32);
            $table->foreignId('referred_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('referred_user_name');
            $table->timestamp('registration_date');
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('total_orders')->default(0);
            $table->boolean('has_active_subscription')->default(false);
            $table->decimal('wallet_earnings', 12, 2)->default(0);
            $table->timestamps();

            $table->unique('referred_user_id');
            $table->index('referrer_user_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('referrals');
    }
};
