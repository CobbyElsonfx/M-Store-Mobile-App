<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('commission_transactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('order_id')->nullable()->constrained('orders')->nullOnDelete();
            $table->foreignUuid('subscription_id')->nullable()->constrained('subscriptions')->nullOnDelete();
            $table->foreignId('referrer_user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('referred_user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('product_profit', 12, 2);
            $table->decimal('referral_share', 12, 2);
            $table->decimal('system_share', 12, 2);
            $table->decimal('referral_percent', 5, 2);
            $table->decimal('system_percent', 5, 2);
            $table->string('status', 20)->default('Completed');
            $table->timestamps();

            $table->index('referrer_user_id');
            $table->index('order_id');
        });

        Schema::create('revenue_transactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('source', 40);
            $table->decimal('amount', 12, 2);
            $table->foreignUuid('order_id')->nullable()->constrained('orders')->nullOnDelete();
            $table->foreignUuid('subscription_id')->nullable()->constrained('subscriptions')->nullOnDelete();
            $table->string('description');
            $table->timestamps();

            $table->index('source');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('revenue_transactions');
        Schema::dropIfExists('commission_transactions');
    }
};
