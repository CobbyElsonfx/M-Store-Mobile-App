<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('agent_applications', function (Blueprint $table) {
            $table->string('id', 20)->primary();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('form_type');
            $table->string('applicant_name');
            $table->string('phone_number', 30);
            $table->json('form_data');
            $table->string('status', 30)->default('Pending');
            $table->text('admin_note')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('form_type');
        });

        Schema::create('application_documents', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('application_id', 20);
            $table->foreign('application_id')->references('id')->on('agent_applications')->cascadeOnDelete();
            $table->string('document_type', 60);
            $table->string('storage_path');
            $table->string('mime_type', 100)->nullable();
            $table->unsignedBigInteger('file_size')->nullable();
            $table->string('original_filename')->nullable();
            $table->timestamps();

            $table->index(['application_id', 'document_type']);
        });

        Schema::create('daily_counters', function (Blueprint $table) {
            $table->string('counter_key')->primary();
            $table->unsignedInteger('current_value')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('application_documents');
        Schema::dropIfExists('agent_applications');
        Schema::dropIfExists('daily_counters');
    }
};
