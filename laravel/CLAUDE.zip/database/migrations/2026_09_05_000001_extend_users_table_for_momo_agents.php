<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role', 20)->default('agent')->after('password');
            $table->string('first_name')->nullable()->after('role');
            $table->string('last_name')->nullable()->after('first_name');
            $table->string('phone_number', 30)->nullable()->after('last_name');
            $table->string('location')->nullable()->after('phone_number');
            $table->string('account_status', 20)->default('Active')->after('location');
            $table->string('referral_code', 32)->nullable()->unique()->after('account_status');
            $table->string('referred_by_code', 32)->nullable()->after('referral_code');
            $table->foreignId('referred_by_user_id')->nullable()->after('referred_by_code')
                ->constrained('users')->nullOnDelete();
            $table->timestamp('referral_date')->nullable()->after('referred_by_user_id');
            $table->timestamp('trial_start_date')->nullable()->after('referral_date');
            $table->timestamp('trial_end_date')->nullable()->after('trial_start_date');
            $table->boolean('is_trial_used')->default(false)->after('trial_end_date');
            $table->string('subscription_status', 20)->default('None')->after('is_trial_used');
            $table->timestamp('subscription_expiry_date')->nullable()->after('subscription_status');
            $table->uuid('active_subscription_id')->nullable()->after('subscription_expiry_date');
            $table->string('firebase_uid')->nullable()->unique()->after('active_subscription_id');

            $table->index('role');
            $table->index('account_status');
            $table->index('subscription_status');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['referred_by_user_id']);
            $table->dropColumn([
                'role',
                'first_name',
                'last_name',
                'phone_number',
                'location',
                'account_status',
                'referral_code',
                'referred_by_code',
                'referred_by_user_id',
                'referral_date',
                'trial_start_date',
                'trial_end_date',
                'is_trial_used',
                'subscription_status',
                'subscription_expiry_date',
                'active_subscription_id',
                'firebase_uid',
            ]);
        });
    }
};
