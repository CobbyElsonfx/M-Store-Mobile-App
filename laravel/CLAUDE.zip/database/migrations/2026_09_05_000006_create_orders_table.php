<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('product_id', 128)->nullable();
            $table->foreign('product_id')->references('id')->on('products')->nullOnDelete();
            $table->string('agent_name');
            $table->string('item_name');
            $table->unsignedInteger('quantity')->default(1);
            $table->decimal('total_amount', 12, 2);
            $table->string('phone_number', 30);
            $table->string('location')->nullable();
            $table->string('status', 20)->default('Pending');
            $table->boolean('commission_processed')->default(false);
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('commission_processed');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
