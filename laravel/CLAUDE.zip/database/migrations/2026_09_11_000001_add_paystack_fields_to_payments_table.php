<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->string('currency', 8)->default('GHS')->after('amount');
            $table->string('subscription_plan_id', 128)->nullable()->after('user_id');
            $table->string('provider_reference')->nullable()->after('reference');
            $table->json('metadata')->nullable()->after('status');

            $table->foreign('subscription_plan_id')
                ->references('id')
                ->on('subscription_plans')
                ->nullOnDelete();
            $table->unique('reference');
            $table->unique('provider_reference');
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropForeign(['subscription_plan_id']);
            $table->dropUnique(['reference']);
            $table->dropUnique(['provider_reference']);
            $table->dropColumn([
                'currency',
                'subscription_plan_id',
                'provider_reference',
                'metadata',
            ]);
        });
    }
};
