<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ussd_flow_templates', function (Blueprint $table) {
            $table->id();
            $table->string('flow_key')->unique();
            $table->string('name');
            $table->string('ussd_code', 32);
            $table->json('steps');
            $table->boolean('is_active')->default(true);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ussd_flow_templates');
    }
};
