<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->string('id', 128)->primary();
            $table->string('product_name');
            $table->text('product_description')->nullable();
            $table->string('category', 60);
            $table->decimal('price', 12, 2);
            $table->decimal('profit', 12, 2)->default(0);
            $table->decimal('referral_percent', 5, 2)->default(40);
            $table->decimal('system_percent', 5, 2)->default(60);
            $table->unsignedInteger('stock_quantity')->default(0);
            $table->string('image_path')->nullable();
            $table->boolean('is_available')->default(true);
            $table->timestamps();

            $table->index('category');
            $table->index('is_available');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
