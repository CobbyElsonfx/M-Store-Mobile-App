<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('plan_id', 128)->nullable();
            $table->foreign('plan_id')->references('id')->on('subscription_plans')->nullOnDelete();
            $table->string('plan_name');
            $table->decimal('price', 10, 2);
            $table->unsignedInteger('duration_days');
            $table->string('payment_provider', 30)->nullable();
            $table->string('payment_reference')->nullable();
            $table->timestamp('start_date');
            $table->timestamp('end_date');
            $table->string('status', 20)->default('Active');
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('end_date');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
    }
};
