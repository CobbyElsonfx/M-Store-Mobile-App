@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Business metrics for the selected period.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.reports.index') }}">
        <div>
            <label for="filter">Period</label>
            <select id="filter" name="filter">
                @foreach ($filters as $value => $label)
                    <option value="{{ $value }}" @selected($filter === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="start_date">From</label>
            <input id="start_date" name="start_date" type="date" value="{{ $startDate }}">
        </div>
        <div>
            <label for="end_date">To</label>
            <input id="end_date" name="end_date" type="date" value="{{ $endDate }}">
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Apply</button>
        </div>
    </form>

    <div class="detail-grid">
        <div class="stat-box"><strong>Total sales</strong><p>GHS {{ number_format($report['total_sales'], 2) }}</p></div>
        <div class="stat-box"><strong>Total orders</strong><p>{{ $report['total_orders'] }}</p></div>
        <div class="stat-box"><strong>Total revenue</strong><p>GHS {{ number_format($report['total_revenue'], 2) }}</p></div>
        <div class="stat-box"><strong>Subscription revenue</strong><p>GHS {{ number_format($report['subscription_revenue'], 2) }}</p></div>
        <div class="stat-box"><strong>Referral earnings</strong><p>GHS {{ number_format($report['referral_earnings'], 2) }}</p></div>
        <div class="stat-box"><strong>Withdrawals paid</strong><p>GHS {{ number_format($report['withdrawal_total'], 2) }}</p></div>
        <div class="stat-box"><strong>New referrals</strong><p>{{ $report['new_referrals'] }}</p></div>
        <div class="stat-box"><strong>Active subscriptions</strong><p>{{ $report['active_subscriptions'] }}</p></div>
    </div>

    <h2>Orders by status</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Status</th><th>Count</th></tr></thead>
        <tbody>
            @foreach ($report['orders_by_status'] as $status => $count)
                <tr><td>{{ $status }}</td><td>{{ $count }}</td></tr>
            @endforeach
        </tbody>
    </table></div>

    <h2>Top products (delivered quantity)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Product</th><th>Quantity</th></tr></thead>
        <tbody>
            @forelse ($report['top_products'] as $name => $count)
                <tr><td>{{ $name }}</td><td>{{ $count }}</td></tr>
            @empty
                <tr><td colspan="2">No delivered orders in this period.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    <h2>Top referrers (commission earnings)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Referrer</th><th>Earnings</th></tr></thead>
        <tbody>
            @forelse ($report['top_referrers'] as $row)
                @php $user = $row['user']; @endphp
                <tr>
                    <td>{{ $user?->email ?? '—' }}</td>
                    <td>GHS {{ number_format($row['earnings'], 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="2">No commission data in this period.</td></tr>
            @endforelse
        </tbody>
    </table></div>
</div>
@endsection
