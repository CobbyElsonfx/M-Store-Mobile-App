@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Track admin actions across the platform.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.audit-log.index') }}">
        <div>
            <label for="action">Action</label>
            <select id="action" name="action">
                <option value="all" @selected($actionFilter === 'all')>All actions</option>
                @foreach ($actions as $value => $label)
                    <option value="{{ $value }}" @selected($actionFilter === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Time</th>
                <th>Admin</th>
                <th>Action</th>
                <th>Entity</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($logs as $log)
                @php
                    $metadata = $log->metadata ?? [];
                    $oldValue = $metadata['old_value'] ?? null;
                    $newValue = $metadata['new_value'] ?? null;
                    $format = function ($value) {
                        if ($value === null) return '—';
                        return is_scalar($value) ? (string) $value : json_encode($value);
                    };
                @endphp
                <tr>
                    <td>{{ $log->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $log->admin?->email ?? ($metadata['admin_email'] ?? '—') }}</td>
                    <td>{{ $actions[$log->action] ?? $log->action }}</td>
                    <td>
                        @if ($log->entity_type)
                            {{ $log->entity_type }}
                            @if ($log->entity_id)<br><code>{{ $log->entity_id }}</code>@endif
                        @else
                            —
                        @endif
                    </td>
                    <td>
                        @if ($oldValue !== null || $newValue !== null)
                            <small>Old: {{ $format($oldValue) }}<br>New: {{ $format($newValue) }}</small>
                        @else
                            —
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="5">No audit entries yet.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    @include('admin.partials.pagination', ['paginator' => $logs])
</div>
@endsection
