@extends('admin.layout')

@section('content')
<div class="card">
    <p><a href="{{ route('admin.users.index') }}">&larr; Back to users</a></p>

    @php
        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
        if ($name === '') {
            $name = $user->name;
        }
    @endphp

    <h1>{{ $name }}</h1>
    <p>{{ $user->email }}</p>

    <div class="detail-grid">
        <p><strong>Phone:</strong> {{ $user->phone_number ?: '—' }}</p>
        <p><strong>Location:</strong> {{ $user->location ?: '—' }}</p>
        <p><strong>Referral code:</strong> {{ $user->referral_code ?: '—' }}</p>
        <p><strong>Account status:</strong> {{ $user->account_status->value }}</p>
        <p><strong>Joined:</strong> {{ $user->created_at?->format('Y-m-d H:i') }}</p>
        @if ($user->referrer)
            @php
                $referrerName = trim(($user->referrer->first_name ?? '').' '.($user->referrer->last_name ?? ''));
                if ($referrerName === '') {
                    $referrerName = $user->referrer->name;
                }
            @endphp
            <p><strong>Referred by:</strong> {{ $referrerName }} ({{ $user->referrer->email }})</p>
        @endif
    </div>

    <h2>Activity</h2>
    <div class="detail-grid">
        <p><strong>Orders:</strong> {{ $stats['orders'] }}</p>
        <p><strong>Submissions:</strong> {{ $stats['submissions'] }}</p>
        <p><strong>Referrals:</strong> {{ $stats['referrals'] }}</p>
        <p><strong>Wallet balance:</strong> GHS {{ number_format((float) ($stats['wallet']->available_balance ?? 0), 2) }}</p>
        <p><strong>Lifetime earnings:</strong> GHS {{ number_format((float) ($stats['wallet']->lifetime_earnings ?? 0), 2) }}</p>
    </div>

    @php
        $subscriptionStatus = $user->subscription_status?->value ?? 'None';
        $currentPlan = $user->activeSubscription;
    @endphp

    <h2>Subscription</h2>
    <div class="detail-grid">
        <p>
            <strong>Status:</strong>
            <span class="badge {{ strtolower($subscriptionStatus) }}">{{ $subscriptionStatus }}</span>
        </p>
        <p><strong>Plan:</strong> {{ $currentPlan?->plan_name ?? '—' }}</p>
        <p><strong>Expires:</strong> {{ $user->subscription_expiry_date?->format('Y-m-d H:i') ?: '—' }}</p>
        <p><strong>Trial ends:</strong> {{ $user->trial_end_date?->format('Y-m-d H:i') ?: '—' }}</p>
    </div>

    <p class="card-lead">Assigning a plan starts today and lasts for the plan duration. An existing active subscription is replaced. Referral bonuses are not paid for admin changes.</p>

    <form method="POST" action="{{ route('admin.users.update-subscription', $user) }}" class="status-form">
        @csrf
        @method('PATCH')
        <input type="hidden" name="action" value="grant">
        <div>
            <label for="plan_id">Plan</label>
            <select id="plan_id" name="plan_id" required>
                <option value="">Select a plan</option>
                @foreach ($plans as $plan)
                    <option value="{{ $plan->id }}" @selected(old('plan_id') === $plan->id)>
                        {{ $plan->plan_name }} — GHS {{ number_format((float) $plan->price, 2) }} / {{ $plan->duration_days }} days
                    </option>
                @endforeach
            </select>
            @error('plan_id')<small class="field-error">{{ $message }}</small>@enderror
        </div>
        <div>
            <label for="admin_note">Admin note (optional)</label>
            <textarea id="admin_note" name="admin_note" rows="3" placeholder="Why this change was made">{{ old('admin_note') }}</textarea>
            @error('admin_note')<small class="field-error">{{ $message }}</small>@enderror
        </div>
        <button type="submit">Apply plan</button>
    </form>

    <form
        method="POST"
        action="{{ route('admin.users.update-subscription', $user) }}"
        class="status-form"
        onsubmit="return confirm('End this user\'s current subscription?');"
    >
        @csrf
        @method('PATCH')
        <input type="hidden" name="action" value="revoke">
        <button type="submit" class="btn-danger">End subscription</button>
    </form>

    @if ($user->subscriptions->isNotEmpty())
        <h2>Subscription history</h2>
        <div class="table-wrap"><table>
            <thead>
                <tr>
                    <th>Plan</th>
                    <th>Provider</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Status</th>
                    <th>Reference</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($user->subscriptions as $subscription)
                    <tr>
                        <td>{{ $subscription->plan_name }}</td>
                        <td>{{ $subscription->payment_provider ?: '—' }}</td>
                        <td>{{ $subscription->start_date?->format('Y-m-d') }}</td>
                        <td>{{ $subscription->end_date?->format('Y-m-d') }}</td>
                        <td>{{ $subscription->status }}</td>
                        <td>{{ $subscription->payment_reference ?: '—' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table></div>
    @endif

    <h2>Account access</h2>
    <form method="POST" action="{{ route('admin.users.update-status', $user) }}" class="status-form">
        @csrf
        @method('PATCH')
        <div>
            <label for="account_status">Status</label>
            <select id="account_status" name="account_status" required>
                <option value="Active" @selected($user->account_status->value === 'Active')>Active</option>
                <option value="Suspended" @selected($user->account_status->value === 'Suspended')>Suspended</option>
            </select>
        </div>
        <button type="submit">Update status</button>
    </form>
</div>
@endsection
