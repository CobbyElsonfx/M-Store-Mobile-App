@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">View registered agents and manage account access.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.users.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Name, email, phone, referral code">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Referrals</th>
                <th>Wallet</th>
                <th>Subscription</th>
                <th>Status</th>
                <th>Joined</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($users as $user)
                @php
                    $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                    if ($name === '') {
                        $name = $user->name;
                    }
                @endphp
                <tr>
                    <td>{{ $name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->phone_number ?: '—' }}</td>
                    <td>{{ $user->referrals_made_count }}</td>
                    <td>GHS {{ number_format((float) ($user->wallet->available_balance ?? 0), 2) }}</td>
                    <td><span class="badge {{ strtolower($user->subscription_status?->value ?? 'none') }}">{{ $user->subscription_status?->value ?? 'None' }}</span></td>
                    <td><span class="badge {{ strtolower($user->account_status->value) }}">{{ $user->account_status->value }}</span></td>
                    <td>{{ $user->created_at?->format('Y-m-d') }}</td>
                    <td><a href="{{ route('admin.users.show', $user) }}">View</a></td>
                </tr>
            @empty
                <tr>
                    <td colspan="9">No users found.</td>
                </tr>
            @endforelse
        </tbody>
    </table></div>

    <div class="pagination">
        @if ($users->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $users->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($users->getUrlRange(max(1, $users->currentPage() - 2), min($users->lastPage(), $users->currentPage() + 2)) as $page => $url)
            @if ($page == $users->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($users->hasMorePages())
            <a href="{{ $users->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
