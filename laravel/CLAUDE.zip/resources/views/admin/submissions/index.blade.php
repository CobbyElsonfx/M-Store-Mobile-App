@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Review agent form submissions, view documents, and update approval status.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.submissions.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Submission ID, name, phone">
        </div>
        <div>
            <label for="form_type">Form type</label>
            <select id="form_type" name="form_type">
                <option value="all" @selected($formTypeFilter === 'all')>All</option>
                @foreach ($formTypes as $type)
                    <option value="{{ $type }}" @selected($formTypeFilter === $type)>{{ $type }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>
                        {{ \App\Support\SubmissionLabels::statusLabel($status) }}
                    </option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Applicant</th>
                <th>Phone</th>
                <th>Form type</th>
                <th>Status</th>
                <th>Submitted</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($applications as $application)
                <tr>
                    <td><code>{{ $application->id }}</code></td>
                    <td>
                        {{ $application->applicant_name }}
                        @if ($application->user)
                            <br><small>{{ $application->user->email }}</small>
                        @endif
                    </td>
                    <td>{{ $application->phone_number }}</td>
                    <td>{{ $application->form_type }}</td>
                    <td><span class="badge {{ strtolower($application->status) }}">{{ \App\Support\SubmissionLabels::statusLabel($application->status) }}</span></td>
                    <td>{{ $application->created_at?->format('Y-m-d H:i') }}</td>
                    <td><a href="{{ route('admin.submissions.show', $application) }}">View</a></td>
                </tr>
            @empty
                <tr>
                    <td colspan="7">No submissions found.</td>
                </tr>
            @endforelse
        </tbody>
    </table></div>

    <div class="pagination">
        @if ($applications->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $applications->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($applications->getUrlRange(max(1, $applications->currentPage() - 2), min($applications->lastPage(), $applications->currentPage() + 2)) as $page => $url)
            @if ($page == $applications->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($applications->hasMorePages())
            <a href="{{ $applications->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
