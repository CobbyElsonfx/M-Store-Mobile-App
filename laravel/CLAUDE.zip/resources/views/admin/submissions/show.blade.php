@extends('admin.layout')

@section('content')
<div class="card">
    <p><a href="{{ route('admin.submissions.index') }}">&larr; Back to submissions</a></p>

    <h1>{{ $application->id }}</h1>
    <p>{{ $application->form_type }}</p>

    <div class="detail-grid">
        <p><strong>Applicant:</strong> {{ $application->applicant_name }}</p>
        <p><strong>Phone:</strong> {{ $application->phone_number }}</p>
        <p><strong>Status:</strong> {{ \App\Support\SubmissionLabels::statusLabel($application->status) }}</p>
        <p><strong>Submitted:</strong> {{ $application->created_at?->format('Y-m-d H:i') }}</p>
        @if ($application->user)
            <p><strong>User:</strong> {{ $application->user->email }}</p>
        @endif
    </div>

    @if ($application->admin_note)
        <div class="note-box">
            <strong>Admin note</strong>
            <p>{{ $application->admin_note }}</p>
        </div>
    @endif

    <h2>Applicant information</h2>
    <div class="detail-grid">
        @foreach (($application->form_data ?? []) as $key => $value)
            <p>
                <strong>{{ $formFieldLabels[$key] ?? $key }}:</strong>
                {{ $value ?: '—' }}
            </p>
        @endforeach
    </div>

    <h2>Documents</h2>
    @if ($application->documents->isEmpty())
        <p>No documents uploaded.</p>
    @else
        <div class="documents-grid">
            @foreach ($application->documents as $document)
                @php
                    $label = $documentLabels[$document->document_type] ?? $document->document_type;
                    $url = route('admin.submissions.document', [$application, $document->document_type]);
                    $isImage = str_starts_with((string) $document->mime_type, 'image/');
                @endphp
                <div class="document-card">
                    <p><strong>{{ $label }}</strong></p>
                    @if ($isImage)
                        <a href="{{ $url }}" target="_blank" rel="noopener">
                            <img src="{{ $url }}" alt="{{ $label }}" class="document-preview">
                        </a>
                    @endif
                    <p><a href="{{ $url }}" target="_blank" rel="noopener">Open document</a></p>
                </div>
            @endforeach
        </div>
    @endif

    <h2>Update status</h2>
    <form method="POST" action="{{ route('admin.submissions.update-status', $application) }}" class="status-form">
        @csrf
        @method('PATCH')
        <div>
            <label for="status">Status</label>
            <select id="status" name="status" required>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected(old('status', $application->status) === $status)>
                        {{ \App\Support\SubmissionLabels::statusLabel($status) }}
                    </option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="admin_note">Admin note</label>
            <textarea id="admin_note" name="admin_note" rows="4" placeholder='e.g. "Form A is blurry."'>{{ old('admin_note', $application->admin_note) }}</textarea>
        </div>
        <button type="submit">Save status</button>
    </form>
</div>
@endsection
