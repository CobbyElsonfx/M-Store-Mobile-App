@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Configure commission defaults, subscriptions, withdrawals, referral links, and Paystack payment credentials.</p>

    <form method="POST" action="{{ route('admin.settings.business.update') }}" class="status-form wide-form">
        @csrf
        @method('PUT')

        <div class="detail-grid">
            <div>
                <label for="referral_commission_percent">Referral commission (%)</label>
                <input id="referral_commission_percent" name="referral_commission_percent" type="number" step="0.01" min="0" max="100" value="{{ old('referral_commission_percent', $settings['referral_commission_percent']) }}" required>
            </div>
            <div>
                <label for="system_commission_percent">System commission (%)</label>
                <input id="system_commission_percent" name="system_commission_percent" type="number" step="0.01" min="0" max="100" value="{{ old('system_commission_percent', $settings['system_commission_percent']) }}" required>
                @error('system_commission_percent')<small class="field-error">{{ $message }}</small>@enderror
            </div>
            <div>
                <label for="monthly_subscription_bonus">Monthly subscription bonus (GHS)</label>
                <input id="monthly_subscription_bonus" name="monthly_subscription_bonus" type="number" step="0.01" min="0" value="{{ old('monthly_subscription_bonus', $settings['monthly_subscription_bonus']) }}" required>
            </div>
            <div>
                <label for="minimum_withdrawal">Minimum withdrawal (GHS)</label>
                <input id="minimum_withdrawal" name="minimum_withdrawal" type="number" step="0.01" min="0" value="{{ old('minimum_withdrawal', $settings['minimum_withdrawal']) }}" required>
            </div>
            <div>
                <label for="trial_days">Trial days</label>
                <input id="trial_days" name="trial_days" type="number" min="0" value="{{ old('trial_days', $settings['trial_days']) }}" required>
            </div>
            <div>
                <label for="currency">Currency</label>
                <input id="currency" name="currency" type="text" value="{{ old('currency', $settings['currency']) }}" required>
            </div>
            <div>
                <label for="tax_rate">Tax rate (%)</label>
                <input id="tax_rate" name="tax_rate" type="number" step="0.01" min="0" max="100" value="{{ old('tax_rate', $settings['tax_rate']) }}" required>
            </div>
        </div>

        <div>
            <label for="referral_share_link_base">Referral share link base</label>
            <input id="referral_share_link_base" name="referral_share_link_base" type="url" value="{{ old('referral_share_link_base', $settings['referral_share_link_base']) }}" required>
            @error('referral_share_link_base')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div>
            <label for="support_contact">Support contact</label>
            <input id="support_contact" name="support_contact" type="text" value="{{ old('support_contact', $settings['support_contact']) }}" placeholder="Phone or email">
        </div>

        <div class="toggle-row">
            <label><input type="checkbox" name="store_enabled" value="1" @checked(old('store_enabled', $settings['store_enabled']))> Store enabled</label>
            <label><input type="checkbox" name="subscription_enabled" value="1" @checked(old('subscription_enabled', $settings['subscription_enabled']))> Subscriptions enabled</label>
            <label><input type="checkbox" name="maintenance_mode" value="1" @checked(old('maintenance_mode', $settings['maintenance_mode']))> Maintenance mode</label>
        </div>

        <div class="settings-section">
            <h2>Paystack</h2>
            <p class="settings-hint">Used only on the Laravel server for subscription checkout. The secret key is never sent to the Android app or shown again after saving.</p>

            <div>
                <label for="paystack_public_key">Public key</label>
                <input id="paystack_public_key" name="paystack_public_key" type="text" value="{{ old('paystack_public_key', $settings['paystack_public_key']) }}" placeholder="pk_test_..." autocomplete="off" spellcheck="false">
                @error('paystack_public_key')<small class="field-error">{{ $message }}</small>@enderror
            </div>

            <div>
                <label for="paystack_secret_key">Secret key</label>
                <input id="paystack_secret_key" name="paystack_secret_key" type="password" value="" placeholder="{{ $settings['paystack_secret_configured'] ? 'Leave blank to keep the current secret' : 'sk_test_...' }}" autocomplete="new-password" spellcheck="false">
                <small class="settings-hint">{{ $settings['paystack_secret_configured'] ? 'A secret key is already configured.' : 'No secret key is saved yet. TEST keys from Paystack Dashboard can be entered here.' }}</small>
                @error('paystack_secret_key')<small class="field-error">{{ $message }}</small>@enderror
            </div>

            <div>
                <label for="paystack_base_url">API base URL</label>
                <input id="paystack_base_url" name="paystack_base_url" type="url" value="{{ old('paystack_base_url', $settings['paystack_base_url']) }}" placeholder="https://api.paystack.co">
                @error('paystack_base_url')<small class="field-error">{{ $message }}</small>@enderror
            </div>
        </div>

        <div class="settings-section">
            <h2>Email notifications</h2>
            <p class="settings-hint">Transactional emails (payments, subscription activation, application status, and security alerts) are always sent. These settings only control reminders and admin alerts.</p>

            <div class="toggle-row">
                <label><input type="checkbox" name="email_reminders_enabled" value="1" @checked(old('email_reminders_enabled', $settings['email_reminders_enabled']))> Subscription expiry reminders</label>
                <label><input type="checkbox" name="email_admin_alerts_enabled" value="1" @checked(old('email_admin_alerts_enabled', $settings['email_admin_alerts_enabled']))> Admin alert emails</label>
            </div>

            <div>
                <label for="subscription_reminder_days">Reminder days before expiry</label>
                <input id="subscription_reminder_days" name="subscription_reminder_days" type="text" value="{{ old('subscription_reminder_days', $settings['subscription_reminder_days']) }}" placeholder="7,3,1">
                <small class="settings-hint">Comma-separated. Duplicate reminders for the same expiry date are not sent.</small>
            </div>

            <div>
                <label for="admin_notification_emails">Admin notification recipients</label>
                <textarea id="admin_notification_emails" name="admin_notification_emails" rows="3" placeholder="ops@example.com, finance@example.com">{{ old('admin_notification_emails', $settings['admin_notification_emails']) }}</textarea>
                <small class="settings-hint">Used for new registrations, new applications, and payment alerts. Do not hardcode addresses in code.</small>
            </div>
        </div>

        <button type="submit">Save settings</button>
    </form>
</div>
@endsection
