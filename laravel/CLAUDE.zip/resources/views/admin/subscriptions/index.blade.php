@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Agent subscription purchases and status.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.subscriptions.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Plan, email, reference">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Plan</th>
                <th>Price</th>
                <th>Start</th>
                <th>End</th>
                <th>Status</th>
                <th>Reference</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($subscriptions as $subscription)
                <tr>
                    <td>
                        @if ($subscription->user)
                            <a href="{{ route('admin.users.show', $subscription->user) }}">{{ $subscription->user->email }}</a>
                        @else
                            —
                        @endif
                    </td>
                    <td>{{ $subscription->plan_name ?? $subscription->plan?->plan_name ?? '—' }}</td>
                    <td>GHS {{ number_format((float) $subscription->price, 2) }}</td>
                    <td>{{ $subscription->start_date?->format('Y-m-d') }}</td>
                    <td>{{ $subscription->end_date?->format('Y-m-d') }}</td>
                    <td>{{ $subscription->status }}</td>
                    <td>{{ $subscription->payment_reference ?: '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="7">No subscriptions found.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    @include('admin.partials.pagination', ['paginator' => $subscriptions])
</div>
@endsection
