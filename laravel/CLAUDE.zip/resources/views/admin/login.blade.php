<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light">
    <title>Admin Login — MoMo Kotle</title>
    <style>
        :root {
            --color-bg: #f8fafc;
            --color-surface: #ffffff;
            --color-field: #e2e8f0;
            --color-field-focus: #f1f5f9;
            --color-text: #0f172a;
            --color-muted: #475569;
            --color-ink: #141d30;
            --color-accent: #059669;
            --font: "Segoe UI", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        }

        *, *::before, *::after { box-sizing: border-box; }

        html { color-scheme: light; }

        body {
            font-family: var(--font);
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            background: var(--color-bg);
            color: var(--color-text);
            padding: 1.5rem;
        }

        .login-shell {
            width: min(960px, 100%);
            display: grid;
            grid-template-columns: 1fr 1fr;
            background: var(--color-surface);
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 12px 32px rgba(15, 23, 42, 0.08);
        }

        .login-brand {
            padding: 2.5rem 2rem;
            background: #ecfdf5;
            color: var(--color-ink);
            display: flex;
            flex-direction: column;
            justify-content: center;
            border-right: 1px solid #d1fae5;
        }

        .login-brand strong {
            font-size: 1.75rem;
            letter-spacing: -0.03em;
        }

        .login-brand span {
            display: block;
            margin-top: 0.35rem;
            color: var(--color-accent);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }

        .login-brand p {
            margin: 1.5rem 0 0;
            color: var(--color-muted);
            line-height: 1.6;
            font-size: 0.95rem;
        }

        .login-form-panel {
            padding: 2.5rem 2rem;
            color: var(--color-text);
            background: var(--color-surface);
        }

        .login-form-panel h1 {
            margin: 0 0 0.35rem;
            font-size: 1.5rem;
            letter-spacing: -0.02em;
        }

        .login-form-panel > p {
            margin: 0 0 1.5rem;
            color: var(--color-muted);
            font-size: 0.92rem;
        }

        label {
            display: block;
            margin: 1rem 0 0.4rem;
            font-size: 0.82rem;
            font-weight: 600;
            color: var(--color-muted);
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem 0.85rem;
            border: 1px solid #94a3b8;
            border-radius: 8px;
            font: inherit;
            background: var(--color-field);
            color: var(--color-text);
            transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
        }

        input::placeholder {
            color: var(--color-muted);
            opacity: 1;
        }

        input:focus {
            outline: none;
            background: var(--color-field-focus);
            border-color: #6ee7b7;
            box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.15);
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1rem;
            font-size: 0.9rem;
            color: var(--color-muted);
            font-weight: 500;
            text-transform: none;
            letter-spacing: normal;
        }

        button[type="submit"] {
            margin-top: 1.5rem;
            width: 100%;
            padding: 0.85rem;
            border: 0;
            border-radius: 8px;
            background: var(--color-accent);
            color: #fff;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            transition: background 0.15s;
        }

        button[type="submit"]:hover { background: #047857; }

        .error {
            color: #dc2626;
            font-size: 0.88rem;
            margin-top: 1rem;
            padding: 0.65rem 0.75rem;
            background: #fef2f2;
            border-radius: 8px;
            border: 1px solid #fecaca;
        }

        @media (max-width: 720px) {
            .login-shell { grid-template-columns: 1fr; }
            .login-brand { padding: 1.75rem; border-right: 0; border-bottom: 1px solid #d1fae5; }
        }
    </style>
</head>
<body>
    <div class="login-shell">
        <div class="login-brand">
            <strong>MoMo Kotle</strong>
            <span>Admin Console</span>
            <p>Manage agents, orders, submissions, wallets, and platform settings from a single control panel.</p>
        </div>

        <div class="login-form-panel">
            <h1>Sign in</h1>
            <p>Enter your admin credentials to continue.</p>

            <form method="POST" action="{{ route('admin.login.submit') }}">
                @csrf
                <label for="email">Email address</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus>

                <label for="password">Password</label>
                <input id="password" type="password" name="password" required>

                <label class="remember">
                    <input type="checkbox" name="remember"> Remember me
                </label>

                @if ($errors->any())
                    <div class="error">{{ $errors->first() }}</div>
                @endif

                <button type="submit">Sign in to admin</button>
            </form>
        </div>
    </div>
</body>
</html>
