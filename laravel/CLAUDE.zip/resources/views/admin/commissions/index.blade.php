@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Referral commission history from delivered orders.</p>

    <div class="detail-grid">
        <div class="stat-box">
            <strong>Product profit</strong>
            <p>GHS {{ number_format($totals['profit'], 2) }}</p>
        </div>
        <div class="stat-box">
            <strong>Referral share</strong>
            <p>GHS {{ number_format($totals['referral'], 2) }}</p>
        </div>
        <div class="stat-box">
            <strong>System share</strong>
            <p>GHS {{ number_format($totals['system'], 2) }}</p>
        </div>
    </div>

    <form class="toolbar" method="GET" action="{{ route('admin.commissions.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Order ID, product, referrer">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Order</th>
                <th>Referrer</th>
                <th>Profit</th>
                <th>Referral</th>
                <th>System</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($commissions as $commission)
                @php
                    $referrer = $commission->referrer;
                    $referrerName = '—';
                    if ($referrer) {
                        $referrerName = trim(($referrer->first_name ?? '').' '.($referrer->last_name ?? ''));
                        if ($referrerName === '') {
                            $referrerName = $referrer->name ?? $referrer->email;
                        }
                    }
                @endphp
                <tr>
                    <td>{{ $commission->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $commission->order?->item_name ?? $commission->order_id ?? '—' }}</td>
                    <td>{{ $referrerName }}</td>
                    <td>GHS {{ number_format((float) $commission->product_profit, 2) }}</td>
                    <td>GHS {{ number_format((float) $commission->referral_share, 2) }}</td>
                    <td>GHS {{ number_format((float) $commission->system_share, 2) }}</td>
                    <td>{{ $commission->status }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="7">No commission transactions found.</td>
                </tr>
            @endforelse
        </tbody>
    </table></div>

    <div class="pagination">
        @if ($commissions->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $commissions->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($commissions->getUrlRange(max(1, $commissions->currentPage() - 2), min($commissions->lastPage(), $commissions->currentPage() + 2)) as $page => $url)
            @if ($page == $commissions->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($commissions->hasMorePages())
            <a href="{{ $commissions->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
