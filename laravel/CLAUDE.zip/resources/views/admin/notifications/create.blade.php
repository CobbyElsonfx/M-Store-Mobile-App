@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Broadcast in-app notifications to agents via the mobile notification feed.</p>

    <form method="POST" action="{{ route('admin.notifications.store') }}" class="status-form wide-form">
        @csrf

        <div>
            <label for="target">Target audience</label>
            <select id="target" name="target" required>
                @foreach ($targets as $value => $label)
                    <option value="{{ $value }}" @selected(old('target', 'all') === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="user_search">Search user (for specific target)</label>
            <div class="inline-action">
                <input id="user_search" name="user_search" type="search" value="{{ $userSearch }}" placeholder="Name, email, phone">
                <button type="submit" formaction="{{ route('admin.notifications.create') }}" formmethod="GET">Search</button>
            </div>
        </div>

        <div>
            <label for="user_id">User</label>
            <select id="user_id" name="user_id">
                <option value="">Select a user</option>
                @foreach ($users as $user)
                    @php
                        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                        if ($name === '') {
                            $name = $user->name;
                        }
                    @endphp
                    <option value="{{ $user->id }}" @selected((string) old('user_id') === (string) $user->id)>
                        {{ $name }} — {{ $user->email }}
                    </option>
                @endforeach
            </select>
            @error('user_id')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div>
            <label for="title">Title</label>
            <input id="title" name="title" type="text" value="{{ old('title') }}" required>
            @error('title')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div>
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="4" required>{{ old('message') }}</textarea>
            @error('message')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <button type="submit">Send notification</button>
    </form>
</div>
@endsection
