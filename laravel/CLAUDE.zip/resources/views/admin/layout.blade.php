<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light">
    <title>{{ ($title ?? 'Admin') . ' — MoMo Kotle' }}</title>
    @include('admin.partials.styles')
</head>
<body>
    <div class="admin-shell">
        @include('admin.partials.sidebar')

        <div class="admin-main">
            <header class="admin-topbar">
                <div>
                    <h1>{{ $title ?? 'Admin' }}</h1>
                </div>
                <div class="admin-topbar-meta">
                    {{ now()->format('l, M j, Y') }}
                </div>
            </header>

            <main class="admin-content">
                @if (session('status'))
                    <div class="flash">{{ session('status') }}</div>
                @endif
                @if (session('error'))
                    <div class="flash error">{{ session('error') }}</div>
                @endif

                @yield('content')
            </main>
        </div>
    </div>
</body>
</html>
