@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Configure USSD dial codes and menu steps used by the mobile app for Cash In, Cash Out, and other agent actions.</p>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Flow</th>
                    <th>Key</th>
                    <th>USSD Code</th>
                    <th>Steps</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse ($flows as $flow)
                    <tr>
                        <td><strong>{{ $flow->name }}</strong></td>
                        <td><code>{{ $flow->flow_key }}</code></td>
                        <td><code>{{ $flow->ussd_code }}</code></td>
                        <td>{{ count($flow->steps ?? []) }}</td>
                        <td>{{ $flow->is_active ? 'Active' : 'Disabled' }}</td>
                        <td>
                            <a href="{{ route('admin.ussd-flows.edit', $flow) }}">Edit</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6">No USSD flows configured. Run <code>php artisan db:seed --class=UssdFlowTemplateSeeder</code>.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
