@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Update the dial code and automation steps for <strong>{{ $flow->name }}</strong> (<code>{{ $flow->flow_key }}</code>).</p>

    <form method="POST" action="{{ route('admin.ussd-flows.update', $flow) }}" class="status-form wide-form">
        @csrf
        @method('PUT')

        <div class="detail-grid">
            <div>
                <label for="name">Display name</label>
                <input id="name" name="name" type="text" value="{{ old('name', $flow->name) }}" required>
                @error('name')<small class="field-error">{{ $message }}</small>@enderror
            </div>
            <div>
                <label for="ussd_code">USSD dial code</label>
                <input id="ussd_code" name="ussd_code" type="text" value="{{ old('ussd_code', $flow->ussd_code) }}" required placeholder="*171#">
                @error('ussd_code')<small class="field-error">{{ $message }}</small>@enderror
            </div>
        </div>

        <div>
            <label for="steps_text">Steps (one per line)</label>
            <textarea id="steps_text" name="steps_text" rows="12" required>{{ old('steps_text', $stepsText) }}</textarea>
            @error('steps_text')<small class="field-error">{{ $message }}</small>@enderror
            <small class="field-help">
                Menu options: enter the digit/key (e.g. <code>3</code>, <code>1</code>).
                Special tokens: <code>phone</code>, <code>phone_confirm</code>, <code>amount</code>, <code>reference</code>, <code>stop</code>.
                Cash In default is <code>1</code>, <code>1</code>, <code>phone</code>, <code>phone_confirm</code>, <code>amount</code>, <code>reference</code>.
                Automation stops before PIN — the user only enters their PIN on the USSD screen.
            </small>
        </div>

        <div class="toggle-row">
            <label><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $flow->is_active))> Active</label>
        </div>

        <div class="form-actions">
            <button type="submit">Save flow</button>
            <a class="btn btn-secondary" href="{{ route('admin.ussd-flows.index') }}">Back</a>
        </div>
    </form>

    <form method="POST" action="{{ route('admin.ussd-flows.reset', $flow) }}" class="inline" style="margin-top: 1rem" onsubmit="return confirm('Reset this flow to factory defaults?')">
        @csrf
        <button type="submit" class="link danger">Reset to defaults</button>
    </form>
</div>
@endsection
