@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Referral registrations and subscription activity.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.referrals.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Code, name, email">
        </div>
        <div>
            <label for="subscription">Subscription</label>
            <select id="subscription" name="subscription">
                <option value="all" @selected($subscriptionFilter === 'all')>All</option>
                <option value="active" @selected($subscriptionFilter === 'active')>Active subscription</option>
                <option value="inactive" @selected($subscriptionFilter === 'inactive')>No active subscription</option>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Referrer</th>
                <th>Referred user</th>
                <th>Code</th>
                <th>Active sub</th>
                <th>Earnings</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($referrals as $referral)
                <tr>
                    <td>{{ $referral->registration_date?->format('Y-m-d') }}</td>
                    <td>{{ $referral->referrer?->email ?? '—' }}</td>
                    <td>{{ $referral->referred_user_name ?: ($referral->referredUser?->email ?? '—') }}</td>
                    <td><code>{{ $referral->referrer_code }}</code></td>
                    <td>{{ $referral->has_active_subscription ? 'Yes' : 'No' }}</td>
                    <td>GHS {{ number_format((float) $referral->wallet_earnings, 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="6">No referrals found.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    @include('admin.partials.pagination', ['paginator' => $referrals])
</div>
@endsection
