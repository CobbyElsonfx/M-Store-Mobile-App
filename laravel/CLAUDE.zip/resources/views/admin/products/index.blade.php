@extends('admin.layout')

@section('content')
<div class="card">
    <div class="page-header">
        <div>
            <p class="card-lead" style="margin:0">Manage store catalog, pricing, stock, and commission splits.</p>
        </div>
        <a class="btn btn-primary" href="{{ route('admin.products.create') }}">Add product</a>
    </div>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Price</th>
                <th>Profit</th>
                <th>Stock</th>
                <th>Available</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($products as $product)
                <tr>
                    <td>
                        @if ($imageUrl = \App\Http\Controllers\Admin\ProductController::imageUrl($product))
                            <img src="{{ $imageUrl }}" alt="" class="product-thumb">
                        @endif
                        <strong>{{ $product->product_name }}</strong>
                    </td>
                    <td>{{ $product->category }}</td>
                    <td>GHS {{ number_format((float) $product->price, 2) }}</td>
                    <td>GHS {{ number_format((float) $product->profit, 2) }}</td>
                    <td>{{ $product->stock_quantity }}</td>
                    <td>{{ $product->is_available ? 'Yes' : 'No' }}</td>
                    <td>
                        <a href="{{ route('admin.products.edit', $product) }}">Edit</a>
                        <form class="inline" method="POST" action="{{ route('admin.products.destroy', $product) }}" onsubmit="return confirm('Delete this product?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="link danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7">No products yet.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    </div>
</div>
@endsection
