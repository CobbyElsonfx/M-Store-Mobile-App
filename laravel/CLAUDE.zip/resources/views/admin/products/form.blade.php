@extends('admin.layout')

@section('content')
<div class="card">
    <p><a href="{{ route('admin.products.index') }}">&larr; Back to products</a></p>
    <h1>{{ $product ? 'Edit product' : 'Add product' }}</h1>

    <form method="POST" action="{{ $product ? route('admin.products.update', $product) : route('admin.products.store') }}" enctype="multipart/form-data" class="status-form">
        @csrf
        @if ($product)
            @method('PUT')
        @endif

        <div>
            <label for="product_name">Product name</label>
            <input id="product_name" name="product_name" type="text" value="{{ old('product_name', $product->product_name ?? '') }}" required>
            @error('product_name')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div>
            <label for="product_description">Description</label>
            <textarea id="product_description" name="product_description" rows="3" required>{{ old('product_description', $product->product_description ?? '') }}</textarea>
            @error('product_description')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div>
            <label for="category">Category</label>
            <select id="category" name="category" required>
                @foreach ($categories as $category)
                    <option value="{{ $category }}" @selected(old('category', $product->category ?? 'SIM Cards') === $category)>{{ $category }}</option>
                @endforeach
            </select>
        </div>

        <div class="detail-grid">
            <div>
                <label for="price">Price (GHS)</label>
                <input id="price" name="price" type="number" step="0.01" min="0" value="{{ old('price', $product->price ?? 0) }}" required>
            </div>
            <div>
                <label for="profit">Profit (GHS)</label>
                <input id="profit" name="profit" type="number" step="0.01" min="0" value="{{ old('profit', $product->profit ?? 0) }}" required>
            </div>
            <div>
                <label for="referral_percent">Referral %</label>
                <input id="referral_percent" name="referral_percent" type="number" step="0.01" min="0" max="100" value="{{ old('referral_percent', $product->referral_percent ?? 40) }}" required>
            </div>
            <div>
                <label for="system_percent">System %</label>
                <input id="system_percent" name="system_percent" type="number" step="0.01" min="0" max="100" value="{{ old('system_percent', $product->system_percent ?? 60) }}" required>
            </div>
            <div>
                <label for="stock_quantity">Stock</label>
                <input id="stock_quantity" name="stock_quantity" type="number" min="0" value="{{ old('stock_quantity', $product->stock_quantity ?? 0) }}" required>
            </div>
        </div>
        @error('system_percent')<small class="field-error">{{ $message }}</small>@enderror

        <div>
            <label>
                <input type="checkbox" name="is_available" value="1" @checked(old('is_available', $product->is_available ?? true))>
                Available in store
            </label>
        </div>

        <div>
            <label for="image">Product image</label>
            @if ($product && ($imageUrl = \App\Http\Controllers\Admin\ProductController::imageUrl($product)))
                <p><img src="{{ $imageUrl }}" alt="" class="product-preview"></p>
            @endif
            <input id="image" name="image" type="file" accept="image/*">
            @error('image')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <button type="submit">{{ $product ? 'Save changes' : 'Create product' }}</button>
    </form>
</div>
@endsection
