<div class="pagination">
    @if ($paginator->onFirstPage())
        <span>&laquo; Prev</span>
    @else
        <a href="{{ $paginator->previousPageUrl() }}">&laquo; Prev</a>
    @endif

    @foreach ($paginator->getUrlRange(max(1, $paginator->currentPage() - 2), min($paginator->lastPage(), $paginator->currentPage() + 2)) as $page => $url)
        @if ($page == $paginator->currentPage())
            <span class="current">{{ $page }}</span>
        @else
            <a href="{{ $url }}">{{ $page }}</a>
        @endif
    @endforeach

    @if ($paginator->hasMorePages())
        <a href="{{ $paginator->nextPageUrl() }}">Next &raquo;</a>
    @else
        <span>Next &raquo;</span>
    @endif
</div>
