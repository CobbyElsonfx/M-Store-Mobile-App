@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">System revenue summary and transaction history.</p>

    <div class="detail-grid">
        <div class="stat-box">
            <strong>Total revenue</strong>
            <p>GHS {{ number_format($summary['total'], 2) }}</p>
        </div>
        <div class="stat-box">
            <strong>Transactions</strong>
            <p>{{ $summary['transaction_count'] }}</p>
        </div>
        @foreach ($summary['by_source'] as $source => $amount)
            <div class="stat-box">
                <strong>{{ $source }}</strong>
                <p>GHS {{ number_format($amount, 2) }}</p>
            </div>
        @endforeach
    </div>

    <form class="toolbar" method="GET" action="{{ route('admin.revenue.index') }}">
        <div>
            <label for="start_date">From</label>
            <input id="start_date" name="start_date" type="date" value="{{ $startDate }}">
        </div>
        <div>
            <label for="end_date">To</label>
            <input id="end_date" name="end_date" type="date" value="{{ $endDate }}">
        </div>
        <div>
            <label for="source">Source</label>
            <select id="source" name="source">
                <option value="all" @selected($sourceFilter === 'all')>All</option>
                @foreach ($sources as $source)
                    <option value="{{ $source }}" @selected($sourceFilter === $source)>{{ $source }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Apply</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Order</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($transactions as $transaction)
                <tr>
                    <td>{{ $transaction->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $transaction->source }}</td>
                    <td>GHS {{ number_format((float) $transaction->amount, 2) }}</td>
                    <td>{{ $transaction->order_id ?: '—' }}</td>
                    <td>{{ $transaction->description }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="5">No revenue transactions found.</td>
                </tr>
            @endforelse
        </tbody>
    </table></div>

    <div class="pagination">
        @if ($transactions->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $transactions->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($transactions->getUrlRange(max(1, $transactions->currentPage() - 2), min($transactions->lastPage(), $transactions->currentPage() + 2)) as $page => $url)
            @if ($page == $transactions->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($transactions->hasMorePages())
            <a href="{{ $transactions->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
