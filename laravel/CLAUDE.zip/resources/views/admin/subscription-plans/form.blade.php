@extends('admin.layout')

@section('content')
<div class="card">
    <p><a href="{{ route('admin.subscription-plans.index') }}">&larr; Back to plans</a></p>
    <h1>{{ $plan ? 'Edit plan' : 'Add plan' }}</h1>

    <form method="POST" action="{{ $plan ? route('admin.subscription-plans.update', $plan) : route('admin.subscription-plans.store') }}" class="status-form">
        @csrf
        @if ($plan)
            @method('PUT')
        @endif

        <div>
            <label for="plan_name">Plan name</label>
            <input id="plan_name" name="plan_name" type="text" value="{{ old('plan_name', $plan->plan_name ?? '') }}" required>
            @error('plan_name')<small class="field-error">{{ $message }}</small>@enderror
        </div>

        <div class="detail-grid">
            <div>
                <label for="price">Price (GHS)</label>
                <input id="price" name="price" type="number" step="0.01" min="0" value="{{ old('price', $plan->price ?? 0) }}" required>
            </div>
            <div>
                <label for="duration_days">Duration (days)</label>
                <input id="duration_days" name="duration_days" type="number" min="1" value="{{ old('duration_days', $plan->duration_days ?? 30) }}" required>
            </div>
            <div>
                <label for="sort_order">Sort order</label>
                <input id="sort_order" name="sort_order" type="number" min="0" value="{{ old('sort_order', $plan->sort_order ?? 0) }}" required>
            </div>
            <div>
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    @foreach ($statuses as $status)
                        <option value="{{ $status }}" @selected(old('status', $plan->status ?? 'Active') === $status)>{{ $status }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <button type="submit">{{ $plan ? 'Save changes' : 'Create plan' }}</button>
    </form>
</div>
@endsection
