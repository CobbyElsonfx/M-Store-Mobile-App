@extends('admin.layout')

@section('content')
<div class="card">
    <div class="page-header">
        <div>
            <p class="card-lead" style="margin:0">Manage subscription pricing and availability for agents.</p>
        </div>
        <a class="btn btn-primary" href="{{ route('admin.subscription-plans.create') }}">Add plan</a>
    </div>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Order</th>
                <th>Plan</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($plans as $plan)
                <tr>
                    <td>{{ $plan->sort_order }}</td>
                    <td><strong>{{ $plan->plan_name }}</strong></td>
                    <td>GHS {{ number_format((float) $plan->price, 2) }}</td>
                    <td>{{ $plan->duration_days }} days</td>
                    <td><span class="badge {{ strtolower($plan->status) }}">{{ $plan->status }}</span></td>
                    <td>
                        <a href="{{ route('admin.subscription-plans.edit', $plan) }}">Edit</a>
                        <form class="inline" method="POST" action="{{ route('admin.subscription-plans.destroy', $plan) }}" onsubmit="return confirm('Delete this plan?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="link danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6">No subscription plans yet.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    </div>
</div>
@endsection
