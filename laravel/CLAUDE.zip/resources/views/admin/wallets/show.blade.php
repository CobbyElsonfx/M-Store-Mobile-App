@extends('admin.layout')

@section('content')
<div class="card">
    <p><a href="{{ route('admin.wallets.index') }}">&larr; Back to wallets</a></p>
    <h1>Wallet — {{ $wallet->user?->email ?? $wallet->user_id }}</h1>

    <div class="detail-grid">
        <p><strong>Available:</strong> GHS {{ number_format((float) $wallet->available_balance, 2) }}</p>
        <p><strong>Pending:</strong> GHS {{ number_format((float) $wallet->pending_balance, 2) }}</p>
        <p><strong>Withdrawn:</strong> GHS {{ number_format((float) $wallet->withdrawn_balance, 2) }}</p>
        <p><strong>Lifetime earnings:</strong> GHS {{ number_format((float) $wallet->lifetime_earnings, 2) }}</p>
    </div>

    <h2>Recent transactions</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($transactions as $transaction)
                <tr>
                    <td>{{ $transaction->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $transaction->source }}</td>
                    <td>GHS {{ number_format((float) $transaction->amount, 2) }}</td>
                    <td>{{ $transaction->status }}</td>
                    <td>{{ $transaction->description }}</td>
                </tr>
            @empty
                <tr><td colspan="5">No transactions yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
