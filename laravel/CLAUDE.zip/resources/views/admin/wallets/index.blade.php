@extends('admin.layout')

@php
    function admin_user_name($user): string {
        if (!$user) return '—';
        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
        return $name !== '' ? $name : ($user->name ?? $user->email ?? '—');
    }
@endphp

@section('content')
<div class="card">
    <p class="card-lead">Agent wallet balances and transaction history.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.wallets.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Agent name, email, phone">
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Available</th>
                <th>Pending</th>
                <th>Withdrawn</th>
                <th>Lifetime</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($wallets as $wallet)
                <tr>
                    <td>
                        {{ admin_user_name($wallet->user) }}
                        @if ($wallet->user?->email)<br><small>{{ $wallet->user->email }}</small>@endif
                    </td>
                    <td>GHS {{ number_format((float) $wallet->available_balance, 2) }}</td>
                    <td>GHS {{ number_format((float) $wallet->pending_balance, 2) }}</td>
                    <td>GHS {{ number_format((float) $wallet->withdrawn_balance, 2) }}</td>
                    <td>GHS {{ number_format((float) $wallet->lifetime_earnings, 2) }}</td>
                    <td><a href="{{ route('admin.wallets.show', $wallet) }}">View</a></td>
                </tr>
            @empty
                <tr><td colspan="6">No wallets found.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    @include('admin.partials.pagination', ['paginator' => $wallets])
</div>
@endsection
