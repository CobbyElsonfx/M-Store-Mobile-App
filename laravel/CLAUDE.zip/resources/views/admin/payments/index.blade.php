@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Subscription payments. Paystack credentials are never shown here.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.payments.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Email, reference">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Provider</th>
                <th>Reference</th>
                <th>Paystack</th>
                <th>Status</th>
                <th>Paid</th>
                <th>Start</th>
                <th>Expiry</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($payments as $payment)
                <tr>
                    <td>{{ $payment->user?->email ?? '—' }}</td>
                    <td>{{ $payment->plan?->plan_name ?? '—' }}</td>
                    <td>{{ $payment->currency }} {{ number_format((float) $payment->amount, 2) }}</td>
                    <td>{{ $payment->provider }}</td>
                    <td>{{ $payment->reference }}</td>
                    <td>{{ $payment->provider_reference ?: '—' }}</td>
                    <td>{{ $payment->status }}</td>
                    <td>{{ $payment->created_at?->format('Y-m-d H:i') }}</td>
                    <td>{{ $payment->subscription?->start_date?->format('Y-m-d') ?? '—' }}</td>
                    <td>{{ $payment->subscription?->end_date?->format('Y-m-d')
                        ?? $payment->user?->subscription_expiry_date?->format('Y-m-d')
                        ?? '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="10">No payments found.</td></tr>
            @endforelse
        </tbody>
    </table></div>

    @include('admin.partials.pagination', ['paginator' => $payments])
</div>
@endsection
