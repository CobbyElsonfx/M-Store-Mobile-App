@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Manage store orders and trigger referral commission when marking an order as Delivered.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.orders.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Agent, item, phone, location">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Agent</th>
                <th>Item</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Status</th>
                <th>Commission</th>
                <th>Update</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($orders as $order)
                <tr>
                    <td>{{ $order->created_at?->format('Y-m-d H:i') }}</td>
                    <td>
                        {{ $order->agent_name }}
                        @if ($order->user)
                            <br><small>{{ $order->user->email }}</small>
                        @endif
                    </td>
                    <td>{{ $order->item_name }}</td>
                    <td>{{ $order->quantity }}</td>
                    <td>GHS {{ number_format((float) $order->total_amount, 2) }}</td>
                    <td><span class="badge {{ strtolower($order->status) }}">{{ $order->status }}</span></td>
                    <td>{{ $order->commission_processed ? 'Processed' : '—' }}</td>
                    <td>
                        <form method="POST" action="{{ route('admin.orders.update-status', $order) }}">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="return_status" value="{{ request('status') }}">
                            <input type="hidden" name="return_search" value="{{ $search }}">
                            <input type="hidden" name="return_page" value="{{ request('page') }}">
                            <select name="status" onchange="this.form.submit()">
                                @foreach ($statuses as $status)
                                    <option value="{{ $status }}" @selected($order->status === $status)>{{ $status }}</option>
                                @endforeach
                            </select>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8">No orders found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    </div>

    <div class="pagination">
        @if ($orders->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $orders->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($orders->getUrlRange(max(1, $orders->currentPage() - 2), min($orders->lastPage(), $orders->currentPage() + 2)) as $page => $url)
            @if ($page == $orders->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($orders->hasMorePages())
            <a href="{{ $orders->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
