@extends('admin.layout')

@section('content')
<div class="stats-grid">
    <div class="stat-box accent">
        <strong>Total agents</strong>
        <p>{{ number_format($stats['total_users']) }}</p>
    </div>
    <div class="stat-box">
        <strong>Pending orders</strong>
        <p>{{ number_format($stats['pending_orders']) }}</p>
    </div>
    <div class="stat-box">
        <strong>Pending submissions</strong>
        <p>{{ number_format($stats['pending_submissions']) }}</p>
    </div>
    <div class="stat-box">
        <strong>Pending withdrawals</strong>
        <p>{{ number_format($stats['pending_withdrawals']) }}</p>
    </div>
    <div class="stat-box accent">
        <strong>Wallet balance</strong>
        <p>GHS {{ number_format($stats['total_wallet_balance'], 2) }}</p>
    </div>
    <div class="stat-box accent">
        <strong>Revenue this month</strong>
        <p>GHS {{ number_format($stats['monthly_revenue'], 2) }}</p>
    </div>
    <div class="stat-box">
        <strong>Active subscribers</strong>
        <p>{{ number_format($stats['active_subscribers']) }}</p>
    </div>
    <div class="stat-box">
        <strong>Total referrals</strong>
        <p>{{ number_format($stats['total_referrals']) }}</p>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <h2>Quick access</h2>
            <p>Jump to frequently used admin modules.</p>
        </div>
    </div>
    <ul class="quick-links">
        <li><a href="{{ route('admin.reports.index') }}">Reports</a></li>
        <li><a href="{{ route('admin.orders.index') }}">Orders</a></li>
        <li><a href="{{ route('admin.submissions.index') }}">Submissions</a></li>
        <li><a href="{{ route('admin.withdrawals.index') }}">Withdrawals</a></li>
        <li><a href="{{ route('admin.wallets.index') }}">Wallets</a></li>
        <li><a href="{{ route('admin.referrals.index') }}">Referrals</a></li>
        <li><a href="{{ route('admin.subscriptions.index') }}">Subscriptions</a></li>
        <li><a href="{{ route('admin.products.index') }}">Products</a></li>
        <li><a href="{{ route('admin.users.index') }}">Users</a></li>
        <li><a href="{{ route('admin.settings.business.edit') }}">Business Settings</a></li>
        <li><a href="{{ route('admin.audit-log.index') }}">Audit Log</a></li>
    </ul>
</div>
@endsection
