@extends('admin.layout')

@section('content')
<div class="card">
    <p class="card-lead">Review withdrawal requests, approve payouts, and mark completed transfers as paid.</p>

    <form class="toolbar" method="GET" action="{{ route('admin.withdrawals.index') }}">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="{{ $search }}" placeholder="Agent name, email, payment number">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" @selected($statusFilter === 'all')>All</option>
                @foreach ($statuses as $status)
                    <option value="{{ $status }}" @selected($statusFilter === $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Agent</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Payment #</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($withdrawals as $withdrawal)
                @php
                    $user = $withdrawal->user;
                    $agentName = '—';
                    if ($user) {
                        $agentName = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                        if ($agentName === '') {
                            $agentName = $user->name ?? '—';
                        }
                    }
                @endphp
                <tr>
                    <td>{{ $withdrawal->created_at?->format('Y-m-d H:i') }}</td>
                    <td>
                        {{ $agentName }}
                        @if ($user?->email)
                            <br><small>{{ $user->email }}</small>
                        @endif
                    </td>
                    <td>GHS {{ number_format((float) $withdrawal->amount, 2) }}</td>
                    <td>{{ str_replace('_', ' ', $withdrawal->payment_method) }}</td>
                    <td>{{ $withdrawal->payment_number }}</td>
                    <td><span class="badge {{ strtolower($withdrawal->status) }}">{{ $withdrawal->status }}</span></td>
                    <td>
                        @if ($withdrawal->admin_note)
                            <small>Note: {{ $withdrawal->admin_note }}</small><br>
                        @endif

                        @if ($withdrawal->status === 'Pending')
                            <form class="inline-action" method="POST" action="{{ route('admin.withdrawals.update', $withdrawal) }}">
                                @csrf
                                @method('PATCH')
                                @include('admin.withdrawals._return_fields')
                                <input type="hidden" name="action" value="approve">
                                <button type="submit">Approve</button>
                            </form>
                            <form class="inline-action" method="POST" action="{{ route('admin.withdrawals.update', $withdrawal) }}">
                                @csrf
                                @method('PATCH')
                                @include('admin.withdrawals._return_fields')
                                <input type="hidden" name="action" value="reject">
                                <input type="text" name="admin_note" placeholder="Rejection note">
                                <button type="submit" class="btn-danger">Reject</button>
                            </form>
                        @elseif ($withdrawal->status === 'Approved')
                            <form class="inline-action" method="POST" action="{{ route('admin.withdrawals.update', $withdrawal) }}">
                                @csrf
                                @method('PATCH')
                                @include('admin.withdrawals._return_fields')
                                <input type="hidden" name="action" value="mark_paid">
                                <button type="submit">Mark paid</button>
                            </form>
                            <form class="inline-action" method="POST" action="{{ route('admin.withdrawals.update', $withdrawal) }}">
                                @csrf
                                @method('PATCH')
                                @include('admin.withdrawals._return_fields')
                                <input type="hidden" name="action" value="reject">
                                <input type="text" name="admin_note" placeholder="Rejection note">
                                <button type="submit" class="btn-danger">Reject</button>
                            </form>
                        @else
                            —
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7">No withdrawal requests found.</td>
                </tr>
            @endforelse
        </tbody>
    </table></div>

    <div class="pagination">
        @if ($withdrawals->onFirstPage())
            <span>&laquo; Prev</span>
        @else
            <a href="{{ $withdrawals->previousPageUrl() }}">&laquo; Prev</a>
        @endif

        @foreach ($withdrawals->getUrlRange(max(1, $withdrawals->currentPage() - 2), min($withdrawals->lastPage(), $withdrawals->currentPage() + 2)) as $page => $url)
            @if ($page == $withdrawals->currentPage())
                <span class="current">{{ $page }}</span>
            @else
                <a href="{{ $url }}">{{ $page }}</a>
            @endif
        @endforeach

        @if ($withdrawals->hasMorePages())
            <a href="{{ $withdrawals->nextPageUrl() }}">Next &raquo;</a>
        @else
            <span>Next &raquo;</span>
        @endif
    </div>
</div>
@endsection
