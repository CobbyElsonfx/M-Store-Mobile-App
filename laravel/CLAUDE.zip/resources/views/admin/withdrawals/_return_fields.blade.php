<input type="hidden" name="return_status" value="{{ request('status') }}">
<input type="hidden" name="return_search" value="{{ $search ?? request('search') }}">
<input type="hidden" name="return_page" value="{{ request('page') }}">
