<?php

namespace Tests\Unit;

use App\Support\PaystackMoney;
use PHPUnit\Framework\TestCase;

class PaystackMoneyTest extends TestCase
{
    public function test_converts_ghs_to_pesewas(): void
    {
        $this->assertSame(600, PaystackMoney::toSubunits(6));
        $this->assertSame(1500, PaystackMoney::toSubunits(15));
        $this->assertSame(6500, PaystackMoney::toSubunits(65));
        $this->assertTrue(PaystackMoney::matches(6, 600));
        $this->assertFalse(PaystackMoney::matches(6, 601));
    }
}
