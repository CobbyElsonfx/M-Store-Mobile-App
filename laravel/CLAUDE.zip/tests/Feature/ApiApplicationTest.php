<?php

namespace Tests\Feature;

use App\Models\AgentApplication;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ApiApplicationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Storage::fake('agent_documents');
    }

    public function test_application_endpoints_require_authentication(): void
    {
        $this->getJson('/api/applications/next-id')->assertUnauthorized();
        $this->getJson('/api/applications')->assertUnauthorized();
    }

    public function test_agent_can_reserve_submission_id(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $response = $this->getJson('/api/applications/next-id');

        $response->assertOk()
            ->assertJsonStructure(['data' => ['id']]);

        $id = $response->json('data.id');
        $this->assertMatchesRegularExpression('/^SUB\d{12}$/', $id);

        $this->assertDatabaseHas('agent_applications', [
            'id' => $id,
            'user_id' => $agent->id,
            'status' => 'Draft',
        ]);
    }

    public function test_agent_can_upload_document_and_submit_application(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $id = $this->getJson('/api/applications/next-id')->json('data.id');

        $this->postJson("/api/applications/{$id}/documents", [
            'slot_id' => 'ghanaCardFront',
            'file' => UploadedFile::fake()->image('front.jpg'),
        ])->assertOk()
            ->assertJsonStructure(['data' => ['url', 'slotId']]);

        $response = $this->postJson("/api/applications/{$id}/submit", [
            'form_type' => 'Agent Card Request',
            'form_data' => [
                'fullName' => 'Jane Agent',
                'phoneNumber' => '0244123456',
                'businessName' => 'Jane Trading',
            ],
        ]);

        $response->assertOk()
            ->assertJsonPath('data.status', 'Pending')
            ->assertJsonPath('data.applicantName', 'Jane Agent');

        $this->assertDatabaseHas('agent_applications', [
            'id' => $id,
            'status' => 'Pending',
            'form_type' => 'Agent Card Request',
        ]);
    }

    public function test_submit_requires_documents(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $id = $this->getJson('/api/applications/next-id')->json('data.id');

        $this->postJson("/api/applications/{$id}/submit", [
            'form_type' => 'Agent Card Request',
            'form_data' => [
                'fullName' => 'Jane Agent',
                'phoneNumber' => '0244123456',
            ],
        ])->assertUnprocessable();
    }

    public function test_agent_can_list_submitted_applications(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        AgentApplication::query()->create([
            'id' => 'SUB202609050099',
            'user_id' => $agent->id,
            'form_type' => 'Agent Card Request',
            'applicant_name' => 'Jane Agent',
            'phone_number' => '0244123456',
            'form_data' => ['fullName' => 'Jane Agent'],
            'status' => 'Pending',
        ]);

        $this->getJson('/api/applications')
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJsonPath('data.0.id', 'SUB202609050099');
    }

    public function test_draft_applications_are_hidden_from_list(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        AgentApplication::query()->create([
            'id' => 'SUB202609050088',
            'user_id' => $agent->id,
            'form_type' => '',
            'applicant_name' => '',
            'phone_number' => '',
            'form_data' => [],
            'status' => 'Draft',
        ]);

        $this->getJson('/api/applications')
            ->assertOk()
            ->assertJsonCount(0, 'data');
    }

    public function test_agent_can_submit_passport_application(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $id = $this->getJson('/api/applications/next-id')->json('data.id');

        $this->postJson("/api/applications/{$id}/documents", [
            'slot_id' => 'signature',
            'file' => UploadedFile::fake()->image('signature.jpg'),
        ])->assertOk();

        $this->postJson("/api/applications/{$id}/submit", [
            'form_type' => 'Passport Application',
            'form_data' => [
                'surname' => 'Mensah',
                'firstName' => 'Ama',
                'phoneNumber' => '0244123456',
                'emailAddress' => 'ama@example.com',
                'hasFormalEducation' => 'No',
            ],
        ])->assertOk()
            ->assertJsonPath('data.status', 'Pending')
            ->assertJsonPath('data.applicantName', 'Ama Mensah')
            ->assertJsonPath('data.formType', 'Passport Application');

        $this->assertDatabaseHas('agent_applications', [
            'id' => $id,
            'status' => 'Pending',
            'form_type' => 'Passport Application',
            'phone_number' => '0244123456',
        ]);
    }
}
