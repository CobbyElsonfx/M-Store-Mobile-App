<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ApiCatalogTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_catalog_endpoints_require_authentication(): void
    {
        $this->getJson('/api/products')->assertUnauthorized();
        $this->getJson('/api/subscription-plans')->assertUnauthorized();
        $this->getJson('/api/settings/business')->assertUnauthorized();
    }

    public function test_authenticated_agent_can_list_products(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $response = $this->getJson('/api/products');

        $response->assertOk()
            ->assertJsonStructure([
                'data' => [
                    '*' => [
                        'id',
                        'productName',
                        'category',
                        'price',
                        'stockQuantity',
                        'isAvailable',
                    ],
                ],
            ]);

        $this->assertGreaterThanOrEqual(1, count($response->json('data')));
    }

    public function test_authenticated_agent_can_show_product(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $product = Product::query()->firstOrFail();

        $this->getJson("/api/products/{$product->id}")
            ->assertOk()
            ->assertJsonPath('data.id', $product->id)
            ->assertJsonPath('data.productName', $product->product_name);
    }

    public function test_authenticated_agent_can_list_subscription_plans(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $response = $this->getJson('/api/subscription-plans');

        $response->assertOk()
            ->assertJsonStructure([
                'data' => [
                    '*' => ['id', 'planName', 'price', 'durationDays', 'status'],
                ],
            ]);

        $this->assertGreaterThanOrEqual(1, count($response->json('data')));
    }

    public function test_authenticated_agent_can_fetch_business_settings(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $this->getJson('/api/settings/business')
            ->assertOk()
            ->assertJsonPath('data.currency', 'GHS')
            ->assertJsonPath('data.storeEnabled', true)
            ->assertJsonMissingPath('data.paystackSecretKey')
            ->assertJsonMissingPath('data.paystackPublicKey');
    }

    public function test_subscription_plan_show_returns_plan(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();

        $this->getJson("/api/subscription-plans/{$plan->id}")
            ->assertOk()
            ->assertJsonPath('data.planName', $plan->plan_name);
    }
}
