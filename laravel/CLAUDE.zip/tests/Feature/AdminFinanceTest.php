<?php

namespace Tests\Feature;

use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Models\CommissionTransaction;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Product;
use App\Models\RevenueTransaction;
use App\Models\User;
use App\Services\OrderCommissionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminFinanceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_revenue_and_commissions_after_order_delivery(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $product = Product::query()->firstOrFail();
        $product->update(['profit' => 100, 'referral_percent' => 40, 'system_percent' => 60]);

        $referrer = User::factory()->create(['role' => UserRole::Agent]);
        $buyer = User::factory()->create([
            'role' => UserRole::Agent,
            'referred_by_user_id' => $referrer->id,
        ]);

        $order = Order::query()->create([
            'user_id' => $buyer->id,
            'product_id' => $product->id,
            'agent_name' => 'Buyer',
            'item_name' => $product->product_name,
            'quantity' => 1,
            'total_amount' => $product->price,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Delivered',
        ]);

        app(OrderCommissionService::class)->processForOrder($order);

        $this->actingAs($admin)
            ->get('/admin/revenue')
            ->assertOk()
            ->assertSee('Revenue')
            ->assertSee('OrderCommission');

        $this->actingAs($admin)
            ->get('/admin/commissions')
            ->assertOk()
            ->assertSee('Commissions')
            ->assertSee($product->product_name);

        $this->actingAs($admin)
            ->get('/admin/payments')
            ->assertOk()
            ->assertSee('Payments');
        $this->assertSame(1, CommissionTransaction::query()->count());
    }
}
