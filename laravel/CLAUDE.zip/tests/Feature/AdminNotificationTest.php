<?php

namespace Tests\Feature;

use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminNotificationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_send_notification_to_specific_user(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $this->actingAs($admin)
            ->post('/admin/notifications', [
                'target' => 'specific',
                'user_id' => $agent->id,
                'title' => 'Hello Agent',
                'message' => 'This is a test broadcast.',
            ])
            ->assertRedirect('/admin/notifications');

        $this->assertDatabaseHas('notifications', [
            'user_id' => $agent->id,
            'title' => 'Hello Agent',
            'type' => 'AdminBroadcast',
        ]);
    }

    public function test_admin_can_send_bulk_notification_to_trial_users(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        User::factory()->count(2)->create([
            'role' => UserRole::Agent,
            'subscription_status' => SubscriptionStatus::Trial,
        ]);
        User::factory()->create([
            'role' => UserRole::Agent,
            'subscription_status' => SubscriptionStatus::Active,
        ]);

        $this->actingAs($admin)
            ->post('/admin/notifications', [
                'target' => 'trial',
                'title' => 'Trial Reminder',
                'message' => 'Your trial ends soon.',
            ])
            ->assertRedirect('/admin/notifications');

        $this->assertSame(2, Notification::query()->where('type', 'AdminBroadcast')->count());
    }

    public function test_admin_can_view_notifications_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->get('/admin/notifications')
            ->assertOk()
            ->assertSee('Notifications')
            ->assertSee('Send notification');
    }
}
