<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class AdminProductTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Storage::fake('public');
    }

    public function test_admin_can_create_update_and_delete_product(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->post('/admin/products', [
                'product_name' => 'Test SIM Pack',
                'product_description' => 'A test product for admin CRUD.',
                'category' => 'SIM Cards',
                'price' => 500,
                'profit' => 50,
                'referral_percent' => 40,
                'system_percent' => 60,
                'stock_quantity' => 25,
                'is_available' => '1',
                'image' => UploadedFile::fake()->image('sim.jpg'),
            ])
            ->assertRedirect('/admin/products');

        $product = Product::query()->where('product_name', 'Test SIM Pack')->first();
        $this->assertNotNull($product);
        Storage::disk('public')->assertExists($product->image_path);

        $this->actingAs($admin)
            ->put("/admin/products/{$product->id}", [
                'product_name' => 'Updated SIM Pack',
                'product_description' => 'Updated description for testing.',
                'category' => 'Agent Materials',
                'price' => 600,
                'profit' => 75,
                'referral_percent' => 30,
                'system_percent' => 70,
                'stock_quantity' => 10,
                'is_available' => '1',
            ])
            ->assertRedirect('/admin/products');

        $product->refresh();
        $this->assertSame('Updated SIM Pack', $product->product_name);
        $this->assertSame('Agent Materials', $product->category);

        $this->actingAs($admin)
            ->delete("/admin/products/{$product->id}")
            ->assertRedirect('/admin/products');

        $this->assertDatabaseMissing('products', ['id' => $product->id]);
    }

    public function test_product_create_rejects_invalid_commission_split(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->from('/admin/products/create')
            ->post('/admin/products', [
                'product_name' => 'Bad Split Product',
                'product_description' => 'Should fail validation.',
                'category' => 'SIM Cards',
                'price' => 100,
                'profit' => 10,
                'referral_percent' => 40,
                'system_percent' => 50,
                'stock_quantity' => 1,
            ])
            ->assertRedirect('/admin/products/create')
            ->assertSessionHasErrors('system_percent');
    }
}
