<?php

namespace Tests\Feature;

use App\Models\Notification;
use App\Models\Payment;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Support\PaystackMoney;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ApiSubscriptionPurchaseTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_pay_requires_authentication(): void
    {
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->assertUnauthorized();
    }

    public function test_agent_can_initialize_paystack_checkout_without_activating(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $response = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ]);

        $response->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonStructure(['access_code', 'authorization_url', 'reference', 'public_key'])
            ->assertJsonPath('authorization_url', 'https://checkout.paystack.com/test');

        $this->assertStringStartsWith('pk_', (string) $response->json('public_key'));
        $this->assertNull($agent->fresh()->active_subscription_id);
        $this->assertSame('Pending', Payment::query()->where('user_id', $agent->id)->value('status'));
        $this->assertSame((float) $plan->price, (float) Payment::query()->where('user_id', $agent->id)->value('amount'));
    }

    public function test_client_cannot_set_payment_amount(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
            'amount' => 1,
        ])->assertOk();

        $this->assertEquals(
            (float) $plan->price,
            (float) Payment::query()->where('user_id', $agent->id)->value('amount')
        );
    }

    public function test_status_endpoint_verifies_and_activates_successful_payment(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');

        $this->getJson("/api/subscriptions/payment/{$reference}")
            ->assertOk()
            ->assertJsonPath('data.status', 'Confirmed')
            ->assertJsonPath('data.subscriptionActive', true);

        $agent->refresh();
        $this->assertSame('Active', $agent->subscription_status->value);
        $this->assertNotNull($agent->active_subscription_id);
    }

    public function test_webhook_activates_subscription_and_is_idempotent(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');

        $raw = $this->successWebhookPayload($reference, $plan);
        $this->postWebhook($raw)->assertOk();
        $this->postWebhook($raw)->assertOk();

        $this->assertSame(1, Subscription::query()->where('user_id', $agent->id)->count());
        $this->assertSame('Confirmed', Payment::query()->where('reference', $reference)->value('status'));
        $this->assertSame('Active', $agent->fresh()->subscription_status->value);
    }

    public function test_invalid_webhook_signature_is_rejected(): void
    {
        $this->postWebhook('{"event":"charge.success"}', 'invalid')
            ->assertUnauthorized();
    }

    public function test_incorrect_amount_does_not_activate(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan, verifiedAmount: 1);

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');

        $this->getJson("/api/subscriptions/payment/{$reference}")
            ->assertOk()
            ->assertJsonPath('data.status', 'Failed');

        $this->assertNull($agent->fresh()->active_subscription_id);
    }

    public function test_abandoned_payment_does_not_activate(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan, verifiedStatus: 'abandoned');

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');

        $this->getJson("/api/subscriptions/payment/{$reference}")
            ->assertOk()
            ->assertJsonPath('data.status', 'Abandoned')
            ->assertJsonPath('data.subscriptionActive', false);

        $this->assertNull($agent->fresh()->active_subscription_id);
    }

    public function test_failed_payment_does_not_activate(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan, verifiedStatus: 'failed');

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');

        $this->getJson("/api/subscriptions/payment/{$reference}")
            ->assertOk()
            ->assertJsonPath('data.status', 'Failed');

        $this->assertNull($agent->fresh()->active_subscription_id);
    }

    public function test_active_subscription_cannot_initialize_another_payment(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');
        $this->getJson("/api/subscriptions/payment/{$reference}")->assertOk();

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->assertUnprocessable();
    }

    public function test_unconfirmed_checkout_can_be_retried(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan, verifiedStatus: 'abandoned');

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->assertOk();

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->assertOk();

        $this->assertSame(2, Payment::query()->where('user_id', $agent->id)->count());
        $this->assertNull($agent->fresh()->active_subscription_id);
    }

    public function test_expired_user_can_start_a_new_subscription(): void
    {
        $agent = User::factory()->create([
            'subscription_status' => 'Expired',
            'subscription_expiry_date' => now()->subDay(),
        ]);
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->assertOk();
    }

    public function test_referrer_receives_subscription_bonus_after_confirmed_payment(): void
    {
        $referrer = User::factory()->create();
        Wallet::query()->create([
            'user_id' => $referrer->id,
            'available_balance' => 0,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 0,
        ]);

        $referred = User::factory()->create([
            'referred_by_user_id' => $referrer->id,
        ]);

        Referral::query()->create([
            'referrer_user_id' => $referrer->id,
            'referrer_code' => $referrer->referral_code ?? 'REFCODE1',
            'referred_user_id' => $referred->id,
            'referred_user_name' => $referred->name,
            'registration_date' => now(),
            'is_active' => true,
        ]);

        Sanctum::actingAs($referred);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();
        $this->fakePaystack($plan);

        $reference = $this->postJson('/api/subscriptions/pay', [
            'subscription_plan_id' => $plan->id,
        ])->json('reference');
        $this->getJson("/api/subscriptions/payment/{$reference}")->assertOk();

        $wallet = Wallet::query()->where('user_id', $referrer->id)->firstOrFail();
        $this->assertGreaterThan(0, (float) $wallet->available_balance);
        $this->assertTrue(
            WalletTransaction::query()->where('user_id', $referrer->id)->where('source', 'SubscriptionBonus')->exists()
        );
        $this->assertTrue(
            Notification::query()->where('user_id', $referrer->id)->where('type', 'CommissionEarned')->exists()
        );
        $this->assertSame(1, WalletTransaction::query()->where('user_id', $referrer->id)->where('source', 'SubscriptionBonus')->count());

        $this->postWebhook($this->successWebhookPayload($reference, $plan))->assertOk();
        $this->assertSame(1, WalletTransaction::query()->where('user_id', $referrer->id)->where('source', 'SubscriptionBonus')->count());
    }

    public function test_access_level_endpoint_returns_value(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $this->getJson('/api/subscriptions/access-level')
            ->assertOk()
            ->assertJsonStructure(['data' => ['accessLevel']]);
    }

    public function test_unknown_payment_reference_is_rejected(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $this->getJson('/api/subscriptions/payment/not-a-real-reference')
            ->assertUnprocessable();
    }

    public function test_legacy_direct_purchase_endpoint_is_removed(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $plan = SubscriptionPlan::query()->where('status', 'Active')->firstOrFail();

        $this->postJson('/api/subscriptions', [
            'plan_id' => $plan->id,
            'payment_provider' => 'MTN_MOMO',
            'payment_reference' => 'PAY123456',
        ])->assertNotFound();
    }

    private function fakePaystack(
        SubscriptionPlan $plan,
        string $verifiedStatus = 'success',
        ?int $verifiedAmount = null
    ): void {
        $amount = $verifiedAmount ?? PaystackMoney::toSubunits((float) $plan->price);

        Http::fake(function ($request) use ($verifiedStatus, $amount) {
            $url = $request->url();
            if (str_contains($url, '/transaction/initialize')) {
                $body = json_decode($request->body(), true) ?: [];
                $reference = (string) ($body['reference'] ?? 'ref');

                return Http::response([
                    'status' => true,
                    'data' => [
                        'authorization_url' => 'https://checkout.paystack.com/test',
                        'access_code' => 'acc_'.$reference,
                        'reference' => $reference,
                    ],
                ]);
            }

            if (str_contains($url, '/transaction/verify/')) {
                $reference = basename(parse_url($url, PHP_URL_PATH) ?: '');

                return Http::response([
                    'status' => true,
                    'data' => [
                        'id' => 12345,
                        'status' => $verifiedStatus,
                        'reference' => $reference,
                        'amount' => $amount,
                        'currency' => 'GHS',
                    ],
                ]);
            }

            return Http::response(['status' => false], 404);
        });
    }

    private function successWebhookPayload(string $reference, SubscriptionPlan $plan): string
    {
        return json_encode([
            'event' => 'charge.success',
            'data' => [
                'id' => 12345,
                'status' => 'success',
                'reference' => $reference,
                'amount' => PaystackMoney::toSubunits((float) $plan->price),
                'currency' => 'GHS',
            ],
        ], JSON_THROW_ON_ERROR);
    }

    private function postWebhook(string $raw, ?string $signature = null)
    {
        $secret = (string) config('services.paystack.secret_key');

        return $this->call(
            'POST',
            '/api/paystack/webhook',
            [],
            [],
            [],
            [
                'CONTENT_TYPE' => 'application/json',
                'HTTP_ACCEPT' => 'application/json',
                'HTTP_X_PAYSTACK_SIGNATURE' => $signature ?? hash_hmac('sha512', $raw, $secret),
            ],
            $raw
        );
    }
}
