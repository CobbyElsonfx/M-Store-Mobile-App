<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\User;
use App\Models\Wallet;
use App\Services\Migration\FirebaseImportService;
use App\Services\Migration\FirebaseImportVerificationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FirebaseMigrationImportTest extends TestCase
{
    use RefreshDatabase;

    public function test_imports_sample_export_and_verifies_counts(): void
    {
        $fixtureDir = base_path('tests/fixtures/firebase-export/sample');

        $importService = app(FirebaseImportService::class);
        $result = $importService->importFromDirectory($fixtureDir);

        $this->assertArrayHasKey('stats', $result);
        $this->assertDatabaseHas('users', [
            'firebase_uid' => 'firebase-agent-001',
            'email' => 'ama.agent@example.com',
        ]);
        $this->assertDatabaseHas('users', [
            'firebase_uid' => 'firebase-admin-001',
            'email' => 'admin.import@example.com',
        ]);

        $agent = User::query()->where('firebase_uid', 'firebase-agent-001')->first();
        $this->assertNotNull($agent);
        $this->assertTrue(Wallet::query()->where('user_id', $agent->id)->exists());
        $this->assertTrue(Product::query()->where('id', 'prod-001')->exists());

        $verifyService = app(FirebaseImportVerificationService::class);
        $report = $verifyService->verify($fixtureDir);

        $this->assertTrue($report['passed']);
    }

    public function test_import_command_runs_with_dir_option(): void
    {
        $fixtureDir = base_path('tests/fixtures/firebase-export/sample');

        $this->artisan('migration:import-firebase', ['--dir' => $fixtureDir])
            ->assertSuccessful();

        $this->artisan('migration:verify-firebase', ['--dir' => $fixtureDir])
            ->assertSuccessful();
    }
}
