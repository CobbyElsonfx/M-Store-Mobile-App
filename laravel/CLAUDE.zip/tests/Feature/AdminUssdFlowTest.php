<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\UssdFlowTemplate;
use App\Support\UssdFlowDefaults;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminUssdFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_view_and_update_ussd_flows(): void
    {
        $this->seed();

        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $flow = UssdFlowTemplate::query()->where('flow_key', 'MTN_CASHIN')->firstOrFail();
        $this->assertSame(
            ['menu', 'menu', 'phone', 'phone_confirm', 'amount', 'reference'],
            collect($flow->steps)->pluck('type')->all()
        );

        $this->actingAs($admin)
            ->get(route('admin.ussd-flows.index'))
            ->assertOk()
            ->assertSee('USSD Flows')
            ->assertSee('CASH IN');

        $this->actingAs($admin)
            ->put(route('admin.ussd-flows.update', $flow), [
                'name' => 'Cash In Updated',
                'ussd_code' => '*170#',
                'steps_text' => "1\n1\nphone\nphone_confirm\namount\nreference",
                'is_active' => '1',
            ])
            ->assertRedirect(route('admin.ussd-flows.index'));

        $flow->refresh();
        $this->assertSame('Cash In Updated', $flow->name);
        $this->assertSame('*170#', $flow->ussd_code);
        $this->assertSame('1', $flow->steps[0]['value']);
    }

    public function test_admin_can_reset_ussd_flow_to_defaults(): void
    {
        $this->seed();

        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $flow = UssdFlowTemplate::query()->where('flow_key', 'MTN_CASHOUT')->firstOrFail();
        $flow->update(['ussd_code' => '*999#']);

        $this->actingAs($admin)
            ->post(route('admin.ussd-flows.reset', $flow))
            ->assertRedirect(route('admin.ussd-flows.edit', $flow));

        $this->assertSame(
            collect(UssdFlowDefaults::all())->firstWhere('flow_key', 'MTN_CASHOUT')['ussd_code'],
            $flow->fresh()->ussd_code
        );
    }
}
