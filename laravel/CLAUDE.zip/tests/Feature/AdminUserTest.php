<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminUserTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_users_and_suspend_agent(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $agent = User::factory()->create([
            'role' => UserRole::Agent,
            'first_name' => 'Test',
            'last_name' => 'Agent',
        ]);

        $this->actingAs($admin)
            ->get('/admin/users')
            ->assertOk()
            ->assertSee('Test Agent')
            ->assertSee($agent->email);

        $this->actingAs($admin)
            ->get("/admin/users/{$agent->id}")
            ->assertOk()
            ->assertSee($agent->email);

        $this->actingAs($admin)
            ->patch("/admin/users/{$agent->id}/status", [
                'account_status' => 'Suspended',
            ])
            ->assertRedirect("/admin/users/{$agent->id}");

        $agent->refresh();
        $this->assertSame('Suspended', $agent->account_status->value);

        $this->assertDatabaseHas('notifications', [
            'user_id' => $agent->id,
            'type' => 'AccountSuspended',
        ]);
    }

    public function test_admin_cannot_view_other_admin_as_agent_user(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->get("/admin/users/{$admin->id}")
            ->assertNotFound();
    }

    public function test_admin_users_list_excludes_admin_accounts(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $agent = User::factory()->create(['role' => UserRole::Agent, 'email' => 'agent.only@example.com']);

        $response = $this->actingAs($admin)->get('/admin/users');

        $response->assertOk()
            ->assertSee($agent->email);

        $this->assertFalse(
            User::query()->where('role', UserRole::Agent)->where('email', 'admin@momokotle.test')->exists()
        );
    }
}
