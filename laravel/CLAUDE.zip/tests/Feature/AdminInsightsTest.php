<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminInsightsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_dashboard_reports_wallets_referrals_and_subscriptions(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        Wallet::query()->create([
            'user_id' => $agent->id,
            'available_balance' => 50,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 50,
        ]);

        WalletTransaction::query()->create([
            'user_id' => $agent->id,
            'amount' => 10,
            'source' => 'OrderCommission',
            'description' => 'Test commission',
            'reference' => 'order-1',
            'status' => 'Completed',
        ]);

        Referral::query()->create([
            'referrer_user_id' => User::factory()->create(['role' => UserRole::Agent])->id,
            'referrer_code' => 'REFCODE1',
            'referred_user_id' => $agent->id,
            'referred_user_name' => 'Referred Agent',
            'registration_date' => now(),
            'is_active' => true,
        ]);

        Subscription::query()->create([
            'user_id' => $agent->id,
            'plan_id' => null,
            'plan_name' => '1 Month',
            'price' => 6,
            'duration_days' => 30,
            'payment_provider' => 'MTN_MOMO',
            'payment_reference' => 'PAY123',
            'start_date' => now(),
            'end_date' => now()->addDays(30),
            'status' => 'Active',
        ]);

        $this->actingAs($admin)->get('/admin')->assertOk()->assertSee('Pending orders');
        $this->actingAs($admin)->get('/admin/reports')->assertOk()->assertSee('Total sales');
        $this->actingAs($admin)->get('/admin/wallets')->assertOk()->assertSee('50.00');
        $this->actingAs($admin)->get("/admin/wallets/{$agent->id}")->assertOk()->assertSee('OrderCommission');
        $this->actingAs($admin)->get('/admin/referrals')->assertOk()->assertSee('REFCODE1');
        $this->actingAs($admin)->get('/admin/subscriptions')->assertOk()->assertSee('PAY123');
    }
}
