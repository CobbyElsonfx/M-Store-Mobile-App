<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\AuditLog;
use App\Models\Notification;
use App\Models\Referral;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Services\SubscriptionAccessService;
use App\Support\AuditActions;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminUserSubscriptionTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_subscription_controls_on_user_page(): void
    {
        $admin = $this->admin();
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        $plan = $this->monthPlan();

        $this->actingAs($admin)
            ->get("/admin/users/{$agent->id}")
            ->assertOk()
            ->assertSee('Subscription')
            ->assertSee('Apply plan')
            ->assertSee('End subscription')
            ->assertSee($plan->plan_name);
    }

    public function test_admin_can_grant_a_plan_to_an_agent(): void
    {
        $admin = $this->admin();
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        $plan = $this->monthPlan();

        $this->actingAs($admin)
            ->patch("/admin/users/{$agent->id}/subscription", [
                'action' => 'grant',
                'plan_id' => $plan->id,
                'admin_note' => 'Complimentary cover',
            ])
            ->assertRedirect("/admin/users/{$agent->id}");

        $agent->refresh();

        $this->assertSame('Active', $agent->subscription_status->value);
        $this->assertNotNull($agent->active_subscription_id);
        $this->assertTrue($agent->subscription_expiry_date->gt(now()->addDays($plan->duration_days - 1)));

        $subscription = Subscription::query()->findOrFail($agent->active_subscription_id);
        $this->assertSame($plan->id, $subscription->plan_id);
        $this->assertSame($plan->plan_name, $subscription->plan_name);
        $this->assertSame('Active', $subscription->status);
        $this->assertSame('ADMIN', $subscription->payment_provider);
        $this->assertStringStartsWith('ADMIN_', (string) $subscription->payment_reference);

        $this->assertSame('full', app(SubscriptionAccessService::class)->resolveAccessLevel($agent));

        $this->assertDatabaseHas('notifications', [
            'user_id' => $agent->id,
            'type' => 'General',
            'title' => 'Subscription Updated',
        ]);

        $this->assertTrue(
            AuditLog::query()
                ->where('admin_user_id', $admin->id)
                ->where('action', AuditActions::SUBSCRIPTION_CHANGE)
                ->where('entity_id', (string) $agent->id)
                ->exists()
        );
    }

    public function test_granting_a_plan_replaces_the_existing_active_subscription(): void
    {
        $admin = $this->admin();
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        $month = $this->monthPlan();
        $quarter = SubscriptionPlan::query()
            ->where('status', 'Active')
            ->where('id', '!=', $month->id)
            ->orderBy('duration_days')
            ->firstOrFail();

        $this->actingAs($admin)
            ->patch("/admin/users/{$agent->id}/subscription", [
                'action' => 'grant',
                'plan_id' => $month->id,
            ])
            ->assertRedirect("/admin/users/{$agent->id}");

        $firstId = $agent->fresh()->active_subscription_id;

        $this->actingAs($admin)
            ->patch("/admin/users/{$agent->id}/subscription", [
                'action' => 'grant',
                'plan_id' => $quarter->id,
            ])
            ->assertRedirect("/admin/users/{$agent->id}");

        $agent->refresh();
        $this->assertSame($quarter->plan_name, $agent->activeSubscription?->plan_name);
        $this->assertNotSame($firstId, $agent->active_subscription_id);
        $this->assertSame('Expired', Subscription::query()->findOrFail($firstId)->status);
        $this->assertSame(1, Subscription::query()->where('user_id', $agent->id)->where('status', 'Active')->count());
    }

    public function test_admin_can_revoke_a_subscription(): void
    {
        $admin = $this->admin();
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        $plan = $this->monthPlan();

        $this->actingAs($admin)->patch("/admin/users/{$agent->id}/subscription", [
            'action' => 'grant',
            'plan_id' => $plan->id,
        ]);

        $subscriptionId = $agent->fresh()->active_subscription_id;

        $this->actingAs($admin)
            ->patch("/admin/users/{$agent->id}/subscription", [
                'action' => 'revoke',
            ])
            ->assertRedirect("/admin/users/{$agent->id}");

        $agent->refresh();
        $this->assertSame('Expired', $agent->subscription_status->value);
        $this->assertNull($agent->active_subscription_id);
        $this->assertSame('Expired', Subscription::query()->findOrFail($subscriptionId)->status);
        $this->assertSame(
            'subscription_required',
            app(SubscriptionAccessService::class)->resolveAccessLevel($agent)
        );

        $this->assertDatabaseHas('notifications', [
            'user_id' => $agent->id,
            'type' => 'SubscriptionExpired',
        ]);

        $this->assertTrue(
            AuditLog::query()
                ->where('action', AuditActions::SUBSCRIPTION_REVOKE)
                ->where('entity_id', (string) $agent->id)
                ->exists()
        );
    }

    public function test_admin_grant_does_not_pay_referral_bonus(): void
    {
        $admin = $this->admin();
        $referrer = User::factory()->create();
        Wallet::query()->create([
            'user_id' => $referrer->id,
            'available_balance' => 0,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 0,
        ]);

        $agent = User::factory()->create([
            'role' => UserRole::Agent,
            'referred_by_user_id' => $referrer->id,
        ]);

        Referral::query()->create([
            'referrer_user_id' => $referrer->id,
            'referrer_code' => $referrer->referral_code ?? 'REFCODE1',
            'referred_user_id' => $agent->id,
            'referred_user_name' => $agent->name,
            'registration_date' => now(),
            'is_active' => true,
        ]);

        $this->actingAs($admin)->patch("/admin/users/{$agent->id}/subscription", [
            'action' => 'grant',
            'plan_id' => $this->monthPlan()->id,
        ])->assertRedirect();

        $this->assertSame(0.0, (float) Wallet::query()->where('user_id', $referrer->id)->value('available_balance'));
        $this->assertFalse(
            WalletTransaction::query()->where('user_id', $referrer->id)->where('source', 'SubscriptionBonus')->exists()
        );
        $this->assertTrue(
            Referral::query()->where('referred_user_id', $agent->id)->value('has_active_subscription')
        );
    }

    public function test_agent_cannot_change_another_users_subscription(): void
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        $target = User::factory()->create(['role' => UserRole::Agent]);

        $this->actingAs($agent)
            ->patch("/admin/users/{$target->id}/subscription", [
                'action' => 'grant',
                'plan_id' => $this->monthPlan()->id,
            ])
            ->assertForbidden();
    }

    public function test_admin_cannot_change_admin_subscription_from_users_page(): void
    {
        $admin = $this->admin();

        $this->actingAs($admin)
            ->patch("/admin/users/{$admin->id}/subscription", [
                'action' => 'grant',
                'plan_id' => $this->monthPlan()->id,
            ])
            ->assertNotFound();
    }

    private function admin(): User
    {
        return User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
    }

    private function monthPlan(): SubscriptionPlan
    {
        return SubscriptionPlan::query()
            ->where('status', 'Active')
            ->orderBy('duration_days')
            ->firstOrFail();
    }
}
