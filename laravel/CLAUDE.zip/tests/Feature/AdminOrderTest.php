<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\CommissionTransaction;
use App\Models\Order;
use App\Models\Product;
use App\Models\RevenueTransaction;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminOrderTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_orders_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->get('/admin/orders')
            ->assertOk()
            ->assertSee('Orders');
    }

    public function test_marking_order_delivered_processes_commission(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $product = Product::query()->firstOrFail();
        $product->update(['profit' => 250, 'referral_percent' => 40, 'system_percent' => 60]);

        $referrer = User::factory()->create(['role' => UserRole::Agent]);
        $buyer = User::factory()->create([
            'role' => UserRole::Agent,
            'referred_by_user_id' => $referrer->id,
        ]);

        $order = Order::query()->create([
            'user_id' => $buyer->id,
            'product_id' => $product->id,
            'agent_name' => 'Buyer Agent',
            'item_name' => $product->product_name,
            'quantity' => 2,
            'total_amount' => 5300,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Processing',
        ]);

        $this->actingAs($admin)
            ->patch("/admin/orders/{$order->id}/status", ['status' => 'Delivered'])
            ->assertRedirect('/admin/orders');

        $order->refresh();
        $this->assertTrue($order->commission_processed);
        $this->assertSame('Delivered', $order->status);

        $wallet = Wallet::query()->where('user_id', $referrer->id)->first();
        $this->assertNotNull($wallet);
        $this->assertEqualsWithDelta(200.0, (float) $wallet->available_balance, 0.001);

        $this->assertDatabaseHas('commission_transactions', [
            'order_id' => $order->id,
            'referrer_user_id' => $referrer->id,
            'referred_user_id' => $buyer->id,
        ]);

        $this->assertDatabaseHas('revenue_transactions', [
            'order_id' => $order->id,
            'source' => 'OrderCommission',
        ]);

        $this->assertSame(1, WalletTransaction::query()->where('user_id', $referrer->id)->count());
        $this->assertSame(1, CommissionTransaction::query()->where('order_id', $order->id)->count());
        $this->assertSame(1, RevenueTransaction::query()->where('order_id', $order->id)->count());
    }

    public function test_commission_is_not_processed_twice(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $product = Product::query()->firstOrFail();

        $referrer = User::factory()->create(['role' => UserRole::Agent]);
        $buyer = User::factory()->create([
            'role' => UserRole::Agent,
            'referred_by_user_id' => $referrer->id,
        ]);

        $order = Order::query()->create([
            'user_id' => $buyer->id,
            'product_id' => $product->id,
            'agent_name' => 'Buyer Agent',
            'item_name' => $product->product_name,
            'quantity' => 1,
            'total_amount' => $product->price,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Delivered',
            'commission_processed' => true,
        ]);

        $this->actingAs($admin)
            ->patch("/admin/orders/{$order->id}/status", ['status' => 'Delivered'])
            ->assertRedirect('/admin/orders');

        $this->assertSame(0, CommissionTransaction::query()->count());
    }
}
