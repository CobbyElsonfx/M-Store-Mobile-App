<?php

namespace Tests\Feature;

use App\Models\SubscriptionPlan;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminSubscriptionPlanTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_create_update_and_delete_subscription_plan(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->post('/admin/subscription-plans', [
                'plan_name' => '2 Weeks Trial Plus',
                'price' => 3,
                'duration_days' => 14,
                'status' => 'Active',
                'sort_order' => 5,
            ])
            ->assertRedirect('/admin/subscription-plans');

        $plan = SubscriptionPlan::query()->where('plan_name', '2 Weeks Trial Plus')->first();
        $this->assertNotNull($plan);

        $this->actingAs($admin)
            ->put("/admin/subscription-plans/{$plan->id}", [
                'plan_name' => '2 Weeks Plus',
                'price' => 4,
                'duration_days' => 14,
                'status' => 'Disabled',
                'sort_order' => 6,
            ])
            ->assertRedirect('/admin/subscription-plans');

        $plan->refresh();
        $this->assertSame('2 Weeks Plus', $plan->plan_name);
        $this->assertSame('Disabled', $plan->status);

        $this->actingAs($admin)
            ->delete("/admin/subscription-plans/{$plan->id}")
            ->assertRedirect('/admin/subscription-plans');

        $this->assertDatabaseMissing('subscription_plans', ['id' => $plan->id]);
    }

    public function test_admin_can_view_subscription_plans_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->get('/admin/subscription-plans')
            ->assertOk()
            ->assertSee('Subscription Plans')
            ->assertSee('1 Month');
    }
}
