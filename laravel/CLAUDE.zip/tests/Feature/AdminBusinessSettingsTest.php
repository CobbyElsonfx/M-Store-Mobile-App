<?php

namespace Tests\Feature;

use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Services\BusinessSettingsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AdminBusinessSettingsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_and_update_business_settings(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->get('/admin/settings/business')
            ->assertOk()
            ->assertSee('Business Settings');

        $this->actingAs($admin)
            ->put('/admin/settings/business', [
                'referral_commission_percent' => 35,
                'system_commission_percent' => 65,
                'monthly_subscription_bonus' => 2,
                'minimum_withdrawal' => 15,
                'trial_days' => 14,
                'currency' => 'GHS',
                'tax_rate' => 0,
                'referral_share_link_base' => 'https://momokotle.app/ref/',
                'support_contact' => 'support@momokotle.test',
                'store_enabled' => '1',
                'subscription_enabled' => '1',
                'maintenance_mode' => '0',
            ])
            ->assertRedirect('/admin/settings/business');

        /** @var BusinessSettingsService $settings */
        $settings = app(BusinessSettingsService::class);
        $this->assertSame(15.0, $settings->getFloat('minimum_withdrawal'));
        $this->assertSame('support@momokotle.test', $settings->get('support_contact'));

        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $this->getJson('/api/settings/business')
            ->assertOk()
            ->assertJsonPath('data.minimumWithdrawal', 15)
            ->assertJsonMissingPath('data.paystackSecretKey')
            ->assertJsonMissingPath('data.paystackPublicKey')
            ->assertJsonMissingPath('data.paystack_secret_key');
    }

    public function test_admin_can_save_paystack_credentials(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $secret = 'sk_test_admindashboardsecret';

        $this->actingAs($admin)
            ->get('/admin/settings/business')
            ->assertOk()
            ->assertSee('Paystack')
            ->assertDontSee($secret);

        $this->actingAs($admin)
            ->put('/admin/settings/business', $this->settingsPayload([
                'paystack_public_key' => 'pk_test_admindashboardpublic',
                'paystack_secret_key' => $secret,
                'paystack_base_url' => 'https://api.paystack.co',
            ]))
            ->assertRedirect('/admin/settings/business');

        $stored = \App\Models\BusinessSetting::query()->where('key', 'paystack_secret_key')->value('value');
        $this->assertNotSame($secret, $stored);
        $this->assertSame($secret, \App\Support\PaystackSecrets::decrypt((string) $stored));

        $paystack = app(\App\Services\PaystackClient::class);
        $this->assertSame('pk_test_admindashboardpublic', $paystack->publicKey());
        $this->assertSame($secret, $paystack->secretKey());

        $this->actingAs($admin)
            ->get('/admin/settings/business')
            ->assertOk()
            ->assertSee('pk_test_admindashboardpublic')
            ->assertSee('A secret key is already configured.')
            ->assertDontSee($secret);

        $agent = User::factory()->create();
        Sanctum::actingAs($agent);
        $this->getJson('/api/settings/business')
            ->assertOk()
            ->assertDontSee($secret)
            ->assertJsonMissingPath('data.paystackSecretKey');
    }

    public function test_blank_paystack_secret_keeps_the_saved_key(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->put('/admin/settings/business', $this->settingsPayload([
                'paystack_public_key' => 'pk_test_keepme',
                'paystack_secret_key' => 'sk_test_originalsecretkey',
            ]))
            ->assertRedirect('/admin/settings/business');

        $this->actingAs($admin)
            ->put('/admin/settings/business', $this->settingsPayload([
                'paystack_public_key' => 'pk_test_keepme',
                'paystack_secret_key' => '',
            ]))
            ->assertRedirect('/admin/settings/business');

        $this->assertSame(
            'sk_test_originalsecretkey',
            app(\App\Services\PaystackClient::class)->secretKey()
        );
    }

    public function test_invalid_paystack_keys_are_rejected(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->from('/admin/settings/business')
            ->put('/admin/settings/business', $this->settingsPayload([
                'paystack_public_key' => 'not-a-paystack-key',
                'paystack_secret_key' => 'also-invalid',
            ]))
            ->assertRedirect('/admin/settings/business')
            ->assertSessionHasErrors(['paystack_public_key', 'paystack_secret_key']);
    }

    public function test_paystack_webhook_uses_admin_saved_secret(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $secret = 'sk_test_webhookfromadmin';

        $this->actingAs($admin)
            ->put('/admin/settings/business', $this->settingsPayload([
                'paystack_secret_key' => $secret,
            ]))
            ->assertRedirect('/admin/settings/business');

        $raw = '{"event":"charge.success","data":{"reference":"unknown"}}';

        $this->call(
            'POST',
            '/api/paystack/webhook',
            [],
            [],
            [],
            [
                'CONTENT_TYPE' => 'application/json',
                'HTTP_X_PAYSTACK_SIGNATURE' => hash_hmac('sha512', $raw, $secret),
            ],
            $raw
        )->assertOk();

        $this->call(
            'POST',
            '/api/paystack/webhook',
            [],
            [],
            [],
            [
                'CONTENT_TYPE' => 'application/json',
                'HTTP_X_PAYSTACK_SIGNATURE' => hash_hmac('sha512', $raw, 'sk_test_dummy'),
            ],
            $raw
        )->assertUnauthorized();
    }

    /**
     * @param  array<string, mixed>  $overrides
     * @return array<string, mixed>
     */
    private function settingsPayload(array $overrides = []): array
    {
        return array_merge([
            'referral_commission_percent' => 40,
            'system_commission_percent' => 60,
            'monthly_subscription_bonus' => 1,
            'minimum_withdrawal' => 10,
            'trial_days' => 7,
            'currency' => 'GHS',
            'tax_rate' => 0,
            'referral_share_link_base' => 'https://momokotle.app/ref/',
            'support_contact' => '',
            'store_enabled' => '1',
            'subscription_enabled' => '1',
            'maintenance_mode' => '0',
        ], $overrides);
    }

    public function test_business_settings_reject_invalid_commission_split(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->actingAs($admin)
            ->from('/admin/settings/business')
            ->put('/admin/settings/business', [
                'referral_commission_percent' => 40,
                'system_commission_percent' => 50,
                'monthly_subscription_bonus' => 1,
                'minimum_withdrawal' => 10,
                'trial_days' => 7,
                'currency' => 'GHS',
                'tax_rate' => 0,
                'referral_share_link_base' => 'https://momokotle.app/ref/',
            ])
            ->assertRedirect('/admin/settings/business')
            ->assertSessionHasErrors('system_commission_percent');
    }
}
