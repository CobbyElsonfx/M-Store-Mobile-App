<?php

namespace Tests\Feature;

use App\Models\Referral;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ApiWalletReferralNotificationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_wallet_endpoints_require_authentication(): void
    {
        $this->getJson('/api/wallet')->assertUnauthorized();
        $this->getJson('/api/referrals/summary')->assertUnauthorized();
        $this->getJson('/api/notifications')->assertUnauthorized();
    }

    public function test_public_referral_validation(): void
    {
        $referrer = User::factory()->create(['referral_code' => 'TESTCODE']);

        $this->getJson('/api/referrals/validate/TESTCODE')
            ->assertOk()
            ->assertJsonPath('data.referrerUserId', (string) $referrer->id);

        $this->getJson('/api/referrals/validate/INVALID')
            ->assertNotFound();
    }

    public function test_agent_can_view_wallet_and_request_withdrawal(): void
    {
        $agent = User::factory()->create();
        Wallet::query()->create([
            'user_id' => $agent->id,
            'available_balance' => 100,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 100,
        ]);
        Sanctum::actingAs($agent);

        $this->getJson('/api/wallet')
            ->assertOk()
            ->assertJsonPath('data.availableBalance', 100);

        $this->postJson('/api/withdrawals', [
            'amount' => 20,
            'payment_method' => 'MTN_MOMO',
            'payment_number' => '0244123456',
        ])->assertCreated()
            ->assertJsonPath('data.amount', 20);

        $this->assertDatabaseHas('wallets', [
            'user_id' => $agent->id,
            'available_balance' => 80,
            'pending_balance' => 20,
        ]);
    }

    public function test_withdrawal_rejects_insufficient_balance(): void
    {
        $agent = User::factory()->create();
        Wallet::query()->create([
            'user_id' => $agent->id,
            'available_balance' => 5,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 5,
        ]);
        Sanctum::actingAs($agent);

        $this->postJson('/api/withdrawals', [
            'amount' => 20,
            'payment_method' => 'MTN_MOMO',
            'payment_number' => '0244123456',
        ])->assertUnprocessable();
    }

    public function test_agent_can_view_referral_summary(): void
    {
        $agent = User::factory()->create(['referral_code' => 'MYCODE12']);
        Sanctum::actingAs($agent);

        Referral::query()->create([
            'referrer_user_id' => $agent->id,
            'referrer_code' => 'MYCODE12',
            'referred_user_id' => User::factory()->create()->id,
            'referred_user_name' => 'Referred User',
            'registration_date' => now(),
            'is_active' => true,
        ]);

        $this->getJson('/api/referrals/summary')
            ->assertOk()
            ->assertJsonPath('data.referralCode', 'MYCODE12')
            ->assertJsonPath('data.stats.totalReferrals', 1);
    }
}
