<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ApiOrderTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_order_endpoints_require_authentication(): void
    {
        $this->getJson('/api/orders')->assertUnauthorized();
        $this->postJson('/api/orders', [])->assertUnauthorized();
    }

    public function test_agent_can_create_order_with_server_pricing(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $product = Product::query()->firstOrFail();
        $product->update(['stock_quantity' => 10, 'is_available' => true]);

        $response = $this->postJson('/api/orders', [
            'product_id' => $product->id,
            'quantity' => 2,
            'phone_number' => '0244123456',
            'location' => 'Accra',
        ]);

        $response->assertCreated()
            ->assertJsonPath('data.itemName', $product->product_name)
            ->assertJsonPath('data.status', 'Pending');

        $this->assertEqualsWithDelta(
            round((float) $product->price * 2, 2),
            (float) $response->json('data.totalAmount'),
            0.001
        );

        $this->assertDatabaseHas('orders', [
            'user_id' => $agent->id,
            'product_id' => $product->id,
            'quantity' => 2,
            'status' => 'Pending',
        ]);
    }

    public function test_create_order_rejects_insufficient_stock(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $product = Product::query()->firstOrFail();
        $product->update(['stock_quantity' => 1, 'is_available' => true]);

        $this->postJson('/api/orders', [
            'product_id' => $product->id,
            'quantity' => 5,
            'phone_number' => '0244123456',
            'location' => 'Accra',
        ])->assertUnprocessable();
    }

    public function test_agent_can_list_own_orders(): void
    {
        $agent = User::factory()->create();
        Sanctum::actingAs($agent);

        $product = Product::query()->firstOrFail();

        Order::query()->create([
            'user_id' => $agent->id,
            'product_id' => $product->id,
            'agent_name' => 'Test Agent',
            'item_name' => $product->product_name,
            'quantity' => 1,
            'total_amount' => $product->price,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Pending',
        ]);

        $this->getJson('/api/orders')
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJsonPath('data.0.userId', (string) $agent->id);
    }

    public function test_agent_cannot_view_another_users_order(): void
    {
        $owner = User::factory()->create();
        $other = User::factory()->create();
        $product = Product::query()->firstOrFail();

        $order = Order::query()->create([
            'user_id' => $owner->id,
            'product_id' => $product->id,
            'agent_name' => 'Owner',
            'item_name' => $product->product_name,
            'quantity' => 1,
            'total_amount' => $product->price,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Pending',
        ]);

        Sanctum::actingAs($other);

        $this->getJson("/api/orders/{$order->id}")
            ->assertNotFound();
    }
}
