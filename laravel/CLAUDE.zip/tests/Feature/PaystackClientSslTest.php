<?php

namespace Tests\Feature;

use App\Services\PaystackClient;
use Tests\TestCase;

class PaystackClientSslTest extends TestCase
{
    public function test_ssl_verification_can_be_disabled_for_local_paystack_calls(): void
    {
        config(['services.paystack.verify_ssl' => false]);

        $this->assertFalse(app(PaystackClient::class)->verifiesSsl());
    }

    public function test_ssl_verification_stays_on_when_explicitly_enabled(): void
    {
        config(['services.paystack.verify_ssl' => true]);

        $this->assertTrue(app(PaystackClient::class)->verifiesSsl());
    }

    public function test_testing_environment_verifies_ssl_by_default(): void
    {
        config(['services.paystack.verify_ssl' => null]);

        $this->assertTrue(app(PaystackClient::class)->verifiesSsl());
    }
}
