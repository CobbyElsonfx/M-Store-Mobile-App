<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\Notification;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WithdrawalRequest;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AdminWithdrawalTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_withdrawals_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $withdrawal = $this->createPendingWithdrawal();

        $this->actingAs($admin)
            ->get('/admin/withdrawals')
            ->assertOk()
            ->assertSee('Withdrawals')
            ->assertSee(number_format((float) $withdrawal->amount, 2));
    }

    public function test_admin_can_approve_mark_paid_and_update_wallet_balances(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $withdrawal = $this->createPendingWithdrawal();

        $this->actingAs($admin)
            ->patch("/admin/withdrawals/{$withdrawal->id}", ['action' => 'approve'])
            ->assertRedirect('/admin/withdrawals');

        $withdrawal->refresh();
        $this->assertSame('Approved', $withdrawal->status);

        $this->assertDatabaseHas('notifications', [
            'user_id' => $withdrawal->user_id,
            'type' => 'WithdrawalApproved',
            'reference_id' => $withdrawal->id,
        ]);

        $this->actingAs($admin)
            ->patch("/admin/withdrawals/{$withdrawal->id}", ['action' => 'mark_paid'])
            ->assertRedirect('/admin/withdrawals');

        $withdrawal->refresh();
        $this->assertSame('Paid', $withdrawal->status);

        $this->assertDatabaseHas('wallets', [
            'user_id' => $withdrawal->user_id,
            'available_balance' => 80,
            'pending_balance' => 0,
            'withdrawn_balance' => 20,
        ]);

        $this->assertDatabaseHas('notifications', [
            'user_id' => $withdrawal->user_id,
            'type' => 'WithdrawalPaid',
        ]);
    }

    public function test_admin_reject_restores_available_balance(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $withdrawal = $this->createPendingWithdrawal();

        $this->actingAs($admin)
            ->patch("/admin/withdrawals/{$withdrawal->id}", [
                'action' => 'reject',
                'admin_note' => 'Invalid payment number.',
            ])
            ->assertRedirect('/admin/withdrawals');

        $withdrawal->refresh();
        $this->assertSame('Rejected', $withdrawal->status);
        $this->assertSame('Invalid payment number.', $withdrawal->admin_note);

        $this->assertDatabaseHas('wallets', [
            'user_id' => $withdrawal->user_id,
            'available_balance' => 100,
            'pending_balance' => 0,
        ]);

        $notification = Notification::query()
            ->where('user_id', $withdrawal->user_id)
            ->where('type', 'WithdrawalRejected')
            ->first();

        $this->assertNotNull($notification);
        $this->assertStringContainsString('Invalid payment number.', $notification->message);
    }

    public function test_agent_cannot_access_admin_withdrawals(): void
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $this->actingAs($agent)
            ->get('/admin/withdrawals')
            ->assertForbidden();
    }

    public function test_cannot_approve_non_pending_withdrawal(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $withdrawal = $this->createPendingWithdrawal();

        $withdrawal->update(['status' => 'Paid']);

        $this->actingAs($admin)
            ->patch("/admin/withdrawals/{$withdrawal->id}", ['action' => 'approve'])
            ->assertRedirect('/admin/withdrawals')
            ->assertSessionHas('error');
    }

    private function createPendingWithdrawal(): WithdrawalRequest
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);
        Wallet::query()->create([
            'user_id' => $agent->id,
            'available_balance' => 100,
            'pending_balance' => 0,
            'withdrawn_balance' => 0,
            'lifetime_earnings' => 100,
        ]);

        Sanctum::actingAs($agent);

        $response = $this->postJson('/api/withdrawals', [
            'amount' => 20,
            'payment_method' => 'MTN_MOMO',
            'payment_number' => '0244123456',
        ])->assertCreated();

        return WithdrawalRequest::query()->findOrFail($response->json('data.withdrawalId'));
    }
}
