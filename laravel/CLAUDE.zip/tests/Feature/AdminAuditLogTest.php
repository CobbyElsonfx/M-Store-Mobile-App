<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\AuditLog;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Support\AuditActions;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminAuditLogTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_can_view_audit_log_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        AuditLog::query()->create([
            'admin_user_id' => $admin->id,
            'action' => AuditActions::LOGIN,
            'entity_type' => 'admin',
            'entity_id' => (string) $admin->id,
            'metadata' => ['admin_email' => $admin->email],
        ]);

        $this->actingAs($admin)
            ->get('/admin/audit-log')
            ->assertOk()
            ->assertSee('Audit Log')
            ->assertSee('Admin Login')
            ->assertSee($admin->email);
    }

    public function test_admin_login_records_audit_entry(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        $this->post('/admin/login', [
            'email' => $admin->email,
            'password' => 'password',
        ])->assertRedirect('/admin');

        $this->assertDatabaseHas('audit_logs', [
            'admin_user_id' => $admin->id,
            'action' => AuditActions::LOGIN,
            'entity_type' => 'admin',
            'entity_id' => (string) $admin->id,
        ]);
    }

    public function test_order_status_change_records_audit_entry(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $product = Product::query()->firstOrFail();
        $buyer = User::factory()->create(['role' => UserRole::Agent]);

        $order = Order::query()->create([
            'user_id' => $buyer->id,
            'product_id' => $product->id,
            'agent_name' => 'Buyer Agent',
            'item_name' => $product->product_name,
            'quantity' => 1,
            'total_amount' => $product->price,
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'status' => 'Pending',
        ]);

        $this->actingAs($admin)
            ->patch("/admin/orders/{$order->id}/status", ['status' => 'Processing'])
            ->assertRedirect('/admin/orders');

        $this->assertDatabaseHas('audit_logs', [
            'admin_user_id' => $admin->id,
            'action' => AuditActions::ORDER_STATUS_CHANGE,
            'entity_type' => 'order',
            'entity_id' => $order->id,
        ]);

        $log = AuditLog::query()
            ->where('action', AuditActions::ORDER_STATUS_CHANGE)
            ->where('entity_id', $order->id)
            ->firstOrFail();

        $this->assertSame('Pending', $log->metadata['old_value']);
        $this->assertSame('Processing', $log->metadata['new_value']);
    }

    public function test_audit_log_can_be_filtered_by_action(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();

        AuditLog::query()->create([
            'admin_user_id' => $admin->id,
            'action' => AuditActions::LOGIN,
            'entity_type' => 'admin',
            'entity_id' => (string) $admin->id,
            'metadata' => ['admin_email' => $admin->email],
        ]);

        AuditLog::query()->create([
            'admin_user_id' => $admin->id,
            'action' => AuditActions::ORDER_STATUS_CHANGE,
            'entity_type' => 'order',
            'entity_id' => 'order-123',
            'metadata' => [
                'admin_email' => $admin->email,
                'old_value' => 'Pending',
                'new_value' => 'Delivered',
            ],
        ]);

        $response = $this->actingAs($admin)
            ->get('/admin/audit-log?action='.AuditActions::ORDER_STATUS_CHANGE)
            ->assertOk();

        $content = $response->getContent();
        $this->assertStringContainsString('Order Status Change</td>', $content);
        $this->assertStringNotContainsString('Admin Login</td>', $content);
        $this->assertStringContainsString('order-123', $content);
    }
}
