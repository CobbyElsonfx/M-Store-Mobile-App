<?php

namespace Tests\Feature;

use App\Enums\SubscriptionStatus;
use App\Enums\UserRole;
use App\Mail\RegistrationOtpMail;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class ApiAuthTest extends TestCase
{
    use RefreshDatabase;

    /** Payload shape sent by the Android app (AuthRegisterRequest). */
    private function mobileRegisterPayload(array $overrides = []): array
    {
        return array_merge([
            'first_name' => 'Kofi',
            'last_name' => 'Mensah',
            'email' => 'kofi.mensah@example.com',
            'phone_number' => '0244123456',
            'location' => 'Accra',
            'password' => 'secret123',
            'password_confirmation' => 'secret123',
        ], $overrides);
    }

    /** @return array{token: string, user: array<string, mixed>} */
    private function registerAndVerify(array $payload): array
    {
        Mail::fake();

        $this->postJson('/api/auth/register', $payload)->assertOk()
            ->assertJsonPath('requires_verification', true)
            ->assertJsonPath('email', $payload['email']);

        $otpCode = null;
        Mail::assertSent(RegistrationOtpMail::class, function (RegistrationOtpMail $mail) use (&$otpCode) {
            $otpCode = $mail->otpCode;

            return true;
        });

        $verify = $this->postJson('/api/auth/register/verify', [
            'email' => $payload['email'],
            'otp_code' => $otpCode,
        ]);

        $verify->assertCreated();

        return [
            'token' => $verify->json('token'),
            'user' => $verify->json('user'),
        ];
    }

    public function test_health_endpoint_returns_ok(): void
    {
        $response = $this->getJson('/api/health');

        $response->assertOk()
            ->assertJsonPath('status', 'ok');
    }

    public function test_register_sends_email_otp_and_requires_verification(): void
    {
        $this->seed();
        Mail::fake();

        $response = $this->postJson('/api/auth/register', $this->mobileRegisterPayload());

        $response->assertOk()
            ->assertJsonPath('requires_verification', true)
            ->assertJsonPath('message', 'Verification code sent to your email.')
            ->assertJsonMissingPath('token');

        Mail::assertSent(RegistrationOtpMail::class, function (RegistrationOtpMail $mail) {
            return $mail->hasTo('kofi.mensah@example.com')
                && strlen($mail->otpCode) === 6;
        });

        $this->assertDatabaseMissing('users', [
            'email' => 'kofi.mensah@example.com',
        ]);
    }

    public function test_agent_can_verify_otp_and_receive_token(): void
    {
        $this->seed();

        $result = $this->registerAndVerify($this->mobileRegisterPayload([
            'email' => 'agent@example.com',
        ]));

        $this->assertNotEmpty($result['token']);
        $this->assertSame('agent@example.com', $result['user']['email']);

        $this->assertDatabaseHas('users', [
            'email' => 'agent@example.com',
            'role' => UserRole::Agent->value,
        ]);
    }

    public function test_mobile_register_response_matches_app_contract_after_verification(): void
    {
        $this->seed();

        Mail::fake();

        $payload = $this->mobileRegisterPayload();
        $this->postJson('/api/auth/register', $payload)->assertOk();

        $otpCode = null;
        Mail::assertSent(RegistrationOtpMail::class, function (RegistrationOtpMail $mail) use (&$otpCode) {
            $otpCode = $mail->otpCode;

            return true;
        });

        $response = $this->postJson('/api/auth/register/verify', [
            'email' => $payload['email'],
            'otp_code' => $otpCode,
        ]);

        $response->assertCreated()
            ->assertJsonPath('token_type', 'Bearer')
            ->assertJsonStructure([
                'message',
                'token',
                'token_type',
                'user' => [
                    'id',
                    'email',
                    'first_name',
                    'last_name',
                    'full_name',
                    'phone_number',
                    'location',
                    'account_status',
                    'referral_code',
                    'subscription_status',
                    'trial_end_date',
                    'access_level',
                    'wallet' => [
                        'available_balance',
                        'pending_balance',
                        'withdrawn_balance',
                        'lifetime_earnings',
                    ],
                ],
            ])
            ->assertJsonPath('user.email', 'kofi.mensah@example.com')
            ->assertJsonPath('user.phone_number', '0244123456')
            ->assertJsonPath('user.subscription_status', SubscriptionStatus::Trial->value)
            ->assertJsonPath('user.wallet.available_balance', 0);

        $this->assertDatabaseHas('wallets', [
            'user_id' => $response->json('user.id'),
            'available_balance' => 0,
        ]);
    }

    public function test_registered_agent_token_can_access_me_endpoint(): void
    {
        $this->seed();

        $result = $this->registerAndVerify($this->mobileRegisterPayload([
            'email' => 'me.test@example.com',
        ]));

        $this->getJson('/api/auth/me', [
            'Authorization' => 'Bearer '.$result['token'],
        ])
            ->assertOk()
            ->assertJsonPath('user.email', 'me.test@example.com')
            ->assertJsonStructure(['user' => ['id', 'access_level', 'wallet']]);
    }

    public function test_registered_agent_can_login_with_same_credentials(): void
    {
        $this->seed();

        $this->registerAndVerify($this->mobileRegisterPayload([
            'email' => 'login.test@example.com',
        ]));

        $this->postJson('/api/auth/login', [
            'email' => 'login.test@example.com',
            'password' => 'secret123',
        ])
            ->assertOk()
            ->assertJsonStructure(['token', 'token_type', 'user' => ['id', 'email']])
            ->assertJsonPath('token_type', 'Bearer');
    }

    public function test_register_rejects_duplicate_email(): void
    {
        $this->seed();

        $payload = $this->mobileRegisterPayload(['email' => 'duplicate@example.com']);

        $this->registerAndVerify($payload);

        $this->postJson('/api/auth/register', $payload)
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['email']);
    }

    public function test_register_rejects_password_mismatch(): void
    {
        $this->seed();

        $this->postJson('/api/auth/register', $this->mobileRegisterPayload([
            'email' => 'mismatch@example.com',
            'password_confirmation' => 'different123',
        ]))
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['password']);
    }

    public function test_verify_rejects_invalid_otp_code(): void
    {
        $this->seed();
        Mail::fake();

        $payload = $this->mobileRegisterPayload(['email' => 'badotp@example.com']);
        $this->postJson('/api/auth/register', $payload)->assertOk();

        $this->postJson('/api/auth/register/verify', [
            'email' => 'badotp@example.com',
            'otp_code' => '000000',
        ])
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['otp_code']);
    }

    public function test_register_rejects_invalid_referral_code_on_verify(): void
    {
        $this->seed();
        Mail::fake();

        $payload = $this->mobileRegisterPayload([
            'email' => 'badref@example.com',
            'referral_code' => 'NOTFOUND1',
        ]);

        $this->postJson('/api/auth/register', $payload)->assertOk();

        $otpCode = null;
        Mail::assertSent(RegistrationOtpMail::class, function (RegistrationOtpMail $mail) use (&$otpCode) {
            $otpCode = $mail->otpCode;

            return true;
        });

        $this->postJson('/api/auth/register/verify', [
            'email' => 'badref@example.com',
            'otp_code' => $otpCode,
        ])
            ->assertStatus(422)
            ->assertJsonPath('message', 'Referral code not found.');
    }

    public function test_register_with_valid_referral_code_links_referrer(): void
    {
        $this->seed();

        $referrer = User::factory()->create([
            'role' => UserRole::Agent,
            'referral_code' => 'REFAGENT1',
        ]);

        $result = $this->registerAndVerify($this->mobileRegisterPayload([
            'email' => 'referred@example.com',
            'referral_code' => 'refagent1',
        ]));

        $newUserId = $result['user']['id'];

        $this->assertDatabaseHas('users', [
            'id' => $newUserId,
            'referred_by_user_id' => $referrer->id,
            'referred_by_code' => 'REFAGENT1',
        ]);

        $this->assertDatabaseHas('referrals', [
            'referrer_user_id' => $referrer->id,
            'referred_user_id' => $newUserId,
        ]);
    }

    public function test_can_resend_registration_otp(): void
    {
        $this->seed();
        Mail::fake();

        $payload = $this->mobileRegisterPayload(['email' => 'resend@example.com']);
        $this->postJson('/api/auth/register', $payload)->assertOk();

        $this->travel(61)->seconds();

        $this->postJson('/api/auth/register/resend-otp', [
            'email' => 'resend@example.com',
        ])
            ->assertOk()
            ->assertJsonPath('message', 'Verification code sent to your email.');

        Mail::assertSent(RegistrationOtpMail::class, 2);
    }

    public function test_referral_validate_endpoint_matches_mobile_precheck(): void
    {
        $referrer = User::factory()->create([
            'role' => UserRole::Agent,
            'referral_code' => 'MOBILE01',
        ]);

        $this->getJson('/api/referrals/validate/MOBILE01')
            ->assertOk()
            ->assertJsonPath('data.referrerUserId', (string) $referrer->id)
            ->assertJsonPath('data.referralCode', 'MOBILE01');

        $this->getJson('/api/referrals/validate/UNKNOWN99')
            ->assertNotFound()
            ->assertJsonPath('message', 'Referral code not found.');
    }

    public function test_admin_cannot_use_mobile_login_endpoint(): void
    {
        $this->seed();

        $response = $this->postJson('/api/auth/login', [
            'email' => 'admin@momokotle.test',
            'password' => 'password',
        ]);

        $response->assertForbidden();
    }

    public function test_admin_web_route_requires_admin_role(): void
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $response = $this->actingAs($agent)->get('/admin');

        $response->assertForbidden();
    }
}
