<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Models\AgentApplication;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class AdminApplicationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Storage::fake('agent_documents');
    }

    public function test_admin_can_view_submissions_page(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $this->createSubmittedApplication();

        $this->actingAs($admin)
            ->get('/admin/submissions')
            ->assertOk()
            ->assertSee('Submissions')
            ->assertSee('Jane Agent');
    }

    public function test_admin_can_view_submission_detail_and_update_status(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $application = $this->createSubmittedApplication();

        $this->actingAs($admin)
            ->get("/admin/submissions/{$application->id}")
            ->assertOk()
            ->assertSee($application->id)
            ->assertSee('Ghana Card Front');

        $this->actingAs($admin)
            ->patch("/admin/submissions/{$application->id}/status", [
                'status' => 'Approved',
                'admin_note' => 'Looks good.',
            ])
            ->assertRedirect("/admin/submissions/{$application->id}");

        $application->refresh();
        $this->assertSame('Approved', $application->status);
        $this->assertSame('Looks good.', $application->admin_note);

        $this->assertDatabaseHas('notifications', [
            'user_id' => $application->user_id,
            'type' => 'ApplicationApproved',
            'reference_id' => $application->id,
        ]);
    }

    public function test_admin_can_view_submission_document(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $application = $this->createSubmittedApplication();

        $documentType = $application->documents()->value('document_type');

        $this->actingAs($admin)
            ->get("/admin/submissions/{$application->id}/documents/{$documentType}")
            ->assertOk();
    }

    public function test_agent_cannot_access_admin_submissions(): void
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $this->actingAs($agent)
            ->get('/admin/submissions')
            ->assertForbidden();
    }

    public function test_rejected_status_sends_notification_with_admin_note(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $application = $this->createSubmittedApplication();

        $this->actingAs($admin)
            ->patch("/admin/submissions/{$application->id}/status", [
                'status' => 'Rejected',
                'admin_note' => 'Missing signature.',
            ])
            ->assertRedirect("/admin/submissions/{$application->id}");

        $notification = Notification::query()
            ->where('user_id', $application->user_id)
            ->where('type', 'ApplicationRejected')
            ->first();

        $this->assertNotNull($notification);
        $this->assertStringContainsString('Missing signature.', $notification->message);
    }

    public function test_admin_can_view_passport_application(): void
    {
        $admin = User::query()->where('email', 'admin@momokotle.test')->firstOrFail();
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $id = $this->actingAs($agent)
            ->getJson('/api/applications/next-id')
            ->json('data.id');

        $this->actingAs($agent)->postJson("/api/applications/{$id}/documents", [
            'slot_id' => 'signature',
            'file' => UploadedFile::fake()->image('signature.jpg'),
        ])->assertOk();

        $this->actingAs($agent)->postJson("/api/applications/{$id}/submit", [
            'form_type' => 'Passport Application',
            'form_data' => [
                'surname' => 'Mensah',
                'firstName' => 'Kwame',
                'phoneNumber' => '0244123456',
                'oldPassportNumber' => 'G1234567',
                'qualifiedWitness' => 'Senior Civil Servant',
            ],
        ])->assertOk();

        $this->actingAs($admin)
            ->get('/admin/submissions')
            ->assertOk()
            ->assertSee('Passport Application')
            ->assertSee('Kwame Mensah');

        $this->actingAs($admin)
            ->get("/admin/submissions/{$id}")
            ->assertOk()
            ->assertSee('Passport Application')
            ->assertSee('Old Passport Number')
            ->assertSee('G1234567')
            ->assertSee('Qualified Witness')
            ->assertSee('Senior Civil Servant')
            ->assertSee('Signature');
    }

    private function createSubmittedApplication(): AgentApplication
    {
        $agent = User::factory()->create(['role' => UserRole::Agent]);

        $id = $this->actingAs($agent)
            ->getJson('/api/applications/next-id')
            ->json('data.id');

        $this->actingAs($agent)->postJson("/api/applications/{$id}/documents", [
            'slot_id' => 'ghanaCardFront',
            'file' => UploadedFile::fake()->image('front.jpg'),
        ])->assertOk();

        $this->actingAs($agent)->postJson("/api/applications/{$id}/submit", [
            'form_type' => 'Agent Card Request',
            'form_data' => [
                'fullName' => 'Jane Agent',
                'phoneNumber' => '0244123456',
                'businessName' => 'Jane Trading',
            ],
        ])->assertOk();

        return AgentApplication::query()->with('documents')->findOrFail($id);
    }
}
