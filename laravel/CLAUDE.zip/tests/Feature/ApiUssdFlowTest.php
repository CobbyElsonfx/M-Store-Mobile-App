<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ApiUssdFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_authenticated_agent_can_fetch_active_ussd_flows(): void
    {
        $this->seed();

        $agent = User::factory()->create(['role' => \App\Enums\UserRole::Agent]);
        $token = $agent->createToken('mobile')->plainTextToken;

        $response = $this->getJson('/api/ussd-flows', [
            'Authorization' => 'Bearer '.$token,
        ]);

        $response->assertOk()
            ->assertJsonStructure([
                'data' => [
                    [
                        'flowKey',
                        'name',
                        'ussdCode',
                        'steps',
                        'isActive',
                    ],
                ],
            ])
            ->assertJsonPath('data.0.flowKey', 'MTN_CASHIN')
            ->assertJsonPath('data.0.ussdCode', '*170#');

        $expected = collect(\App\Support\UssdFlowDefaults::all())->keyBy('flow_key');
        $returned = collect($response->json('data'))->keyBy('flowKey');

        $this->assertSame($expected->keys()->all(), $returned->keys()->all());

        foreach ($expected as $key => $flow) {
            $this->assertSame(
                collect($flow['steps'])->pluck('type')->all(),
                collect($returned[$key]['steps'])->pluck('type')->all(),
                "API steps for {$key} must match the admin-stored defaults"
            );
            $this->assertSame($flow['ussd_code'], $returned[$key]['ussdCode']);
        }
    }

    public function test_ussd_flows_require_authentication(): void
    {
        $this->getJson('/api/ussd-flows')->assertUnauthorized();
    }
}
