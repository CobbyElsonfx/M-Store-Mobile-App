

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="page-header">
        <div>
            <p class="card-lead" style="margin:0">Manage subscription pricing and availability for agents.</p>
        </div>
        <a class="btn btn-primary" href="<?php echo e(route('admin.subscription-plans.create')); ?>">Add plan</a>
    </div>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Order</th>
                <th>Plan</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($plan->sort_order); ?></td>
                    <td><strong><?php echo e($plan->plan_name); ?></strong></td>
                    <td>GHS <?php echo e(number_format((float) $plan->price, 2)); ?></td>
                    <td><?php echo e($plan->duration_days); ?> days</td>
                    <td><span class="badge <?php echo e(strtolower($plan->status)); ?>"><?php echo e($plan->status); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('admin.subscription-plans.edit', $plan)); ?>">Edit</a>
                        <form class="inline" method="POST" action="<?php echo e(route('admin.subscription-plans.destroy', $plan)); ?>" onsubmit="return confirm('Delete this plan?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="link danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No subscription plans yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/subscription-plans/index.blade.php ENDPATH**/ ?>