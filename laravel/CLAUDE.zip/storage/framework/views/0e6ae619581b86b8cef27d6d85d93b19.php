

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Configure USSD dial codes and menu steps used by the mobile app for Cash In, Cash Out, and other agent actions.</p>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Flow</th>
                    <th>Key</th>
                    <th>USSD Code</th>
                    <th>Steps</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $flows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($flow->name); ?></strong></td>
                        <td><code><?php echo e($flow->flow_key); ?></code></td>
                        <td><code><?php echo e($flow->ussd_code); ?></code></td>
                        <td><?php echo e(count($flow->steps ?? [])); ?></td>
                        <td><?php echo e($flow->is_active ? 'Active' : 'Disabled'); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.ussd-flows.edit', $flow)); ?>">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No USSD flows configured. Run <code>php artisan db:seed --class=UssdFlowTemplateSeeder</code>.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/ussd-flows/index.blade.php ENDPATH**/ ?>