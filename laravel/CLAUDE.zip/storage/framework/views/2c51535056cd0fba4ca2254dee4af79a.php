

<?php
    function admin_user_name($user): string {
        if (!$user) return '—';
        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
        return $name !== '' ? $name : ($user->name ?? $user->email ?? '—');
    }
?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Agent wallet balances and transaction history.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.wallets.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Agent name, email, phone">
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Available</th>
                <th>Pending</th>
                <th>Withdrawn</th>
                <th>Lifetime</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e(admin_user_name($wallet->user)); ?>

                        <?php if($wallet->user?->email): ?><br><small><?php echo e($wallet->user->email); ?></small><?php endif; ?>
                    </td>
                    <td>GHS <?php echo e(number_format((float) $wallet->available_balance, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $wallet->pending_balance, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $wallet->withdrawn_balance, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $wallet->lifetime_earnings, 2)); ?></td>
                    <td><a href="<?php echo e(route('admin.wallets.show', $wallet)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">No wallets found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $wallets], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/wallets/index.blade.php ENDPATH**/ ?>