Hello <?php echo e($firstName); ?>,

Your MoMo Kotle account verification code is:

<?php echo e($otpCode); ?>


This code expires in <?php echo e($expiresMinutes); ?> minutes. If you did not request this, you can ignore this email.

Thanks,
MoMo Kotle
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/mail/registration-otp.blade.php ENDPATH**/ ?>