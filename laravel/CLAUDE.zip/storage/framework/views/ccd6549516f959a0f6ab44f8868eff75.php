<?php echo e($title); ?>


<?php echo e($greeting); ?>


<?php echo e($intro); ?>


<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($label); ?>: <?php echo e($value); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($nextSteps): ?>
<?php echo e($nextSteps); ?>

<?php endif; ?>

<?php if($note): ?>
<?php echo e($note); ?>

<?php endif; ?>

Open the MoMo Kotle app for full details.
<?php if($supportContact): ?>
Support: <?php echo e($supportContact); ?>

<?php endif; ?>
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/mail/transactional-text.blade.php ENDPATH**/ ?>