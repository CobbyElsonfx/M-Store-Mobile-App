<input type="hidden" name="return_status" value="<?php echo e(request('status')); ?>">
<input type="hidden" name="return_search" value="<?php echo e($search ?? request('search')); ?>">
<input type="hidden" name="return_page" value="<?php echo e(request('page')); ?>">
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/withdrawals/_return_fields.blade.php ENDPATH**/ ?>