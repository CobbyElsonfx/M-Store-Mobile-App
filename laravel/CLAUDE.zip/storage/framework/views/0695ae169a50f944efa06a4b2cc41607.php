

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Agent subscription purchases and status.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.subscriptions.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Plan, email, reference">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Plan</th>
                <th>Price</th>
                <th>Start</th>
                <th>End</th>
                <th>Status</th>
                <th>Reference</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($subscription->user): ?>
                            <a href="<?php echo e(route('admin.users.show', $subscription->user)); ?>"><?php echo e($subscription->user->email); ?></a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($subscription->plan_name ?? $subscription->plan?->plan_name ?? '—'); ?></td>
                    <td>GHS <?php echo e(number_format((float) $subscription->price, 2)); ?></td>
                    <td><?php echo e($subscription->start_date?->format('Y-m-d')); ?></td>
                    <td><?php echo e($subscription->end_date?->format('Y-m-d')); ?></td>
                    <td><?php echo e($subscription->status); ?></td>
                    <td><?php echo e($subscription->payment_reference ?: '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7">No subscriptions found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $subscriptions], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/subscriptions/index.blade.php ENDPATH**/ ?>