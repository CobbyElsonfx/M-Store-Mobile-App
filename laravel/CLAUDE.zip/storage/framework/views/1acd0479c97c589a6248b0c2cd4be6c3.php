

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="page-header">
        <div>
            <p class="card-lead" style="margin:0">Manage store catalog, pricing, stock, and commission splits.</p>
        </div>
        <a class="btn btn-primary" href="<?php echo e(route('admin.products.create')); ?>">Add product</a>
    </div>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Price</th>
                <th>Profit</th>
                <th>Stock</th>
                <th>Available</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($imageUrl = \App\Http\Controllers\Admin\ProductController::imageUrl($product)): ?>
                            <img src="<?php echo e($imageUrl); ?>" alt="" class="product-thumb">
                        <?php endif; ?>
                        <strong><?php echo e($product->product_name); ?></strong>
                    </td>
                    <td><?php echo e($product->category); ?></td>
                    <td>GHS <?php echo e(number_format((float) $product->price, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $product->profit, 2)); ?></td>
                    <td><?php echo e($product->stock_quantity); ?></td>
                    <td><?php echo e($product->is_available ? 'Yes' : 'No'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.products.edit', $product)); ?>">Edit</a>
                        <form class="inline" method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>" onsubmit="return confirm('Delete this product?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="link danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No products yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/products/index.blade.php ENDPATH**/ ?>