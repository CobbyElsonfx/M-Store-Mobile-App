

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Track admin actions across the platform.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.audit-log.index')); ?>">
        <div>
            <label for="action">Action</label>
            <select id="action" name="action">
                <option value="all" <?php if($actionFilter === 'all'): echo 'selected'; endif; ?>>All actions</option>
                <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($actionFilter === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Time</th>
                <th>Admin</th>
                <th>Action</th>
                <th>Entity</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $metadata = $log->metadata ?? [];
                    $oldValue = $metadata['old_value'] ?? null;
                    $newValue = $metadata['new_value'] ?? null;
                    $format = function ($value) {
                        if ($value === null) return '—';
                        return is_scalar($value) ? (string) $value : json_encode($value);
                    };
                ?>
                <tr>
                    <td><?php echo e($log->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($log->admin?->email ?? ($metadata['admin_email'] ?? '—')); ?></td>
                    <td><?php echo e($actions[$log->action] ?? $log->action); ?></td>
                    <td>
                        <?php if($log->entity_type): ?>
                            <?php echo e($log->entity_type); ?>

                            <?php if($log->entity_id): ?><br><code><?php echo e($log->entity_id); ?></code><?php endif; ?>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($oldValue !== null || $newValue !== null): ?>
                            <small>Old: <?php echo e($format($oldValue)); ?><br>New: <?php echo e($format($newValue)); ?></small>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">No audit entries yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $logs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/audit-log/index.blade.php ENDPATH**/ ?>