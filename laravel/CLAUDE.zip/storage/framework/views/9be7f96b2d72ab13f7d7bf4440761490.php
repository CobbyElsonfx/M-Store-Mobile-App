

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Delivery log for transactional emails. Failed emails never undo a successful payment, subscription, or application.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.email-notifications.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Email, subject, reference">
        </div>
        <div>
            <label for="type">Type</label>
            <select id="type" name="type">
                <option value="all" <?php if($typeFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type); ?>" <?php if($typeFilter === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Sent</th>
                <th>Recipient</th>
                <th>Type</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Reference</th>
                <th>Failure</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($log->sent_at?->format('Y-m-d H:i') ?: $log->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($log->recipient_email); ?></td>
                    <td><?php echo e($log->notification_type); ?></td>
                    <td><?php echo e($log->subject); ?></td>
                    <td><span class="badge <?php echo e($log->status === 'sent' ? 'approved' : ($log->status === 'failed' ? 'rejected' : 'pending')); ?>"><?php echo e($log->status); ?></span></td>
                    <td><?php echo e($log->reference_id ?: '—'); ?></td>
                    <td><?php echo e($log->failure_reason ?: '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7">No email notifications logged.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $logs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/email-notifications/index.blade.php ENDPATH**/ ?>