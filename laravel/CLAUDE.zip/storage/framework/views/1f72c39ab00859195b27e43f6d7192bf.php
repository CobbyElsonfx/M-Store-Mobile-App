<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">View registered agents and manage account access.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.users.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Name, email, phone, referral code">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Referrals</th>
                <th>Wallet</th>
                <th>Subscription</th>
                <th>Status</th>
                <th>Joined</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                    if ($name === '') {
                        $name = $user->name;
                    }
                ?>
                <tr>
                    <td><?php echo e($name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone_number ?: '—'); ?></td>
                    <td><?php echo e($user->referrals_made_count); ?></td>
                    <td>GHS <?php echo e(number_format((float) ($user->wallet->available_balance ?? 0), 2)); ?></td>
                    <td><span class="badge <?php echo e(strtolower($user->subscription_status?->value ?? 'none')); ?>"><?php echo e($user->subscription_status?->value ?? 'None'); ?></span></td>
                    <td><span class="badge <?php echo e(strtolower($user->account_status->value)); ?>"><?php echo e($user->account_status->value); ?></span></td>
                    <td><?php echo e($user->created_at?->format('Y-m-d')); ?></td>
                    <td><a href="<?php echo e(route('admin.users.show', $user)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <div class="pagination">
        <?php if($users->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($users->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $users->getUrlRange(max(1, $users->currentPage() - 2), min($users->lastPage(), $users->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $users->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($users->hasMorePages()): ?>
            <a href="<?php echo e($users->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>