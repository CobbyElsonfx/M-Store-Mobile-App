<?php
    $user = auth()->user();
    $initials = strtoupper(substr($user->first_name ?? $user->name ?? 'A', 0, 1).substr($user->last_name ?? '', 0, 1));
?>

<aside class="admin-sidebar">
    <div class="sidebar-brand">
        <strong>MoMo Kotle</strong>
        <span>Admin Console</span>
    </div>

    <nav class="sidebar-nav" aria-label="Admin navigation">
        <div class="nav-section">
            <div class="nav-section-label">Overview</div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.dashboard')]); ?>">
                <span class="nav-icon">◫</span> Dashboard
            </a>
            <a href="<?php echo e(route('admin.reports.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.reports.*')]); ?>">
                <span class="nav-icon">▤</span> Reports
            </a>
        </div>

        <div class="nav-section">
            <div class="nav-section-label">Operations</div>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.orders.*')]); ?>">
                <span class="nav-icon">◈</span> Orders
            </a>
            <a href="<?php echo e(route('admin.submissions.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.submissions.*')]); ?>">
                <span class="nav-icon">▣</span> Submissions
            </a>
            <a href="<?php echo e(route('admin.withdrawals.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.withdrawals.*')]); ?>">
                <span class="nav-icon">◉</span> Withdrawals
            </a>
            <a href="<?php echo e(route('admin.notifications.create')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.notifications.*')]); ?>">
                <span class="nav-icon">◔</span> Notifications
            </a>
        </div>

        <div class="nav-section">
            <div class="nav-section-label">Catalog</div>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.products.*')]); ?>">
                <span class="nav-icon">▦</span> Products
            </a>
            <a href="<?php echo e(route('admin.subscription-plans.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.subscription-plans.*')]); ?>">
                <span class="nav-icon">▧</span> Subscription Plans
            </a>
        </div>

        <div class="nav-section">
            <div class="nav-section-label">Users & Finance</div>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.users.*')]); ?>">
                <span class="nav-icon">◍</span> Users
            </a>
            <a href="<?php echo e(route('admin.wallets.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.wallets.*')]); ?>">
                <span class="nav-icon">◎</span> Wallets
            </a>
            <a href="<?php echo e(route('admin.referrals.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.referrals.*')]); ?>">
                <span class="nav-icon">◑</span> Referrals
            </a>
            <a href="<?php echo e(route('admin.subscriptions.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.subscriptions.*')]); ?>">
                <span class="nav-icon">◐</span> Subscriptions
            </a>
            <a href="<?php echo e(route('admin.payments.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.payments.*')]); ?>">
                <span class="nav-icon">◑</span> Payments
            </a>
            <a href="<?php echo e(route('admin.revenue.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.revenue.*')]); ?>">
                <span class="nav-icon">◒</span> Revenue
            </a>
            <a href="<?php echo e(route('admin.commissions.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.commissions.*')]); ?>">
                <span class="nav-icon">◓</span> Commissions
            </a>
        </div>

        <div class="nav-section">
            <div class="nav-section-label">System</div>
            <a href="<?php echo e(route('admin.settings.business.edit')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.settings.business.*')]); ?>">
                <span class="nav-icon">⚙</span> Business Settings
            </a>
            <a href="<?php echo e(route('admin.ussd-flows.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.ussd-flows.*')]); ?>">
                <span class="nav-icon">☎</span> USSD Flows
            </a>
            <a href="<?php echo e(route('admin.audit-log.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.audit-log.*')]); ?>">
                <span class="nav-icon">◷</span> Audit Log
            </a>
            <a href="<?php echo e(route('admin.email-notifications.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('admin.email-notifications.*')]); ?>">
                <span class="nav-icon">✉</span> Email Log
            </a>
        </div>
    </nav>

    <div class="sidebar-footer">
        <div class="sidebar-user">
            <div class="sidebar-avatar"><?php echo e($initials); ?></div>
            <div class="sidebar-user-info">
                <strong><?php echo e($user->name); ?></strong>
                <small><?php echo e($user->email); ?></small>
            </div>
        </div>
        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="sidebar-logout" type="submit">Sign out</button>
        </form>
    </div>
</aside>
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>