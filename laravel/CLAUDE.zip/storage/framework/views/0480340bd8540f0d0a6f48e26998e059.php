

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <div class="stat-box accent">
        <strong>Total agents</strong>
        <p><?php echo e(number_format($stats['total_users'])); ?></p>
    </div>
    <div class="stat-box">
        <strong>Pending orders</strong>
        <p><?php echo e(number_format($stats['pending_orders'])); ?></p>
    </div>
    <div class="stat-box">
        <strong>Pending submissions</strong>
        <p><?php echo e(number_format($stats['pending_submissions'])); ?></p>
    </div>
    <div class="stat-box">
        <strong>Pending withdrawals</strong>
        <p><?php echo e(number_format($stats['pending_withdrawals'])); ?></p>
    </div>
    <div class="stat-box accent">
        <strong>Wallet balance</strong>
        <p>GHS <?php echo e(number_format($stats['total_wallet_balance'], 2)); ?></p>
    </div>
    <div class="stat-box accent">
        <strong>Revenue this month</strong>
        <p>GHS <?php echo e(number_format($stats['monthly_revenue'], 2)); ?></p>
    </div>
    <div class="stat-box">
        <strong>Active subscribers</strong>
        <p><?php echo e(number_format($stats['active_subscribers'])); ?></p>
    </div>
    <div class="stat-box">
        <strong>Total referrals</strong>
        <p><?php echo e(number_format($stats['total_referrals'])); ?></p>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <h2>Quick access</h2>
            <p>Jump to frequently used admin modules.</p>
        </div>
    </div>
    <ul class="quick-links">
        <li><a href="<?php echo e(route('admin.reports.index')); ?>">Reports</a></li>
        <li><a href="<?php echo e(route('admin.orders.index')); ?>">Orders</a></li>
        <li><a href="<?php echo e(route('admin.submissions.index')); ?>">Submissions</a></li>
        <li><a href="<?php echo e(route('admin.withdrawals.index')); ?>">Withdrawals</a></li>
        <li><a href="<?php echo e(route('admin.wallets.index')); ?>">Wallets</a></li>
        <li><a href="<?php echo e(route('admin.referrals.index')); ?>">Referrals</a></li>
        <li><a href="<?php echo e(route('admin.subscriptions.index')); ?>">Subscriptions</a></li>
        <li><a href="<?php echo e(route('admin.products.index')); ?>">Products</a></li>
        <li><a href="<?php echo e(route('admin.users.index')); ?>">Users</a></li>
        <li><a href="<?php echo e(route('admin.settings.business.edit')); ?>">Business Settings</a></li>
        <li><a href="<?php echo e(route('admin.audit-log.index')); ?>">Audit Log</a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>