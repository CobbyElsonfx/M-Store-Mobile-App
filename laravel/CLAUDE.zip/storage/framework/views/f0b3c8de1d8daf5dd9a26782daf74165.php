

<?php $__env->startSection('content'); ?>
<div class="card">
    <p><a href="<?php echo e(route('admin.subscription-plans.index')); ?>">&larr; Back to plans</a></p>
    <h1><?php echo e($plan ? 'Edit plan' : 'Add plan'); ?></h1>

    <form method="POST" action="<?php echo e($plan ? route('admin.subscription-plans.update', $plan) : route('admin.subscription-plans.store')); ?>" class="status-form">
        <?php echo csrf_field(); ?>
        <?php if($plan): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div>
            <label for="plan_name">Plan name</label>
            <input id="plan_name" name="plan_name" type="text" value="<?php echo e(old('plan_name', $plan->plan_name ?? '')); ?>" required>
            <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="detail-grid">
            <div>
                <label for="price">Price (GHS)</label>
                <input id="price" name="price" type="number" step="0.01" min="0" value="<?php echo e(old('price', $plan->price ?? 0)); ?>" required>
            </div>
            <div>
                <label for="duration_days">Duration (days)</label>
                <input id="duration_days" name="duration_days" type="number" min="1" value="<?php echo e(old('duration_days', $plan->duration_days ?? 30)); ?>" required>
            </div>
            <div>
                <label for="sort_order">Sort order</label>
                <input id="sort_order" name="sort_order" type="number" min="0" value="<?php echo e(old('sort_order', $plan->sort_order ?? 0)); ?>" required>
            </div>
            <div>
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php if(old('status', $plan->status ?? 'Active') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <button type="submit"><?php echo e($plan ? 'Save changes' : 'Create plan'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/subscription-plans/form.blade.php ENDPATH**/ ?>