

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Referral commission history from delivered orders.</p>

    <div class="detail-grid">
        <div class="stat-box">
            <strong>Product profit</strong>
            <p>GHS <?php echo e(number_format($totals['profit'], 2)); ?></p>
        </div>
        <div class="stat-box">
            <strong>Referral share</strong>
            <p>GHS <?php echo e(number_format($totals['referral'], 2)); ?></p>
        </div>
        <div class="stat-box">
            <strong>System share</strong>
            <p>GHS <?php echo e(number_format($totals['system'], 2)); ?></p>
        </div>
    </div>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.commissions.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Order ID, product, referrer">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Order</th>
                <th>Referrer</th>
                <th>Profit</th>
                <th>Referral</th>
                <th>System</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $referrer = $commission->referrer;
                    $referrerName = '—';
                    if ($referrer) {
                        $referrerName = trim(($referrer->first_name ?? '').' '.($referrer->last_name ?? ''));
                        if ($referrerName === '') {
                            $referrerName = $referrer->name ?? $referrer->email;
                        }
                    }
                ?>
                <tr>
                    <td><?php echo e($commission->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($commission->order?->item_name ?? $commission->order_id ?? '—'); ?></td>
                    <td><?php echo e($referrerName); ?></td>
                    <td>GHS <?php echo e(number_format((float) $commission->product_profit, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $commission->referral_share, 2)); ?></td>
                    <td>GHS <?php echo e(number_format((float) $commission->system_share, 2)); ?></td>
                    <td><?php echo e($commission->status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No commission transactions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <div class="pagination">
        <?php if($commissions->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($commissions->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $commissions->getUrlRange(max(1, $commissions->currentPage() - 2), min($commissions->lastPage(), $commissions->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $commissions->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($commissions->hasMorePages()): ?>
            <a href="<?php echo e($commissions->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/commissions/index.blade.php ENDPATH**/ ?>