

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Review agent form submissions, view documents, and update approval status.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.submissions.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Submission ID, name, phone">
        </div>
        <div>
            <label for="form_type">Form type</label>
            <select id="form_type" name="form_type">
                <option value="all" <?php if($formTypeFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $formTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type); ?>" <?php if($formTypeFilter === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>>
                        <?php echo e(\App\Support\SubmissionLabels::statusLabel($status)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Applicant</th>
                <th>Phone</th>
                <th>Form type</th>
                <th>Status</th>
                <th>Submitted</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><code><?php echo e($application->id); ?></code></td>
                    <td>
                        <?php echo e($application->applicant_name); ?>

                        <?php if($application->user): ?>
                            <br><small><?php echo e($application->user->email); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($application->phone_number); ?></td>
                    <td><?php echo e($application->form_type); ?></td>
                    <td><span class="badge <?php echo e(strtolower($application->status)); ?>"><?php echo e(\App\Support\SubmissionLabels::statusLabel($application->status)); ?></span></td>
                    <td><?php echo e($application->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><a href="<?php echo e(route('admin.submissions.show', $application)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No submissions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <div class="pagination">
        <?php if($applications->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($applications->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $applications->getUrlRange(max(1, $applications->currentPage() - 2), min($applications->lastPage(), $applications->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $applications->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($applications->hasMorePages()): ?>
            <a href="<?php echo e($applications->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/submissions/index.blade.php ENDPATH**/ ?>