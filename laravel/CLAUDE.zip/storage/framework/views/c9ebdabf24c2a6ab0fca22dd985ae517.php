

<?php $__env->startSection('content'); ?>
<div class="card">
    <p><a href="<?php echo e(route('admin.wallets.index')); ?>">&larr; Back to wallets</a></p>
    <h1>Wallet — <?php echo e($wallet->user?->email ?? $wallet->user_id); ?></h1>

    <div class="detail-grid">
        <p><strong>Available:</strong> GHS <?php echo e(number_format((float) $wallet->available_balance, 2)); ?></p>
        <p><strong>Pending:</strong> GHS <?php echo e(number_format((float) $wallet->pending_balance, 2)); ?></p>
        <p><strong>Withdrawn:</strong> GHS <?php echo e(number_format((float) $wallet->withdrawn_balance, 2)); ?></p>
        <p><strong>Lifetime earnings:</strong> GHS <?php echo e(number_format((float) $wallet->lifetime_earnings, 2)); ?></p>
    </div>

    <h2>Recent transactions</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaction->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($transaction->source); ?></td>
                    <td>GHS <?php echo e(number_format((float) $transaction->amount, 2)); ?></td>
                    <td><?php echo e($transaction->status); ?></td>
                    <td><?php echo e($transaction->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">No transactions yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/wallets/show.blade.php ENDPATH**/ ?>