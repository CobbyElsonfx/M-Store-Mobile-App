<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light">
    <title><?php echo e(($title ?? 'Admin') . ' — MoMo Kotle'); ?></title>
    <?php echo $__env->make('admin.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>
    <div class="admin-shell">
        <?php echo $__env->make('admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="admin-main">
            <header class="admin-topbar">
                <div>
                    <h1><?php echo e($title ?? 'Admin'); ?></h1>
                </div>
                <div class="admin-topbar-meta">
                    <?php echo e(now()->format('l, M j, Y')); ?>

                </div>
            </header>

            <main class="admin-content">
                <?php if(session('status')): ?>
                    <div class="flash"><?php echo e(session('status')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="flash error"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/layout.blade.php ENDPATH**/ ?>