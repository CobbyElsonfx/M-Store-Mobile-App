

<?php $__env->startSection('content'); ?>
<div class="card">
    <p><a href="<?php echo e(route('admin.submissions.index')); ?>">&larr; Back to submissions</a></p>

    <h1><?php echo e($application->id); ?></h1>
    <p><?php echo e($application->form_type); ?></p>

    <div class="detail-grid">
        <p><strong>Applicant:</strong> <?php echo e($application->applicant_name); ?></p>
        <p><strong>Phone:</strong> <?php echo e($application->phone_number); ?></p>
        <p><strong>Status:</strong> <?php echo e(\App\Support\SubmissionLabels::statusLabel($application->status)); ?></p>
        <p><strong>Submitted:</strong> <?php echo e($application->created_at?->format('Y-m-d H:i')); ?></p>
        <?php if($application->user): ?>
            <p><strong>User:</strong> <?php echo e($application->user->email); ?></p>
        <?php endif; ?>
    </div>

    <?php if($application->admin_note): ?>
        <div class="note-box">
            <strong>Admin note</strong>
            <p><?php echo e($application->admin_note); ?></p>
        </div>
    <?php endif; ?>

    <h2>Applicant information</h2>
    <div class="detail-grid">
        <?php $__currentLoopData = ($application->form_data ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                <strong><?php echo e($formFieldLabels[$key] ?? $key); ?>:</strong>
                <?php echo e($value ?: '—'); ?>

            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2>Documents</h2>
    <?php if($application->documents->isEmpty()): ?>
        <p>No documents uploaded.</p>
    <?php else: ?>
        <div class="documents-grid">
            <?php $__currentLoopData = $application->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $label = $documentLabels[$document->document_type] ?? $document->document_type;
                    $url = route('admin.submissions.document', [$application, $document->document_type]);
                    $isImage = str_starts_with((string) $document->mime_type, 'image/');
                ?>
                <div class="document-card">
                    <p><strong><?php echo e($label); ?></strong></p>
                    <?php if($isImage): ?>
                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener">
                            <img src="<?php echo e($url); ?>" alt="<?php echo e($label); ?>" class="document-preview">
                        </a>
                    <?php endif; ?>
                    <p><a href="<?php echo e($url); ?>" target="_blank" rel="noopener">Open document</a></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <h2>Update status</h2>
    <form method="POST" action="<?php echo e(route('admin.submissions.update-status', $application)); ?>" class="status-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status" required>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(old('status', $application->status) === $status): echo 'selected'; endif; ?>>
                        <?php echo e(\App\Support\SubmissionLabels::statusLabel($status)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="admin_note">Admin note</label>
            <textarea id="admin_note" name="admin_note" rows="4" placeholder='e.g. "Form A is blurry."'><?php echo e(old('admin_note', $application->admin_note)); ?></textarea>
        </div>
        <button type="submit">Save status</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/submissions/show.blade.php ENDPATH**/ ?>