

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Review withdrawal requests, approve payouts, and mark completed transfers as paid.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.withdrawals.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Agent name, email, payment number">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Agent</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Payment #</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $user = $withdrawal->user;
                    $agentName = '—';
                    if ($user) {
                        $agentName = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                        if ($agentName === '') {
                            $agentName = $user->name ?? '—';
                        }
                    }
                ?>
                <tr>
                    <td><?php echo e($withdrawal->created_at?->format('Y-m-d H:i')); ?></td>
                    <td>
                        <?php echo e($agentName); ?>

                        <?php if($user?->email): ?>
                            <br><small><?php echo e($user->email); ?></small>
                        <?php endif; ?>
                    </td>
                    <td>GHS <?php echo e(number_format((float) $withdrawal->amount, 2)); ?></td>
                    <td><?php echo e(str_replace('_', ' ', $withdrawal->payment_method)); ?></td>
                    <td><?php echo e($withdrawal->payment_number); ?></td>
                    <td><span class="badge <?php echo e(strtolower($withdrawal->status)); ?>"><?php echo e($withdrawal->status); ?></span></td>
                    <td>
                        <?php if($withdrawal->admin_note): ?>
                            <small>Note: <?php echo e($withdrawal->admin_note); ?></small><br>
                        <?php endif; ?>

                        <?php if($withdrawal->status === 'Pending'): ?>
                            <form class="inline-action" method="POST" action="<?php echo e(route('admin.withdrawals.update', $withdrawal)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.withdrawals._return_fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <input type="hidden" name="action" value="approve">
                                <button type="submit">Approve</button>
                            </form>
                            <form class="inline-action" method="POST" action="<?php echo e(route('admin.withdrawals.update', $withdrawal)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.withdrawals._return_fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <input type="hidden" name="action" value="reject">
                                <input type="text" name="admin_note" placeholder="Rejection note">
                                <button type="submit" class="btn-danger">Reject</button>
                            </form>
                        <?php elseif($withdrawal->status === 'Approved'): ?>
                            <form class="inline-action" method="POST" action="<?php echo e(route('admin.withdrawals.update', $withdrawal)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.withdrawals._return_fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <input type="hidden" name="action" value="mark_paid">
                                <button type="submit">Mark paid</button>
                            </form>
                            <form class="inline-action" method="POST" action="<?php echo e(route('admin.withdrawals.update', $withdrawal)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.withdrawals._return_fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <input type="hidden" name="action" value="reject">
                                <input type="text" name="admin_note" placeholder="Rejection note">
                                <button type="submit" class="btn-danger">Reject</button>
                            </form>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No withdrawal requests found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <div class="pagination">
        <?php if($withdrawals->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($withdrawals->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $withdrawals->getUrlRange(max(1, $withdrawals->currentPage() - 2), min($withdrawals->lastPage(), $withdrawals->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $withdrawals->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($withdrawals->hasMorePages()): ?>
            <a href="<?php echo e($withdrawals->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/withdrawals/index.blade.php ENDPATH**/ ?>