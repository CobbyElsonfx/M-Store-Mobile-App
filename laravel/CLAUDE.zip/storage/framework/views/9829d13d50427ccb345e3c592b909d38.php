

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Update the dial code and automation steps for <strong><?php echo e($flow->name); ?></strong> (<code><?php echo e($flow->flow_key); ?></code>).</p>

    <form method="POST" action="<?php echo e(route('admin.ussd-flows.update', $flow)); ?>" class="status-form wide-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="detail-grid">
            <div>
                <label for="name">Display name</label>
                <input id="name" name="name" type="text" value="<?php echo e(old('name', $flow->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="ussd_code">USSD dial code</label>
                <input id="ussd_code" name="ussd_code" type="text" value="<?php echo e(old('ussd_code', $flow->ussd_code)); ?>" required placeholder="*171#">
                <?php $__errorArgs = ['ussd_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div>
            <label for="steps_text">Steps (one per line)</label>
            <textarea id="steps_text" name="steps_text" rows="12" required><?php echo e(old('steps_text', $stepsText)); ?></textarea>
            <?php $__errorArgs = ['steps_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <small class="field-help">
                Menu options: enter the digit/key (e.g. <code>3</code>, <code>1</code>).
                Special tokens: <code>phone</code>, <code>phone_confirm</code>, <code>amount</code>, <code>reference</code>, <code>stop</code>.
                Cash In default is <code>1</code>, <code>1</code>, <code>phone</code>, <code>phone_confirm</code>, <code>amount</code>, <code>reference</code>.
                Automation stops before PIN — the user only enters their PIN on the USSD screen.
            </small>
        </div>

        <div class="toggle-row">
            <label><input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $flow->is_active)): echo 'checked'; endif; ?>> Active</label>
        </div>

        <div class="form-actions">
            <button type="submit">Save flow</button>
            <a class="btn btn-secondary" href="<?php echo e(route('admin.ussd-flows.index')); ?>">Back</a>
        </div>
    </form>

    <form method="POST" action="<?php echo e(route('admin.ussd-flows.reset', $flow)); ?>" class="inline" style="margin-top: 1rem" onsubmit="return confirm('Reset this flow to factory defaults?')">
        <?php echo csrf_field(); ?>
        <button type="submit" class="link danger">Reset to defaults</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/ussd-flows/edit.blade.php ENDPATH**/ ?>