

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Business metrics for the selected period.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.reports.index')); ?>">
        <div>
            <label for="filter">Period</label>
            <select id="filter" name="filter">
                <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($filter === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="start_date">From</label>
            <input id="start_date" name="start_date" type="date" value="<?php echo e($startDate); ?>">
        </div>
        <div>
            <label for="end_date">To</label>
            <input id="end_date" name="end_date" type="date" value="<?php echo e($endDate); ?>">
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Apply</button>
        </div>
    </form>

    <div class="detail-grid">
        <div class="stat-box"><strong>Total sales</strong><p>GHS <?php echo e(number_format($report['total_sales'], 2)); ?></p></div>
        <div class="stat-box"><strong>Total orders</strong><p><?php echo e($report['total_orders']); ?></p></div>
        <div class="stat-box"><strong>Total revenue</strong><p>GHS <?php echo e(number_format($report['total_revenue'], 2)); ?></p></div>
        <div class="stat-box"><strong>Subscription revenue</strong><p>GHS <?php echo e(number_format($report['subscription_revenue'], 2)); ?></p></div>
        <div class="stat-box"><strong>Referral earnings</strong><p>GHS <?php echo e(number_format($report['referral_earnings'], 2)); ?></p></div>
        <div class="stat-box"><strong>Withdrawals paid</strong><p>GHS <?php echo e(number_format($report['withdrawal_total'], 2)); ?></p></div>
        <div class="stat-box"><strong>New referrals</strong><p><?php echo e($report['new_referrals']); ?></p></div>
        <div class="stat-box"><strong>Active subscriptions</strong><p><?php echo e($report['active_subscriptions']); ?></p></div>
    </div>

    <h2>Orders by status</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Status</th><th>Count</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $report['orders_by_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($status); ?></td><td><?php echo e($count); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table></div>

    <h2>Top products (delivered quantity)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Product</th><th>Quantity</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $report['top_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><?php echo e($name); ?></td><td><?php echo e($count); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="2">No delivered orders in this period.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <h2>Top referrers (commission earnings)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Referrer</th><th>Earnings</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $report['top_referrers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $user = $row['user']; ?>
                <tr>
                    <td><?php echo e($user?->email ?? '—'); ?></td>
                    <td>GHS <?php echo e(number_format($row['earnings'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="2">No commission data in this period.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>