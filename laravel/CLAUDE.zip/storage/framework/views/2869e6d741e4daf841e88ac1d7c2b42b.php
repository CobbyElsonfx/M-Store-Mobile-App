<div class="pagination">
    <?php if($paginator->onFirstPage()): ?>
        <span>&laquo; Prev</span>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>">&laquo; Prev</a>
    <?php endif; ?>

    <?php $__currentLoopData = $paginator->getUrlRange(max(1, $paginator->currentPage() - 2), min($paginator->lastPage(), $paginator->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($page == $paginator->currentPage()): ?>
            <span class="current"><?php echo e($page); ?></span>
        <?php else: ?>
            <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>">Next &raquo;</a>
    <?php else: ?>
        <span>Next &raquo;</span>
    <?php endif; ?>
</div>
<?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/partials/pagination.blade.php ENDPATH**/ ?>