

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Manage store orders and trigger referral commission when marking an order as Delivered.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.orders.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Agent, item, phone, location">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Agent</th>
                <th>Item</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Status</th>
                <th>Commission</th>
                <th>Update</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($order->created_at?->format('Y-m-d H:i')); ?></td>
                    <td>
                        <?php echo e($order->agent_name); ?>

                        <?php if($order->user): ?>
                            <br><small><?php echo e($order->user->email); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($order->item_name); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td>GHS <?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                    <td><span class="badge <?php echo e(strtolower($order->status)); ?>"><?php echo e($order->status); ?></span></td>
                    <td><?php echo e($order->commission_processed ? 'Processed' : '—'); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.orders.update-status', $order)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="return_status" value="<?php echo e(request('status')); ?>">
                            <input type="hidden" name="return_search" value="<?php echo e($search); ?>">
                            <input type="hidden" name="return_page" value="<?php echo e(request('page')); ?>">
                            <select name="status" onchange="this.form.submit()">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php if($order->status === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>

    <div class="pagination">
        <?php if($orders->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($orders->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $orders->getUrlRange(max(1, $orders->currentPage() - 2), min($orders->lastPage(), $orders->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $orders->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($orders->hasMorePages()): ?>
            <a href="<?php echo e($orders->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>