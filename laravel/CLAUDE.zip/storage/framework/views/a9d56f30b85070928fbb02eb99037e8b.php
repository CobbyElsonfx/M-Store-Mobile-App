<?php $__env->startSection('content'); ?>
<div class="card">
    <p><a href="<?php echo e(route('admin.users.index')); ?>">&larr; Back to users</a></p>

    <?php
        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
        if ($name === '') {
            $name = $user->name;
        }
    ?>

    <h1><?php echo e($name); ?></h1>
    <p><?php echo e($user->email); ?></p>

    <div class="detail-grid">
        <p><strong>Phone:</strong> <?php echo e($user->phone_number ?: '—'); ?></p>
        <p><strong>Location:</strong> <?php echo e($user->location ?: '—'); ?></p>
        <p><strong>Referral code:</strong> <?php echo e($user->referral_code ?: '—'); ?></p>
        <p><strong>Account status:</strong> <?php echo e($user->account_status->value); ?></p>
        <p><strong>Joined:</strong> <?php echo e($user->created_at?->format('Y-m-d H:i')); ?></p>
        <?php if($user->referrer): ?>
            <?php
                $referrerName = trim(($user->referrer->first_name ?? '').' '.($user->referrer->last_name ?? ''));
                if ($referrerName === '') {
                    $referrerName = $user->referrer->name;
                }
            ?>
            <p><strong>Referred by:</strong> <?php echo e($referrerName); ?> (<?php echo e($user->referrer->email); ?>)</p>
        <?php endif; ?>
    </div>

    <h2>Activity</h2>
    <div class="detail-grid">
        <p><strong>Orders:</strong> <?php echo e($stats['orders']); ?></p>
        <p><strong>Submissions:</strong> <?php echo e($stats['submissions']); ?></p>
        <p><strong>Referrals:</strong> <?php echo e($stats['referrals']); ?></p>
        <p><strong>Wallet balance:</strong> GHS <?php echo e(number_format((float) ($stats['wallet']->available_balance ?? 0), 2)); ?></p>
        <p><strong>Lifetime earnings:</strong> GHS <?php echo e(number_format((float) ($stats['wallet']->lifetime_earnings ?? 0), 2)); ?></p>
    </div>

    <?php
        $subscriptionStatus = $user->subscription_status?->value ?? 'None';
        $currentPlan = $user->activeSubscription;
    ?>

    <h2>Subscription</h2>
    <div class="detail-grid">
        <p>
            <strong>Status:</strong>
            <span class="badge <?php echo e(strtolower($subscriptionStatus)); ?>"><?php echo e($subscriptionStatus); ?></span>
        </p>
        <p><strong>Plan:</strong> <?php echo e($currentPlan?->plan_name ?? '—'); ?></p>
        <p><strong>Expires:</strong> <?php echo e($user->subscription_expiry_date?->format('Y-m-d H:i') ?: '—'); ?></p>
        <p><strong>Trial ends:</strong> <?php echo e($user->trial_end_date?->format('Y-m-d H:i') ?: '—'); ?></p>
    </div>

    <p class="card-lead">Assigning a plan starts today and lasts for the plan duration. An existing active subscription is replaced. Referral bonuses are not paid for admin changes.</p>

    <form method="POST" action="<?php echo e(route('admin.users.update-subscription', $user)); ?>" class="status-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" name="action" value="grant">
        <div>
            <label for="plan_id">Plan</label>
            <select id="plan_id" name="plan_id" required>
                <option value="">Select a plan</option>
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plan->id); ?>" <?php if(old('plan_id') === $plan->id): echo 'selected'; endif; ?>>
                        <?php echo e($plan->plan_name); ?> — GHS <?php echo e(number_format((float) $plan->price, 2)); ?> / <?php echo e($plan->duration_days); ?> days
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['plan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="admin_note">Admin note (optional)</label>
            <textarea id="admin_note" name="admin_note" rows="3" placeholder="Why this change was made"><?php echo e(old('admin_note')); ?></textarea>
            <?php $__errorArgs = ['admin_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit">Apply plan</button>
    </form>

    <form
        method="POST"
        action="<?php echo e(route('admin.users.update-subscription', $user)); ?>"
        class="status-form"
        onsubmit="return confirm('End this user\'s current subscription?');"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" name="action" value="revoke">
        <button type="submit" class="btn-danger">End subscription</button>
    </form>

    <?php if($user->subscriptions->isNotEmpty()): ?>
        <h2>Subscription history</h2>
        <div class="table-wrap"><table>
            <thead>
                <tr>
                    <th>Plan</th>
                    <th>Provider</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Status</th>
                    <th>Reference</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user->subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($subscription->plan_name); ?></td>
                        <td><?php echo e($subscription->payment_provider ?: '—'); ?></td>
                        <td><?php echo e($subscription->start_date?->format('Y-m-d')); ?></td>
                        <td><?php echo e($subscription->end_date?->format('Y-m-d')); ?></td>
                        <td><?php echo e($subscription->status); ?></td>
                        <td><?php echo e($subscription->payment_reference ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
    <?php endif; ?>

    <h2>Account access</h2>
    <form method="POST" action="<?php echo e(route('admin.users.update-status', $user)); ?>" class="status-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div>
            <label for="account_status">Status</label>
            <select id="account_status" name="account_status" required>
                <option value="Active" <?php if($user->account_status->value === 'Active'): echo 'selected'; endif; ?>>Active</option>
                <option value="Suspended" <?php if($user->account_status->value === 'Suspended'): echo 'selected'; endif; ?>>Suspended</option>
            </select>
        </div>
        <button type="submit">Update status</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/users/show.blade.php ENDPATH**/ ?>