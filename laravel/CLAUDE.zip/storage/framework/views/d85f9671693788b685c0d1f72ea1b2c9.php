

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Subscription payments. Paystack credentials are never shown here.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.payments.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Email, reference">
        </div>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="all" <?php if($statusFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($statusFilter === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Provider</th>
                <th>Reference</th>
                <th>Paystack</th>
                <th>Status</th>
                <th>Paid</th>
                <th>Start</th>
                <th>Expiry</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($payment->user?->email ?? '—'); ?></td>
                    <td><?php echo e($payment->plan?->plan_name ?? '—'); ?></td>
                    <td><?php echo e($payment->currency); ?> <?php echo e(number_format((float) $payment->amount, 2)); ?></td>
                    <td><?php echo e($payment->provider); ?></td>
                    <td><?php echo e($payment->reference); ?></td>
                    <td><?php echo e($payment->provider_reference ?: '—'); ?></td>
                    <td><?php echo e($payment->status); ?></td>
                    <td><?php echo e($payment->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($payment->subscription?->start_date?->format('Y-m-d') ?? '—'); ?></td>
                    <td><?php echo e($payment->subscription?->end_date?->format('Y-m-d')
                        ?? $payment->user?->subscription_expiry_date?->format('Y-m-d')
                        ?? '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="10">No payments found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $payments], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>