<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Configure commission defaults, subscriptions, withdrawals, referral links, and Paystack payment credentials.</p>

    <form method="POST" action="<?php echo e(route('admin.settings.business.update')); ?>" class="status-form wide-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="detail-grid">
            <div>
                <label for="referral_commission_percent">Referral commission (%)</label>
                <input id="referral_commission_percent" name="referral_commission_percent" type="number" step="0.01" min="0" max="100" value="<?php echo e(old('referral_commission_percent', $settings['referral_commission_percent'])); ?>" required>
            </div>
            <div>
                <label for="system_commission_percent">System commission (%)</label>
                <input id="system_commission_percent" name="system_commission_percent" type="number" step="0.01" min="0" max="100" value="<?php echo e(old('system_commission_percent', $settings['system_commission_percent'])); ?>" required>
                <?php $__errorArgs = ['system_commission_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="monthly_subscription_bonus">Monthly subscription bonus (GHS)</label>
                <input id="monthly_subscription_bonus" name="monthly_subscription_bonus" type="number" step="0.01" min="0" value="<?php echo e(old('monthly_subscription_bonus', $settings['monthly_subscription_bonus'])); ?>" required>
            </div>
            <div>
                <label for="minimum_withdrawal">Minimum withdrawal (GHS)</label>
                <input id="minimum_withdrawal" name="minimum_withdrawal" type="number" step="0.01" min="0" value="<?php echo e(old('minimum_withdrawal', $settings['minimum_withdrawal'])); ?>" required>
            </div>
            <div>
                <label for="trial_days">Trial days</label>
                <input id="trial_days" name="trial_days" type="number" min="0" value="<?php echo e(old('trial_days', $settings['trial_days'])); ?>" required>
            </div>
            <div>
                <label for="currency">Currency</label>
                <input id="currency" name="currency" type="text" value="<?php echo e(old('currency', $settings['currency'])); ?>" required>
            </div>
            <div>
                <label for="tax_rate">Tax rate (%)</label>
                <input id="tax_rate" name="tax_rate" type="number" step="0.01" min="0" max="100" value="<?php echo e(old('tax_rate', $settings['tax_rate'])); ?>" required>
            </div>
        </div>

        <div>
            <label for="referral_share_link_base">Referral share link base</label>
            <input id="referral_share_link_base" name="referral_share_link_base" type="url" value="<?php echo e(old('referral_share_link_base', $settings['referral_share_link_base'])); ?>" required>
            <?php $__errorArgs = ['referral_share_link_base'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="support_contact">Support contact</label>
            <input id="support_contact" name="support_contact" type="text" value="<?php echo e(old('support_contact', $settings['support_contact'])); ?>" placeholder="Phone or email">
        </div>

        <div class="toggle-row">
            <label><input type="checkbox" name="store_enabled" value="1" <?php if(old('store_enabled', $settings['store_enabled'])): echo 'checked'; endif; ?>> Store enabled</label>
            <label><input type="checkbox" name="subscription_enabled" value="1" <?php if(old('subscription_enabled', $settings['subscription_enabled'])): echo 'checked'; endif; ?>> Subscriptions enabled</label>
            <label><input type="checkbox" name="maintenance_mode" value="1" <?php if(old('maintenance_mode', $settings['maintenance_mode'])): echo 'checked'; endif; ?>> Maintenance mode</label>
        </div>

        <div class="settings-section">
            <h2>Paystack</h2>
            <p class="settings-hint">Used only on the Laravel server for subscription checkout. The secret key is never sent to the Android app or shown again after saving.</p>

            <div>
                <label for="paystack_public_key">Public key</label>
                <input id="paystack_public_key" name="paystack_public_key" type="text" value="<?php echo e(old('paystack_public_key', $settings['paystack_public_key'])); ?>" placeholder="pk_test_..." autocomplete="off" spellcheck="false">
                <?php $__errorArgs = ['paystack_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="paystack_secret_key">Secret key</label>
                <input id="paystack_secret_key" name="paystack_secret_key" type="password" value="" placeholder="<?php echo e($settings['paystack_secret_configured'] ? 'Leave blank to keep the current secret' : 'sk_test_...'); ?>" autocomplete="new-password" spellcheck="false">
                <small class="settings-hint"><?php echo e($settings['paystack_secret_configured'] ? 'A secret key is already configured.' : 'No secret key is saved yet. TEST keys from Paystack Dashboard can be entered here.'); ?></small>
                <?php $__errorArgs = ['paystack_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="paystack_base_url">API base URL</label>
                <input id="paystack_base_url" name="paystack_base_url" type="url" value="<?php echo e(old('paystack_base_url', $settings['paystack_base_url'])); ?>" placeholder="https://api.paystack.co">
                <?php $__errorArgs = ['paystack_base_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="settings-section">
            <h2>Email notifications</h2>
            <p class="settings-hint">Transactional emails (payments, subscription activation, application status, and security alerts) are always sent. These settings only control reminders and admin alerts.</p>

            <div class="toggle-row">
                <label><input type="checkbox" name="email_reminders_enabled" value="1" <?php if(old('email_reminders_enabled', $settings['email_reminders_enabled'])): echo 'checked'; endif; ?>> Subscription expiry reminders</label>
                <label><input type="checkbox" name="email_admin_alerts_enabled" value="1" <?php if(old('email_admin_alerts_enabled', $settings['email_admin_alerts_enabled'])): echo 'checked'; endif; ?>> Admin alert emails</label>
            </div>

            <div>
                <label for="subscription_reminder_days">Reminder days before expiry</label>
                <input id="subscription_reminder_days" name="subscription_reminder_days" type="text" value="<?php echo e(old('subscription_reminder_days', $settings['subscription_reminder_days'])); ?>" placeholder="7,3,1">
                <small class="settings-hint">Comma-separated. Duplicate reminders for the same expiry date are not sent.</small>
            </div>

            <div>
                <label for="admin_notification_emails">Admin notification recipients</label>
                <textarea id="admin_notification_emails" name="admin_notification_emails" rows="3" placeholder="ops@example.com, finance@example.com"><?php echo e(old('admin_notification_emails', $settings['admin_notification_emails'])); ?></textarea>
                <small class="settings-hint">Used for new registrations, new applications, and payment alerts. Do not hardcode addresses in code.</small>
            </div>
        </div>

        <button type="submit">Save settings</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/settings/business.blade.php ENDPATH**/ ?>