

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Broadcast in-app notifications to agents via the mobile notification feed.</p>

    <form method="POST" action="<?php echo e(route('admin.notifications.store')); ?>" class="status-form wide-form">
        <?php echo csrf_field(); ?>

        <div>
            <label for="target">Target audience</label>
            <select id="target" name="target" required>
                <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(old('target', 'all') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="user_search">Search user (for specific target)</label>
            <div class="inline-action">
                <input id="user_search" name="user_search" type="search" value="<?php echo e($userSearch); ?>" placeholder="Name, email, phone">
                <button type="submit" formaction="<?php echo e(route('admin.notifications.create')); ?>" formmethod="GET">Search</button>
            </div>
        </div>

        <div>
            <label for="user_id">User</label>
            <select id="user_id" name="user_id">
                <option value="">Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $name = trim(($user->first_name ?? '').' '.($user->last_name ?? ''));
                        if ($name === '') {
                            $name = $user->name;
                        }
                    ?>
                    <option value="<?php echo e($user->id); ?>" <?php if((string) old('user_id') === (string) $user->id): echo 'selected'; endif; ?>>
                        <?php echo e($name); ?> — <?php echo e($user->email); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="title">Title</label>
            <input id="title" name="title" type="text" value="<?php echo e(old('title')); ?>" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="4" required><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit">Send notification</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/notifications/create.blade.php ENDPATH**/ ?>