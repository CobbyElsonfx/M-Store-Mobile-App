

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">System revenue summary and transaction history.</p>

    <div class="detail-grid">
        <div class="stat-box">
            <strong>Total revenue</strong>
            <p>GHS <?php echo e(number_format($summary['total'], 2)); ?></p>
        </div>
        <div class="stat-box">
            <strong>Transactions</strong>
            <p><?php echo e($summary['transaction_count']); ?></p>
        </div>
        <?php $__currentLoopData = $summary['by_source']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat-box">
                <strong><?php echo e($source); ?></strong>
                <p>GHS <?php echo e(number_format($amount, 2)); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.revenue.index')); ?>">
        <div>
            <label for="start_date">From</label>
            <input id="start_date" name="start_date" type="date" value="<?php echo e($startDate); ?>">
        </div>
        <div>
            <label for="end_date">To</label>
            <input id="end_date" name="end_date" type="date" value="<?php echo e($endDate); ?>">
        </div>
        <div>
            <label for="source">Source</label>
            <select id="source" name="source">
                <option value="all" <?php if($sourceFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($source); ?>" <?php if($sourceFilter === $source): echo 'selected'; endif; ?>><?php echo e($source); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Apply</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Order</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaction->created_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($transaction->source); ?></td>
                    <td>GHS <?php echo e(number_format((float) $transaction->amount, 2)); ?></td>
                    <td><?php echo e($transaction->order_id ?: '—'); ?></td>
                    <td><?php echo e($transaction->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No revenue transactions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <div class="pagination">
        <?php if($transactions->onFirstPage()): ?>
            <span>&laquo; Prev</span>
        <?php else: ?>
            <a href="<?php echo e($transactions->previousPageUrl()); ?>">&laquo; Prev</a>
        <?php endif; ?>

        <?php $__currentLoopData = $transactions->getUrlRange(max(1, $transactions->currentPage() - 2), min($transactions->lastPage(), $transactions->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $transactions->currentPage()): ?>
                <span class="current"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($transactions->hasMorePages()): ?>
            <a href="<?php echo e($transactions->nextPageUrl()); ?>">Next &raquo;</a>
        <?php else: ?>
            <span>Next &raquo;</span>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/revenue/index.blade.php ENDPATH**/ ?>