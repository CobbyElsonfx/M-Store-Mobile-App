

<?php $__env->startSection('content'); ?>
<div class="card">
    <p class="card-lead">Referral registrations and subscription activity.</p>

    <form class="toolbar" method="GET" action="<?php echo e(route('admin.referrals.index')); ?>">
        <div>
            <label for="search">Search</label>
            <input id="search" name="search" type="search" value="<?php echo e($search); ?>" placeholder="Code, name, email">
        </div>
        <div>
            <label for="subscription">Subscription</label>
            <select id="subscription" name="subscription">
                <option value="all" <?php if($subscriptionFilter === 'all'): echo 'selected'; endif; ?>>All</option>
                <option value="active" <?php if($subscriptionFilter === 'active'): echo 'selected'; endif; ?>>Active subscription</option>
                <option value="inactive" <?php if($subscriptionFilter === 'inactive'): echo 'selected'; endif; ?>>No active subscription</option>
            </select>
        </div>
        <div>
            <label>&nbsp;</label>
            <button type="submit">Filter</button>
        </div>
    </form>

    <div class="table-wrap"><table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Referrer</th>
                <th>Referred user</th>
                <th>Code</th>
                <th>Active sub</th>
                <th>Earnings</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($referral->registration_date?->format('Y-m-d')); ?></td>
                    <td><?php echo e($referral->referrer?->email ?? '—'); ?></td>
                    <td><?php echo e($referral->referred_user_name ?: ($referral->referredUser?->email ?? '—')); ?></td>
                    <td><code><?php echo e($referral->referrer_code); ?></code></td>
                    <td><?php echo e($referral->has_active_subscription ? 'Yes' : 'No'); ?></td>
                    <td>GHS <?php echo e(number_format((float) $referral->wallet_earnings, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">No referrals found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table></div>

    <?php echo $__env->make('admin.partials.pagination', ['paginator' => $referrals], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Projects\momo-kotle\laravel\resources\views/admin/referrals/index.blade.php ENDPATH**/ ?>