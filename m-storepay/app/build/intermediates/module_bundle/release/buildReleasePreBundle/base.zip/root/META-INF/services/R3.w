S3.b
