Q3.b
